// datas.js V1 - Bottin Annuaire Web Libre 2025
// Format V1 (avec date optionnelle)

window.sites = [
  {
    "n": "Constitutions Kulchatila",
    "u": "https://libresol2-5jaz4b32.manus.space",
    "c": "Constitution",
    "d": "Constitution des Communes Libres et Solidaires : Découvrez les différentes versions de notre projet constitutionnel innovant",
    "date": "2025"
  },
  {
    "n": "Constitutions LMBMicro",
    "u": "https://libresol2-5jaz4b32.manus.space",
    "c": "Constitution",
    "d": "Constitution des Communes Libres et Solidaires : Découvrez les différentes versions de notre projet constitutionnel innovant",
    "date": "2025"
  },
  {
    "n": "Constitutions",
    "u": "https://libresol2-5jaz4b32.manus.space",
    "c": "Kulchatila",
    "d": "Constitution des Communes Libres et Solidaires : Découvrez les différentes versions de notre projet constitutionnel innovant",
    "date": "2025"
  },
  {
    "n": "STM",
    "u": "https://www.stm.info/fr",
    "c": "Société de transport de Montréal",
    "d": "Mon transport public Montréal",
    "date": "2025"
  },
  {
    "n": "SIRTA",
    "u": "https://montransportadapte.stm.info",
    "c": "Société de transport de Montréal",
    "d": "Mon transport adapté Montréal",
    "date": "2025"
  },
  {
    "n": "CIBC",
    "u": "https://www.cibc.com/fr/personal-banking.html",
    "c": "Finance",
    "d": "La Banque CIBC",
    "date": "2025"
  },
  {
    "n": "Tangerine",
    "u": "https://www.tangerine.ca/app/#/accounts",
    "c": "Finance",
    "d": "La Banque Tangerine",
    "date": "2025"
  },
  {
    "n": "BNC",
    "u": "https://www.bnc.ca",
    "c": "Finance",
    "d": "La Banque Nationale",
    "date": "2025"
  },
  {
    "n": "Desjardins",
    "u": "https://accweb.mouv.desjardins.com",
    "c": "Finance",
    "d": "La Caisse Populaire Desjardins",
    "date": "2025"
  },
  {
    "n": "Honeygain",
    "u": "https://join.honeygain.com/LMBMI8C2",
    "c": "Crypto/Web3",
    "d": "Honeygain est la toute première application qui aide ses utilisateurs à gagner de l'argent en ligne en partageant leur connexion Internet",
    "date": "2025"
  },
  {
    "n": "Shodan",
    "u": "https://www.shodan.io",
    "c": "Recherches",
    "d": "Moteur de recherche pour services et appareils connectés",
    "date": "2025"
  },
  {
    "n": "Hunter.io Email Finder",
    "u": "https://hunter.io/fr/email-finder",
    "c": "Recherches",
    "d": "Recherche d'adresses email",
    "date": "2025"
  },
  {
    "n": "Torchsearch",
    "u": "https://torchsearch.org",
    "c": "Recherches",
    "d": "Moteur de recherche Torch",
    "date": "2025"
  },
  {
    "n": "ZoomEye",
    "u": "https://www.zoomeye.ai",
    "c": "Recherches",
    "d": "Moteur de recherche pour cybersécurité",
    "date": "2025"
  },
  {
    "n": "Canada411",
    "u": "https://fr.canada411.ca",
    "c": "Recherches",
    "d": "Annuaire téléphonique canadien",
    "date": "2025"
  },
  {
    "n": "Pages Jaunes",
    "u": "https://www.pagesjaunes.ca",
    "c": "Recherches",
    "d": "Annuaire Pages Jaunes Canada",
    "date": "2025"
  },
  {
    "n": "DuckDuckGo",
    "u": "https://duckduckgo.com",
    "c": "Recherches",
    "d": "Moteur de recherche respectueux de la vie privée",
    "date": "2025"
  },
  {
    "n": "Mojeek",
    "u": "https://www.mojeek.com",
    "c": "Recherches",
    "d": "Moteur de recherche indépendant",
    "date": "2025"
  },
  {
    "n": "Yandex",
    "u": "https://yandex.com",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Seznam",
    "u": "https://www.seznam.cz",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Qwant",
    "u": "https://www.qwant.com",
    "c": "Recherches",
    "d": "Moteur de recherche français",
    "date": "2025"
  },
  {
    "n": "Lukol",
    "u": "https://www.lukol.com",
    "c": "Recherches",
    "d": "Moteur de recherche anonyme",
    "date": "2025"
  },
  {
    "n": "Archive.org",
    "u": "https://archive.org",
    "c": "Apprentissage",
    "d": "Bibliothèque numérique et archives du web",
    "date": "2025"
  },
  {
    "n": "Yahoo Canada",
    "u": "https://ca.yahoo.com",
    "c": "Recherches",
    "d": "Portail et moteur de recherche Yahoo Canada",
    "date": "2025"
  },
  {
    "n": "Webcrawler",
    "u": "https://www.webcrawler.com",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Bing",
    "u": "https://www.bing.com",
    "c": "Recherches",
    "d": "Moteur de recherche Microsoft",
    "date": "2025"
  },
  {
    "n": "Google",
    "u": "https://www.google.com",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Startpage",
    "u": "https://www.startpage.com",
    "c": "Recherches",
    "d": "Moteur de recherche privé",
    "date": "2025"
  },
  {
    "n": "Ecosia",
    "u": "https://www.ecosia.org",
    "c": "Recherches",
    "d": "Moteur de recherche qui finance la plantation d'arbres",
    "date": "2025"
  },
  {
    "n": "Lilo",
    "u": "https://www.lilo.org",
    "c": "Recherches",
    "d": "Moteur de recherche solidaire",
    "date": "2025"
  },
  {
    "n": "GiveWater",
    "u": "https://www.givewater.com",
    "c": "Recherches",
    "d": "Moteur de recherche caritatif",
    "date": "2025"
  },
  {
    "n": "YouCare",
    "u": "https://youcare.world/?l=fr",
    "c": "Recherches",
    "d": "Moteur solidaire (FR)",
    "date": "2025"
  },
  {
    "n": "Brave Search",
    "u": "https://search.brave.com",
    "c": "Recherches",
    "d": "Moteur de recherche Brave",
    "date": "2025"
  },
  {
    "n": "Larousse",
    "u": "https://www.larousse.fr",
    "c": "Apprentissage",
    "d": "Dictionnaire et encyclopédie FR",
    "date": "2025"
  },
  {
    "n": "National Geographic FR",
    "u": "https://www.nationalgeographic.fr",
    "c": "Apprentissage",
    "d": "Articles science et exploration",
    "date": "2025"
  },
  {
    "n": "Wikipedia FR",
    "u": "https://fr.wikipedia.org",
    "c": "Apprentissage",
    "d": "Encyclopédie libre (FR)",
    "date": "2025"
  },
  {
    "n": "Grokipedia",
    "u": "https://grokipedia.com",
    "c": "Apprentissage",
    "d": "Wiki alternatif",
    "date": "2025"
  },
  {
    "n": "Ask",
    "u": "https://www.ask.com",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Gibiru",
    "u": "https://gibiru.com",
    "c": "Recherches",
    "d": "Moteur privé",
    "date": "2025"
  },
  {
    "n": "GitHub",
    "u": "https://github.com",
    "c": "Apprentissage",
    "d": "Hébergement de code et collaboration",
    "date": "2025"
  },
  {
    "n": "Disconnect Search",
    "u": "https://search.disconnect.me",
    "c": "Recherches",
    "d": "Recherche privée via proxy",
    "date": "2025"
  },
  {
    "n": "MetaGer FR",
    "u": "https://metager.org/fr-FR",
    "c": "Recherches",
    "d": "Meta-moteur de recherche (FR)",
    "date": "2025"
  },
  {
    "n": "Oscobo",
    "u": "https://www.oscobo.com",
    "c": "Recherches",
    "d": "Moteur axé confidentialité",
    "date": "2025"
  },
  {
    "n": "YaCy",
    "u": "https://yacy.net",
    "c": "Recherches",
    "d": "Moteur P2P décentralisé",
    "date": "2025"
  },
  {
    "n": "Searx",
    "u": "https://searx.bndkt.io",
    "c": "Recherches",
    "d": "Meta-moteur open source",
    "date": "2025"
  },
  {
    "n": "PeerTube",
    "u": "https://peertube.tv",
    "c": "Vidéo et audio",
    "d": "Plateforme vidéo décentralisée",
    "date": "2025"
  },
  {
    "n": "YouTube",
    "u": "https://www.youtube.com",
    "c": "Vidéo et audio",
    "d": "Plateforme vidéo",
    "date": "2025"
  },
  {
    "n": "TikTok FR",
    "u": "https://www.tiktok.com/fr",
    "c": "Vidéo et audio",
    "d": "Plateforme vidéo courte (FR)",
    "date": "2025"
  },
  {
    "n": "Dailymotion CA",
    "u": "https://www.dailymotion.com/ca",
    "c": "Vidéo et audio",
    "d": "Plateforme vidéo (CA)",
    "date": "2025"
  },
  {
    "n": "Baidu",
    "u": "https://www.baidu.com",
    "c": "Recherches",
    "d": "Moteur de recherche chinois",
    "date": "2025"
  },
  {
    "n": "Sogou (HTTP)",
    "u": "http://www.sogou.com",
    "c": "Recherches",
    "d": "Moteur chinois (HTTP)",
    "date": "2025"
  },
  {
    "n": "Youdao",
    "u": "https://www.youdao.com",
    "c": "Recherches",
    "d": "Service de recherche/traduction",
    "date": "2025"
  },
  {
    "n": "Sogou",
    "u": "https://www.sogou.com",
    "c": "Recherches",
    "d": "Moteur de recherche chinois",
    "date": "2025"
  },
  {
    "n": "Soso",
    "u": "https://www.soso.com/",
    "c": "Recherches",
    "d": "Moteur de recherche",
    "date": "2025"
  },
  {
    "n": "Swisscows FR",
    "u": "https://swisscows.com/fr",
    "c": "Recherches",
    "d": "Moteur privé (FR)",
    "date": "2025"
  },
  {
    "n": "Geo.ca",
    "u": "https://geo.ca/fr/accueil",
    "c": "Cartes",
    "d": "Portail géospatial du Canada (FR)",
    "date": "2025"
  },
  {
    "n": "Geoportail",
    "u": "https://www.geoportail.gouv.fr",
    "c": "Cartes",
    "d": "Portail cartographique France",
    "date": "2025"
  },
  {
    "n": "ToS;DR FR",
    "u": "https://tosdr.org/fr",
    "c": "Apprentissage",
    "d": "Analyse des conditions d'utilisation (FR)",
    "date": "2025"
  },
  {
    "n": "StartMyCar",
    "u": "https://www.startmycar.com",
    "c": "Utilitaires web",
    "d": "Démarreur auto - infos/communauté",
    "date": "2025"
  },
  {
    "n": "KarmaSearch FR",
    "u": "https://karmasearch.org/fr",
    "c": "Recherches",
    "d": "Moteur de recherche (FR)",
    "date": "2025"
  },
  {
    "n": "360 Earth View",
    "u": "https://360earthview.com",
    "c": "Cartes",
    "d": "Cartes aériennes et satellite",
    "date": "2025"
  },
  {
    "n": "360 Earth View GPS",
    "u": "https://360earthview.com/aerial-maps/search.html?fun=gps",
    "c": "Cartes",
    "d": "Recherche GPS aérienne",
    "date": "2025"
  },
  {
    "n": "Gosur Satellite FR",
    "u": "https://satellite-map.gosur.com/fr",
    "c": "Cartes",
    "d": "Carte satellite (FR)",
    "date": "2025"
  },
  {
    "n": "Google Maps CA",
    "u": "https://www.google.ca/maps",
    "c": "Cartes",
    "d": "Cartographie Google (CA)",
    "date": "2025"
  },
  {
    "n": "Google Earth Web",
    "u": "https://earth.google.com/web",
    "c": "Cartes",
    "d": "Visualisation 3D terrestre",
    "date": "2025"
  },
  {
    "n": "Bing Maps",
    "u": "https://www.bing.com/maps",
    "c": "Cartes",
    "d": "Cartographie Microsoft",
    "date": "2025"
  },
  {
    "n": "Mappy Plan",
    "u": "https://fr.mappy.com/plan",
    "c": "Cartes",
    "d": "Plans et itinéraires (FR)",
    "date": "2025"
  },
  {
    "n": "Portail Cartographique QC",
    "u": "https://vgo.portailcartographique.gouv.qc.ca/mobile.aspx",
    "c": "Cartes",
    "d": "Portail carto Québec",
    "date": "2025"
  },
  {
    "n": "EOS LandViewer FR",
    "u": "https://eos.com/landviewer/fr",
    "c": "Cartes",
    "d": "Imagerie satellite (FR)",
    "date": "2025"
  },
  {
    "n": "Zoom.Earth Satellite HD",
    "u": "https://zoom.earth/maps/satellite-hd",
    "c": "Cartes",
    "d": "Satellite HD temps réel",
    "date": "2025"
  },
  {
    "n": "LeoLabs Visualization",
    "u": "https://platform.leolabs.space/visualization",
    "c": "Cartes",
    "d": "Visualisation trafic spatial",
    "date": "2025"
  },
  {
    "n": "Waze Live Map FR",
    "u": "https://www.waze.com/fr/live-map",
    "c": "Cartes",
    "d": "Trafic en direct (FR)",
    "date": "2025"
  },
  {
    "n": "Aixploria Top 100 IA",
    "u": "https://www.aixploria.com/top-100-ia",
    "c": "IA",
    "d": "Liste d'outils IA (FR)",
    "date": "2025"
  },
  {
    "n": "Hugging Face Spaces",
    "u": "https://huggingface.co/spaces",
    "c": "IA",
    "d": "Apps IA communautaires",
    "date": "2025"
  },
  {
    "n": "Manus IM",
    "u": "https://manus.im/app",
    "c": "IA",
    "d": "App de messagerie IA",
    "date": "2025"
  },
  {
    "n": "Claude",
    "u": "https://claude.ai/new",
    "c": "IA",
    "d": "Assistant IA",
    "date": "2025"
  },
  {
    "n": "DeepSeek Chat",
    "u": "https://chat.deepseek.com",
    "c": "IA",
    "d": "Chat IA",
    "date": "2025"
  },
  {
    "n": "Copilot",
    "u": "https://copilot.microsoft.com",
    "c": "IA",
    "d": "Assistant IA Microsoft",
    "date": "2025"
  },
  {
    "n": "Google AI Studio",
    "u": "https://aistudio.google.com/prompts/new_chat",
    "c": "IA",
    "d": "Studio prompts IA",
    "date": "2025"
  },
  {
    "n": "ChatGPT",
    "u": "https://chatgpt.com",
    "c": "IA",
    "d": "Assistant IA OpenAI",
    "date": "2025"
  },
  {
    "n": "Gemini",
    "u": "https://gemini.google.com/app",
    "c": "IA",
    "d": "Assistant IA Google",
    "date": "2025"
  },
  {
    "n": "Grok",
    "u": "https://grok.com",
    "c": "IA",
    "d": "Assistant IA",
    "date": "2025"
  },
  {
    "n": "DALL·E 3 FR",
    "u": "https://openai.com/fr-FR/index/dall-e-3",
    "c": "IA",
    "d": "Génération d'images (FR)",
    "date": "2025"
  },
  {
    "n": "OpenAI FR",
    "u": "https://openai.com/fr-FR",
    "c": "IA",
    "d": "Portail OpenAI (FR)",
    "date": "2025"
  },
  {
    "n": "GenSpark",
    "u": "https://www.genspark.ai",
    "c": "IA",
    "d": "Plateforme IA",
    "date": "2025"
  },
  {
    "n": "Perplexity",
    "u": "https://www.perplexity.ai",
    "c": "IA",
    "d": "Recherche IA conversationnelle",
    "date": "2025"
  },
  {
    "n": "RemakeIt FR",
    "u": "https://www.remakeit.io/fr",
    "c": "IA",
    "d": "Outils IA (FR)",
    "date": "2025"
  },
  {
    "n": "StackEdit",
    "u": "https://stackedit.io",
    "c": "Utilitaires web",
    "d": "Éditeur Markdown en ligne",
    "date": "2025"
  },
  {
    "n": "Songer",
    "u": "https://songer.co",
    "c": "Musique et voix",
    "d": "Génération musicale IA",
    "date": "2025"
  },
  {
    "n": "Wan Video",
    "u": "https://wan.video",
    "c": "Vidéo et audio",
    "d": "Outil vidéo IA",
    "date": "2025"
  },
  {
    "n": "AINSFW FR",
    "u": "https://www.ainsfw.ai/fr",
    "c": "IA",
    "d": "Outils IA (FR)",
    "date": "2025"
  },
  {
    "n": "OpenAI Academy",
    "u": "https://academy.openai.com",
    "c": "Apprentissage",
    "d": "Ressources et cours OpenAI",
    "date": "2025"
  },
  {
    "n": "Synthesis Tutor",
    "u": "https://www.synthesis.com/tutor",
    "c": "Apprentissage",
    "d": "Tutor IA pour apprentissage",
    "date": "2025"
  },
  {
    "n": "ElevenLabs FR",
    "u": "https://elevenlabs.io/fr",
    "c": "Musique et voix",
    "d": "Synthèse et clonage vocal (FR)",
    "date": "2025"
  },
  {
    "n": "Wavetube",
    "u": "https://wavetube.ai/ai-podcast-to-video",
    "c": "Vidéo et audio",
    "d": "Convertir podcasts en vidéo IA",
    "date": "2025"
  },
  {
    "n": "MusicCreator FR",
    "u": "https://www.musiccreator.ai/fr/ai-music-generator",
    "c": "Musique et voix",
    "d": "Générateur de musique IA (FR)",
    "date": "2025"
  },
  {
    "n": "Dezgo",
    "u": "https://dezgo.com",
    "c": "IA",
    "d": "Génération d'images IA",
    "date": "2025"
  },
  {
    "n": "Immersity Upload",
    "u": "https://app.immersity.ai/upload",
    "c": "Vidéo et audio",
    "d": "Upload pour plateforme IA Immersity",
    "date": "2025"
  },
  {
    "n": "Mistral Console",
    "u": "https://console.mistral.ai/home",
    "c": "IA",
    "d": "Console Mistral",
    "date": "2025"
  },
  {
    "n": "ArtGuru FR",
    "u": "https://www.artguru.ai/fr",
    "c": "IA",
    "d": "Génération d'art IA (FR)",
    "date": "2025"
  },
  {
    "n": "DeepFiction",
    "u": "https://www.deepfiction.ai",
    "c": "IA",
    "d": "Génération de fiction par IA",
    "date": "2025"
  },
  {
    "n": "KlingAI Global",
    "u": "https://klingai.com/global",
    "c": "IA",
    "d": "Plateforme vidéo IA",
    "date": "2025"
  },
  {
    "n": "Leo AI FR",
    "u": "https://iamleo.ai/fr",
    "c": "IA",
    "d": "Assistant IA (FR)",
    "date": "2025"
  },
  {
    "n": "Luvvoice Voice Cloning FR",
    "u": "https://luvvoice.com/fr/voice-cloning",
    "c": "Musique et voix",
    "d": "Clonage de voix (FR)",
    "date": "2025"
  },
  {
    "n": "DescribePicture FR‑CA",
    "u": "https://describepicture.org/fr-CA",
    "c": "IA",
    "d": "Description d'images (FR‑CA)",
    "date": "2025"
  },
  {
    "n": "VideoMaker",
    "u": "https://videomaker.me",
    "c": "Vidéo et audio",
    "d": "Générateur vidéo",
    "date": "2025"
  },
  {
    "n": "JackTrip",
    "u": "https://www.jacktrip.com",
    "c": "Musique et voix",
    "d": "Audio à faible latence pour musique",
    "date": "2025"
  },
  {
    "n": "Luvvoice FR",
    "u": "https://luvvoice.com/fr",
    "c": "Musique et voix",
    "d": "Plateforme voix (FR)",
    "date": "2025"
  },
  {
    "n": "MakeSong FR",
    "u": "https://www.makesong.com/fr",
    "c": "Musique et voix",
    "d": "Générateur de chansons (FR)",
    "date": "2025"
  },
  {
    "n": "AI Music SO FR",
    "u": "https://aimusic.so/fr",
    "c": "Musique et voix",
    "d": "Générateur musique IA (FR)",
    "date": "2025"
  },
  {
    "n": "Suno",
    "u": "https://suno.com/home",
    "c": "Musique et voix",
    "d": "Générateur de musique IA",
    "date": "2025"
  },
  {
    "n": "Intelbase",
    "u": "https://intelbase.is",
    "c": "Recherches",
    "d": "Outils et base de données d'OSINT",
    "date": "2025"
  },
  {
    "n": "DeepL Translator FR",
    "u": "https://www.deepl.com/fr/translator",
    "c": "Utilitaires web",
    "d": "Traduction (FR)",
    "date": "2025"
  },
  {
    "n": "Wan Video (dup)",
    "u": "https://wan.video",
    "c": "Vidéo et audio",
    "d": "Outil vidéo IA (doublon)",
    "date": "2025"
  },
  {
    "n": "Wan 2.2",
    "u": "https://wan2-2.org",
    "c": "IA",
    "d": "Modèle vidéo IA Wan 2.2",
    "date": "2025"
  },
  {
    "n": "Meta DemoLab Sketch",
    "u": "https://sketch.metademolab.com",
    "c": "IA",
    "d": "Démonstrateur animation sketch",
    "date": "2025"
  },
  {
    "n": "Gambo AI",
    "u": "https://www.gambo.ai",
    "c": "IA",
    "d": "Plateforme IA",
    "date": "2025"
  },
  {
    "n": "FableAI App",
    "u": "https://fableai.app",
    "c": "IA",
    "d": "Application narration IA",
    "date": "2025"
  },
  {
    "n": "Showrunner",
    "u": "https://www.showrunner.xyz",
    "c": "IA",
    "d": "Génération de séries IA",
    "date": "2025"
  },
  {
    "n": "Gab AI Landing",
    "u": "https://gab.ai/landing",
    "c": "IA",
    "d": "Landing IA de Gab",
    "date": "2025"
  },
  {
    "n": "Spaces",
    "u": "https://huggingface.co/spaces",
    "c": "IA",
    "d": "Hugging Face Spaces",
    "date": "2025"
  },
  {
    "n": "Wan2.2 Animate",
    "u": "https://huggingface.co/spaces/Wan-AI/Wan2.2-Animate",
    "c": "IA",
    "d": "Espace Hugging Face Wan2.2 Animate",
    "date": "2025"
  },
  {
    "n": "AI QR Code Generator",
    "u": "https://huggingface.co/spaces/Oysiyl/AI-QR-code-generator",
    "c": "IA",
    "d": "Générateur de QR code IA",
    "date": "2025"
  },
  {
    "n": "HTML2PDF FR",
    "u": "https://html2pdf.com/fr",
    "c": "Utilitaires web",
    "d": "Conversion HTML vers PDF (FR)",
    "date": "2025"
  },
  {
    "n": "Vercel",
    "u": "https://vercel.com",
    "c": "Utilitaires web",
    "d": "Hébergement et déploiement frontend",
    "date": "2025"
  },
  {
    "n": "Turso",
    "u": "https://turso.tech",
    "c": "Utilitaires web",
    "d": "Base de données edge",
    "date": "2025"
  },
  {
    "n": "WhiteScreen",
    "u": "https://www.whitescreen.online",
    "c": "Utilitaires web",
    "d": "Écran blanc utilitaire",
    "date": "2025"
  },
  {
    "n": "dCode",
    "u": "https://www.dcode.fr",
    "c": "Apprentissage",
    "d": "Outils cryptographiques et codes",
    "date": "2025"
  },
  {
    "n": "Most Exclusive Website",
    "u": "https://mostexclusivewebsite.com",
    "c": "Utilitaires web",
    "d": "Site concept expérimental",
    "date": "2025"
  },
  {
    "n": "CDC EPHT",
    "u": "https://ephtracking.cdc.gov",
    "c": "Apprentissage",
    "d": "Suivi santé publique environnementale",
    "date": "2025"
  },
  {
    "n": "TinEye",
    "u": "https://tineye.com",
    "c": "Utilitaires web",
    "d": "Recherche inversée d'images",
    "date": "2025"
  },
  {
    "n": "Project Gutenberg",
    "u": "https://www.gutenberg.org",
    "c": "Apprentissage",
    "d": "Livres numériques gratuits",
    "date": "2025"
  },
  {
    "n": "Remove.bg FR",
    "u": "https://www.remove.bg/fr",
    "c": "Utilitaires web",
    "d": "Suppression de fond d'image (FR)",
    "date": "2025"
  },
  {
    "n": "Coolors",
    "u": "https://coolors.co",
    "c": "Utilitaires web",
    "d": "Générateur de palettes de couleurs",
    "date": "2025"
  },
  {
    "n": "Rome2Rio FR",
    "u": "https://www.rome2rio.com/fr",
    "c": "Utilitaires web",
    "d": "Planification trajets multimodaux (FR)",
    "date": "2025"
  },
  {
    "n": "10 Minute Mail FR",
    "u": "https://10minutemail.net/?lang=fr",
    "c": "Utilitaires web",
    "d": "E-mail temporaire (FR)",
    "date": "2025"
  },
  {
    "n": "Have I Been Pwned",
    "u": "https://haveibeenpwned.com",
    "c": "Utilitaires web",
    "d": "Vérification de fuites de données",
    "date": "2025"
  },
  {
    "n": "IsItDownRightNow",
    "u": "https://www.isitdownrightnow.com",
    "c": "Utilitaires web",
    "d": "Statut des sites web",
    "date": "2025"
  },
  {
    "n": "Downdetector CA",
    "u": "https://downdetector.ca",
    "c": "Utilitaires web",
    "d": "Suivi des pannes (CA)",
    "date": "2025"
  },
  {
    "n": "Down For Everyone Or Just Me",
    "u": "https://downforeveryoneorjustme.com",
    "c": "Utilitaires web",
    "d": "Statut site",
    "date": "2025"
  },
  {
    "n": "Neal.fun Deep Sea",
    "u": "https://neal.fun/deep-sea",
    "c": "Apprentissage",
    "d": "Exploration des profondeurs marines",
    "date": "2025"
  },
  {
    "n": "Geocachen Codes Secrets",
    "u": "https://geocachen.be/fr/codes-secrets-les-plus-utilises",
    "c": "Apprentissage",
    "d": "Codes secrets courants (FR)",
    "date": "2025"
  },
  {
    "n": "Gradio",
    "u": "https://www.gradio.app",
    "c": "IA",
    "d": "Framework UI pour modèles",
    "date": "2025"
  },
  {
    "n": "X-Minus AI FR",
    "u": "https://x-minus.pro/ai?locale=fr_FR",
    "c": "Musique et voix",
    "d": "Isolation voix/instruments (FR)",
    "date": "2025"
  },
  {
    "n": "Archive Buttons",
    "u": "https://www.archivebuttons.com",
    "c": "Utilitaires web",
    "d": "Boutons d'archive web",
    "date": "2025"
  },
  {
    "n": "RemovePaywall",
    "u": "https://www.removepaywall.com",
    "c": "Utilitaires web",
    "d": "Lecture d'articles verrouillés",
    "date": "2025"
  },
  {
    "n": "9xbuddy FR",
    "u": "https://9xbuddy.site/fr",
    "c": "Utilitaires web",
    "d": "Téléchargement de vidéos (FR)",
    "date": "2025"
  },
  {
    "n": "DynamicsLab Blog",
    "u": "https://blog.dynamicslab.ai",
    "c": "Apprentissage",
    "d": "Blog IA et dynamiques",
    "date": "2025"
  },
  {
    "n": "Lostgamer",
    "u": "https://lostgamer.io",
    "c": "Divers jeux/outils",
    "d": "Jeu d'identification de lieux",
    "date": "2025"
  },
  {
    "n": "MapGenie",
    "u": "https://mapgenie.io",
    "c": "Divers jeux/outils",
    "d": "Cartes pour jeux vidéo",
    "date": "2025"
  },
  {
    "n": "Temporel Inc (itch.io)",
    "u": "https://evilgiegue.itch.io/temporel-inc",
    "c": "Divers jeux/outils",
    "d": "Jeu hébergé sur itch.io",
    "date": "2025"
  },
  {
    "n": "WeMod FR",
    "u": "https://www.wemod.com/fr",
    "c": "Divers jeux/outils",
    "d": "Mods et trainers (FR)",
    "date": "2025"
  },
  {
    "n": "Keys.lol",
    "u": "https://keys.lol",
    "c": "Crypto/Web3",
    "d": "Exploration clés BTC publiques",
    "date": "2025"
  },
  {
    "n": "AllPrivateKeys Lucky",
    "u": "https://allprivatekeys.com/get-lucky",
    "c": "Crypto/Web3",
    "d": "Générateur chance clé privée",
    "date": "2025"
  },
  {
    "n": "AllPrivateKeys",
    "u": "https://allprivatekeys.com",
    "c": "Crypto/Web3",
    "d": "Base de données clés privées",
    "date": "2025"
  },
  {
    "n": "MyEtherWallet Access",
    "u": "https://www.myetherwallet.com/wallet/access",
    "c": "Crypto/Web3",
    "d": "Accès portefeuille Ethereum",
    "date": "2025"
  },
  {
    "n": "Coin360",
    "u": "https://coin360.com",
    "c": "Crypto/Web3",
    "d": "Carte thermique du marché crypto",
    "date": "2025"
  },
  {
    "n": "Etherscan",
    "u": "https://etherscan.io",
    "c": "Crypto/Web3",
    "d": "Explorateur blockchain Ethereum",
    "date": "2025"
  },
  {
    "n": "Blockchain Explorer",
    "u": "https://www.blockchain.com/explorer",
    "c": "Crypto/Web3",
    "d": "Explorateur blockchain multi-chaînes",
    "date": "2025"
  },
  {
    "n": "OpenSea",
    "u": "https://opensea.io",
    "c": "Crypto/Web3",
    "d": "Marketplace NFT",
    "date": "2025"
  },
  {
    "n": "Gala Games",
    "u": "https://games.gala.com",
    "c": "Crypto/Web3",
    "d": "Plateforme jeux Web3",
    "date": "2025"
  },
  {
    "n": "The Sandbox",
    "u": "https://www.sandbox.game/en",
    "c": "Crypto/Web3",
    "d": "Monde virtuel Web3",
    "date": "2025"
  },
  {
    "n": "Télécharger Freeware",
    "u": "https://telecharger-freeware.com",
    "c": "Téléchargements logiciels",
    "d": "Annuaire de freeware",
    "date": "2025"
  },
  {
    "n": "Gratuiciel",
    "u": "https://www.gratuiciel.com",
    "c": "Téléchargements logiciels",
    "d": "Annuaire logiciels gratuits",
    "date": "2025"
  },
  {
    "n": "NCH Software",
    "u": "https://www.nchsoftware.com",
    "c": "Téléchargements logiciels",
    "d": "Suite d'outils logiciels",
    "date": "2025"
  },
  {
    "n": "FileHippo",
    "u": "https://filehippo.com",
    "c": "Téléchargements logiciels",
    "d": "Répertoire de téléchargements",
    "date": "2025"
  },
  {
    "n": "Softpedia",
    "u": "https://www.softpedia.com",
    "c": "Téléchargements logiciels",
    "d": "Catalogue logiciels et news",
    "date": "2025"
  },
  {
    "n": "Clubic",
    "u": "https://www.clubic.com",
    "c": "Téléchargements logiciels",
    "d": "News tech et téléchargements",
    "date": "2025"
  },
  {
    "n": "TechSpot",
    "u": "https://www.techspot.com",
    "c": "Téléchargements logiciels",
    "d": "News et téléchargements tech",
    "date": "2025"
  },
  {
    "n": "Waretheque (HTTP)",
    "u": "http://www.waretheque.com",
    "c": "Téléchargements logiciels",
    "d": "Annuaire logiciels (HTTP)",
    "date": "2025"
  },
  {
    "n": "Logithèque",
    "u": "https://www.logitheque.com",
    "c": "Téléchargements logiciels",
    "d": "Répertoire de logiciels",
    "date": "2025"
  },
  {
    "n": "MajorGeeks",
    "u": "https://www.majorgeeks.com",
    "c": "Téléchargements logiciels",
    "d": "Répertoire logiciels Windows",
    "date": "2025"
  },
  {
    "n": "DownloadCrew",
    "u": "https://www.downloadcrew.com",
    "c": "Téléchargements logiciels",
    "d": "Sélection de logiciels",
    "date": "2025"
  },
  {
    "n": "FileHorse",
    "u": "https://www.filehorse.com",
    "c": "Téléchargements logiciels",
    "d": "Téléchargements logiciels",
    "date": "2025"
  },
  {
    "n": "FilePuma",
    "u": "https://www.filepuma.com",
    "c": "Téléchargements logiciels",
    "d": "Téléchargements logiciels",
    "date": "2025"
  },
  {
    "n": "SnapFiles",
    "u": "https://www.snapfiles.com",
    "c": "Téléchargements logiciels",
    "d": "Téléchargements logiciels",
    "date": "2025"
  },
  {
    "n": "Microsoft Apps",
    "u": "https://apps.microsoft.com",
    "c": "Téléchargements logiciels",
    "d": "Magasin d'applications Microsoft",
    "date": "2025"
  },
  {
    "n": "Ninite",
    "u": "https://ninite.com",
    "c": "Téléchargements logiciels",
    "d": "Installations groupées",
    "date": "2025"
  },
  {
    "n": "AnimeSalt PC",
    "u": "https://animesalt.org/pc",
    "c": "Téléchargements logiciels",
    "d": "Répertoire PC AnimeSalt",
    "date": "2025"
  },
  {
    "n": "Join PeerTube",
    "u": "https://joinpeertube.org",
    "c": "Vidéo et audio",
    "d": "Découvrir instances PeerTube",
    "date": "2025"
  },
  {
    "n": "OpenAI Sora FR",
    "u": "https://openai.com/fr-FR/sora",
    "c": "IA",
    "d": "Modèle vidéo Sora (FR)",
    "date": "2025"
  },
  {
    "n": "ClickUp",
    "u": "https://clickup.com",
    "c": "Utilitaires web",
    "d": "Gestion de projet",
    "date": "2025"
  },
  {
    "n": "TrustedHousesitters",
    "u": "https://www.trustedhousesitters.com",
    "c": "Utilitaires web",
    "d": "Gardiennage de maison",
    "date": "2025"
  },
  {
    "n": "GeoGuessr",
    "u": "https://www.geoguessr.com",
    "c": "Divers jeux/outils",
    "d": "Jeu de géolocalisation",
    "date": "2025"
  },
  {
    "n": "AnimeSalt",
    "u": "https://animesalt.org",
    "c": "Téléchargements logiciels",
    "d": "Répertoire AnimeSalt",
    "date": "2025"
  },
  {
    "n": "French-Stream",
    "u": "https://french-stream.one",
    "c": "Vidéo et audio",
    "d": "Streaming FR",
    "date": "2025"
  },
  {
    "n": "HDToday",
    "u": "https://hdtoday.cc/home",
    "c": "Vidéo et audio",
    "d": "Streaming films/séries",
    "date": "2025"
  },
  {
    "n": "BuzzMonClick",
    "u": "https://buzzmonclick.io",
    "c": "Réseaux sociaux et médias",
    "d": "Plateforme de contenus",
    "date": "2025"
  },
  {
    "n": "TV Garden",
    "u": "https://tv.garden",
    "c": "Vidéo et audio",
    "d": "TV en ligne",
    "date": "2025"
  },
  {
    "n": "MyRetroTVs",
    "u": "https://www.myretrotvs.com",
    "c": "Vidéo et audio",
    "d": "Chaînes TV rétro",
    "date": "2025"
  },
  {
    "n": "IHaveNoTV",
    "u": "https://ihavenotv.com",
    "c": "Vidéo et audio",
    "d": "Documentaires gratuits",
    "date": "2025"
  },
  {
    "n": "When Jumpscare",
    "u": "https://www.whenjumpscare.com",
    "c": "Divers jeux/outils",
    "d": "Références de jumpscares",
    "date": "2025"
  },
  {
    "n": "Radio.Garden",
    "u": "https://radio.garden",
    "c": "Vidéo et audio",
    "d": "Radio mondiale interactive",
    "date": "2025"
  },
  {
    "n": "MyNoise",
    "u": "https://mynoise.net",
    "c": "Vidéo et audio",
    "d": "Générateur d'ambiances sonores",
    "date": "2025"
  },
  {
    "n": "freeCodeCamp",
    "u": "https://www.freecodecamp.org",
    "c": "Apprentissage",
    "d": "Apprendre à coder gratuitement",
    "date": "2025"
  },
  {
    "n": "MindLuster",
    "u": "https://www.mindluster.com",
    "c": "Apprentissage",
    "d": "Cours en ligne gratuits",
    "date": "2025"
  },
  {
    "n": "Wolfram|Alpha",
    "u": "https://www.wolframalpha.com",
    "c": "Apprentissage",
    "d": "Moteur de connaissances computationnel",
    "date": "2025"
  },
  {
    "n": "LuxMedia",
    "u": "https://luxmedia.info",
    "c": "Réseaux sociaux et médias",
    "d": "Plateforme média",
    "date": "2025"
  },
  {
    "n": "Les 7 du Québec",
    "u": "https://les7duquebec.net",
    "c": "Réseaux sociaux et médias",
    "d": "Site d'opinion québécois",
    "date": "2025"
  },
  {
    "n": "ConspiracyWatch",
    "u": "https://www.conspiracywatch.info",
    "c": "Apprentissage",
    "d": "Observatoire des théories du complot",
    "date": "2025"
  },
  {
    "n": "Gab",
    "u": "https://gab.com/home",
    "c": "Réseaux sociaux et médias",
    "d": "Réseau social",
    "date": "2025"
  },
  {
    "n": "Facebook",
    "u": "https://www.facebook.com",
    "c": "Réseaux sociaux et médias",
    "d": "Réseau social",
    "date": "2025"
  },
  {
    "n": "X (Twitter)",
    "u": "https://x.com",
    "c": "Réseaux sociaux et médias",
    "d": "Réseau social",
    "date": "2025"
  },
  {
    "n": "500px",
    "u": "https://500px.com",
    "c": "Réseaux sociaux et médias",
    "d": "Plate-forme de partage photos",
    "date": "2025"
  },
  {
    "n": "Alertful",
    "u": "https://alertful.com",
    "c": "Utilitaires web",
    "d": "Rappels par e-mail",
    "date": "2025"
  },
  {
    "n": "Aviary",
    "u": "https://aviary.com",
    "c": "Utilitaires web",
    "d": "Éditeur photo en ligne",
    "date": "2025"
  },
  {
    "n": "Bitly",
    "u": "https://bitly.com",
    "c": "Utilitaires web",
    "d": "Raccourcir des URL",
    "date": "2025"
  },
  {
    "n": "Bubbl.us",
    "u": "https://bubbl.us",
    "c": "Utilitaires web",
    "d": "Brainstorming collaboratif",
    "date": "2025"
  },
  {
    "n": "CopyPasteCharacter",
    "u": "https://copypastecharacter.com",
    "c": "Utilitaires web",
    "d": "Caractères spéciaux",
    "date": "2025"
  },
  {
    "n": "CTRLQ RSS",
    "u": "https://ctrlq.org/rss",
    "c": "Utilitaires web",
    "d": "Recherche flux RSS",
    "date": "2025"
  },
  {
    "n": "CTRLQ Screenshots",
    "u": "https://ctrlq.org/screenshots",
    "c": "Utilitaires web",
    "d": "Captures page Web",
    "date": "2025"
  },
  {
    "n": "DaFont",
    "u": "https://www.dafont.com",
    "c": "Utilitaires web",
    "d": "Catalogue de polices",
    "date": "2025"
  },
  {
    "n": "DisposableWebpage",
    "u": "https://disposablewebpage.com",
    "c": "Utilitaires web",
    "d": "Pages auto-détruites",
    "date": "2025"
  },
  {
    "n": "Doodle",
    "u": "https://doodle.com",
    "c": "Utilitaires web",
    "d": "Planifier des réunions",
    "date": "2025"
  },
  {
    "n": "Dropbox",
    "u": "https://www.dropbox.com",
    "c": "Utilitaires web",
    "d": "Stockage et synchronisation",
    "date": "2025"
  },
  {
    "n": "e.ggTimer",
    "u": "https://e.ggtimer.com",
    "c": "Utilitaires web",
    "d": "Minuterie en ligne",
    "date": "2025"
  },
  {
    "n": "Evernote",
    "u": "https://evernote.com",
    "c": "Utilitaires web",
    "d": "Notes multi-appareils",
    "date": "2025"
  },
  {
    "n": "Every Time Zone",
    "u": "https://everytimezone.com",
    "c": "Utilitaires web",
    "d": "Fuseaux horaires",
    "date": "2025"
  },
  {
    "n": "FaxZero",
    "u": "https://faxzero.com",
    "c": "Utilitaires web",
    "d": "Fax gratuit",
    "date": "2025"
  },
  {
    "n": "FeedMyInbox",
    "u": "https://feedmyinbox.com",
    "c": "Utilitaires web",
    "d": "Flux RSS par e-mail",
    "date": "2025"
  },
  {
    "n": "Flickr",
    "u": "https://www.flickr.com",
    "c": "Réseaux sociaux et médias",
    "d": "Photos et vidéos",
    "date": "2025"
  },
  {
    "n": "FollowUpThen",
    "u": "https://www.followupthen.com",
    "c": "Utilitaires web",
    "d": "Rappels e-mail",
    "date": "2025"
  },
  {
    "n": "Ge.tt",
    "u": "https://ge.tt",
    "c": "Utilitaires web",
    "d": "Envoyer un fichier",
    "date": "2025"
  },
  {
    "n": "Pocket",
    "u": "https://getpocket.com",
    "c": "Utilitaires web",
    "d": "Sauvegarder à lire plus tard",
    "date": "2025"
  },
  {
    "n": "Google Drive",
    "u": "https://drive.google.com",
    "c": "Utilitaires web",
    "d": "Docs, feuilles, etc.",
    "date": "2025"
  },
  {
    "n": "GTmetrix",
    "u": "https://gtmetrix.com",
    "c": "Utilitaires web",
    "d": "Performance de sites",
    "date": "2025"
  },
  {
    "n": "Homestyler",
    "u": "https://homestyler.com",
    "c": "Utilitaires web",
    "d": "Maison 3D",
    "date": "2025"
  },
  {
    "n": "Iconfinder",
    "u": "https://iconfinder.com",
    "c": "Utilitaires web",
    "d": "Icônes",
    "date": "2025"
  },
  {
    "n": "Join.me",
    "u": "https://www.join.me",
    "c": "Utilitaires web",
    "d": "Partage d’écran",
    "date": "2025"
  },
  {
    "n": "Jotti",
    "u": "https://jotti.org",
    "c": "Utilitaires web",
    "d": "Scan antivirus",
    "date": "2025"
  },
  {
    "n": "VirusTotal",
    "u": "https://www.virustotal.com",
    "c": "Utilitaires web",
    "d": "Scan antivirus",
    "date": "2025"
  },
  {
    "n": "IFTTT",
    "u": "https://ifttt.com",
    "c": "Utilitaires web",
    "d": "Automatisations",
    "date": "2025"
  },
  {
    "n": "imo",
    "u": "https://imo.im",
    "c": "Utilitaires web",
    "d": "Chat multi-réseaux",
    "date": "2025"
  },
  {
    "n": "Kleki",
    "u": "https://kleki.com",
    "c": "Utilitaires web",
    "d": "Dessins et croquis",
    "date": "2025"
  },
  {
    "n": "Liveshare",
    "u": "https://liveshare.com",
    "c": "Utilitaires web",
    "d": "Partage instantané",
    "date": "2025"
  },
  {
    "n": "Livestream",
    "u": "https://livestream.com",
    "c": "Vidéo et audio",
    "d": "Événements en direct",
    "date": "2025"
  },
  {
    "n": "Mailvu",
    "u": "https://mailvu.com",
    "c": "Utilitaires web",
    "d": "Vidéo par e-mail",
    "date": "2025"
  },
  {
    "n": "Marker.to",
    "u": "https://marker.to",
    "c": "Utilitaires web",
    "d": "Surligner page web",
    "date": "2025"
  },
  {
    "n": "Midomi",
    "u": "https://www.midomi.com",
    "c": "Musique et voix",
    "d": "Trouver une chanson",
    "date": "2025"
  },
  {
    "n": "Minutes.io",
    "u": "https://minutes.io",
    "c": "Utilitaires web",
    "d": "Notes réunion",
    "date": "2025"
  },
  {
    "n": "Mixlr",
    "u": "https://mixlr.com",
    "c": "Vidéo et audio",
    "d": "Audio en direct",
    "date": "2025"
  },
  {
    "n": "WhatTheFont",
    "u": "https://www.myfonts.com/WhatTheFont",
    "c": "Utilitaires web",
    "d": "Identifier une police",
    "date": "2025"
  },
  {
    "n": "Noteflight",
    "u": "https://www.noteflight.com",
    "c": "Musique et voix",
    "d": "Partitions musicales",
    "date": "2025"
  },
  {
    "n": "Notes.io",
    "u": "https://notes.io",
    "c": "Utilitaires web",
    "d": "Notes rapides",
    "date": "2025"
  },
  {
    "n": "Oneload",
    "u": "https://oneload.com",
    "c": "Utilitaires web",
    "d": "Upload multi plateformes",
    "date": "2025"
  },
  {
    "n": "Otixo",
    "u": "https://www.otixo.com",
    "c": "Utilitaires web",
    "d": "Gestion multi-cloud",
    "date": "2025"
  },
  {
    "n": "Pancake.io",
    "u": "https://pancake.io",
    "c": "Utilitaires web",
    "d": "Site via Dropbox",
    "date": "2025"
  },
  {
    "n": "PDFescape",
    "u": "https://www.pdfescape.com",
    "c": "Utilitaires web",
    "d": "Éditer PDF en ligne",
    "date": "2025"
  },
  {
    "n": "PicMonkey",
    "u": "https://www.picmonkey.com",
    "c": "Utilitaires web",
    "d": "Retouche photo",
    "date": "2025"
  },
  {
    "n": "PipeBytes",
    "u": "https://www.pipebytes.com",
    "c": "Utilitaires web",
    "d": "Transfert P2P fichiers",
    "date": "2025"
  },
  {
    "n": "PrintWhatYouLike",
    "u": "https://www.printwhatyoulike.com",
    "c": "Utilitaires web",
    "d": "Impression ciblée",
    "date": "2025"
  },
  {
    "n": "Privnote",
    "u": "https://privnote.com",
    "c": "Utilitaires web",
    "d": "Notes auto-détruites",
    "date": "2025"
  },
  {
    "n": "Random.org",
    "u": "https://random.org",
    "c": "Utilitaires web",
    "d": "Tirages aléatoires",
    "date": "2025"
  },
  {
    "n": "Remember The Milk",
    "u": "https://rememberthemilk.com",
    "c": "Utilitaires web",
    "d": "Liste de tâches",
    "date": "2025"
  },
  {
    "n": "Norton SafeWeb",
    "u": "https://safeweb.norton.com",
    "c": "Utilitaires web",
    "d": "Analyse site",
    "date": "2025"
  },
  {
    "n": "Screenr",
    "u": "https://screenr.com",
    "c": "Vidéo et audio",
    "d": "Capture vidéo / YouTube",
    "date": "2025"
  },
  {
    "n": "Scribble Maps",
    "u": "https://www.scribblemaps.com",
    "c": "Cartes",
    "d": "Google Maps personnalisée",
    "date": "2025"
  },
  {
    "n": "Scr.im",
    "u": "https://scr.im",
    "c": "Utilitaires web",
    "d": "Partager e-mail sans spam",
    "date": "2025"
  },
  {
    "n": "SimilarSites",
    "u": "https://www.similarsites.com",
    "c": "Recherches",
    "d": "Sites similaires",
    "date": "2025"
  },
  {
    "n": "Stupeflix",
    "u": "https://www.stupeflix.com",
    "c": "Vidéo et audio",
    "d": "Montage vidéo express",
    "date": "2025"
  },
  {
    "n": "SumoPaint",
    "u": "https://www.sumopaint.com",
    "c": "Utilitaires web",
    "d": "Retouche photo en ligne",
    "date": "2025"
  },
  {
    "n": "FreeImages (ex sxc.hu)",
    "u": "https://www.freeimages.com",
    "c": "Utilitaires web",
    "d": "Images libres de droit",
    "date": "2025"
  },
  {
    "n": "TagMyDoc",
    "u": "https://tagmydoc.com",
    "c": "Utilitaires web",
    "d": "Accès instantané au doc",
    "date": "2025"
  },
  {
    "n": "TallTweets",
    "u": "https://talltweets.com",
    "c": "Utilitaires web",
    "d": "Tweets > 140 caractères",
    "date": "2025"
  },
  {
    "n": "Tinychat",
    "u": "https://tinychat.com",
    "c": "Réseaux sociaux et médias",
    "d": "Forum discussion privé",
    "date": "2025"
  },
  {
    "n": "Google Translate",
    "u": "https://translate.google.com",
    "c": "Utilitaires web",
    "d": "Traduction pages / docs",
    "date": "2025"
  },
  {
    "n": "Typing (ex typingweb)",
    "u": "https://www.typing.com",
    "c": "Apprentissage",
    "d": "Entraînement clavier",
    "date": "2025"
  },
  {
    "n": "WeTransfer",
    "u": "https://wetransfer.com",
    "c": "Utilitaires web",
    "d": "Partage gros fichiers",
    "date": "2025"
  },
  {
    "n": "WooRank",
    "u": "https://www.woorank.com",
    "c": "Utilitaires web",
    "d": "SEO site/blog",
    "date": "2025"
  },
  {
    "n": "Wordle.net",
    "u": "https://www.wordle.net",
    "c": "Utilitaires web",
    "d": "Nuage de mots-clés",
    "date": "2025"
  },
  {
    "n": "YouTube Disco",
    "u": "https://www.youtube.com/disco",
    "c": "Vidéo et audio",
    "d": "Playlist artiste",
    "date": "2025"
  },
  {
    "n": "Zoom.it",
    "u": "https://zoom.it",
    "c": "Utilitaires web",
    "d": "Zoom image HD",
    "date": "2025"
  },
  {
    "n": "Ministère de la Justice Québec",
    "u": "https://www.justice.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Ministère responsable de l'administration de la justice au Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Éducation Québec",
    "u": "https://www.education.gouv.qc.ca",
    "c": "Éducation",
    "d": "Gestion de l'éducation primaire, secondaire et collégiale au Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de la Santé et des Services sociaux",
    "u": "https://www.msss.gouv.qc.ca",
    "c": "Santé",
    "d": "Santé publique et services sociaux au Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de la Culture et des Communications",
    "u": "https://www.culture.gouv.qc.ca",
    "c": "Culture",
    "d": "Promotion de la culture et des communications québécoises",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Économie et de l'Innovation",
    "u": "https://www.economie.gouv.qc.ca",
    "c": "Commerce",
    "d": "Développement économique et innovation au Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Finances Québec",
    "u": "https://www.finances.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Gestion financière et fiscale du Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Relations internationales et de la Francophonie",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/relations-internationales-francophonie",
    "c": "Gouvernement",
    "d": "Relations internationales et promotion francophonie",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Environnement et de la Lutte contre les changements climatiques",
    "u": "https://www.environnement.gouv.qc.ca",
    "c": "Environnement",
    "d": "Protection environnement et climat Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Agriculture, des Pêcheries et de l'Alimentation",
    "u": "https://www.mapaq.gouv.qc.ca",
    "c": "Commerce",
    "d": "Agriculture et alimentation Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Transports",
    "u": "https://www.transports.gouv.qc.ca",
    "c": "Transport",
    "d": "Gestion transports et infrastructures Québec",
    "date": "2025"
  },
  {
    "n": "Ministère du Travail, de l'Emploi et de la Solidarité sociale",
    "u": "https://www.mtess.gouv.qc.ca",
    "c": "Emploi",
    "d": "Travail et solidarité sociale Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de la Famille",
    "u": "https://www.mfa.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Services à la famille et enfance Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Immigration, de la Francisation et de l'Intégration",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/immigration-francisation-integration",
    "c": "Gouvernement",
    "d": "Immigration et francisation Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Affaires municipales et de l'Habitation",
    "u": "https://www.mamh.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Affaires municipales et habitation Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de la Sécurité publique",
    "u": "https://www.securitepublique.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Sécurité publique Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Ressources naturelles et des Forêts",
    "u": "https://mffp.gouv.qc.ca",
    "c": "Environnement",
    "d": "Ressources naturelles et forêts Québec",
    "date": "2025"
  },
  {
    "n": "Ministère du Tourisme",
    "u": "https://www.tourisme.gouv.qc.ca",
    "c": "Tourisme",
    "d": "Promotion tourisme Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Énergie et des Ressources naturelles",
    "u": "https://mern.gouv.qc.ca",
    "c": "Environnement",
    "d": "Énergie et ressources Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Aînés et des Proches aidants",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/aines-proches-aidants",
    "c": "Santé",
    "d": "Soutien aînés Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Enseignement supérieur",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/enseignement-superieur",
    "c": "Éducation",
    "d": "Enseignement supérieur Québec",
    "date": "2025"
  },
  {
    "n": "Centre d'acquisitions gouvernementales",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/centre-acquisitions-gouvernementales",
    "c": "Gouvernement",
    "d": "Acquisitions gouvernementales Québec",
    "date": "2025"
  },
  {
    "n": "Centre de la francophonie des Amériques",
    "u": "https://www.francophoniedesameriques.com",
    "c": "Culture",
    "d": "Promotion francophonie Amériques",
    "date": "2025"
  },
  {
    "n": "Comité consultatif de lutte contre la pauvreté et l'exclusion sociale",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/comite-consultatif-lutte-contre-pauvrete-exclusion-sociale",
    "c": "Gouvernement",
    "d": "Lutte contre pauvreté Québec",
    "date": "2025"
  },
  {
    "n": "Comité consultatif sur l'accessibilité financière aux études",
    "u": "https://www.quebec.ca/gouvernement/ministere/enseignement-superieur/organismes-lies/comite-consultatif-sur-laccessibilite-financiere-aux-etudes-ccafe",
    "c": "Éducation",
    "d": "Accessibilité études Québec",
    "date": "2025"
  },
  {
    "n": "Comité consultatif sur les changements climatiques",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/comite-consultatif-changements-climatiques",
    "c": "Environnement",
    "d": "Changements climatiques Québec",
    "date": "2025"
  },
  {
    "n": "Commissaire à la lutte contre la corruption",
    "u": "https://upac.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Lutte corruption Québec",
    "date": "2025"
  },
  {
    "n": "Commissaire à la santé et au bien-être",
    "u": "https://www.csbe.gouv.qc.ca/accueil.html",
    "c": "Santé",
    "d": "Santé bien-être Québec",
    "date": "2025"
  },
  {
    "n": "Commission consultative de l’enseignement privé",
    "u": "https://www.quebec.ca/gouvernement/ministere/education/organismes-lies/commission-consultative-de-lenseignement-prive-ccep",
    "c": "Éducation",
    "d": "Enseignement privé Québec",
    "date": "2025"
  },
  {
    "n": "Commission d’accès à l’information",
    "u": "http://www.cai.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Accès information Québec",
    "date": "2025"
  },
  {
    "n": "Commission de la capitale nationale du Québec",
    "u": "http://www.capitale.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Capitale nationale Québec",
    "date": "2025"
  },
  {
    "n": "Commission de la fonction publique",
    "u": "http://www.cfp.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Fonction publique Québec",
    "date": "2025"
  },
  {
    "n": "Commission de la représentation électorale du Québec",
    "u": "https://www.electionsquebec.qc.ca/notre-institution/commission-de-la-representation-electorale",
    "c": "Gouvernement",
    "d": "Représentation électorale Québec",
    "date": "2025"
  },
  {
    "n": "Commission de l’éthique en science et en technologie",
    "u": "http://www.ethique.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Éthique science Québec",
    "date": "2025"
  },
  {
    "n": "Commission de protection du territoire agricole du Québec",
    "u": "http://www.cptaq.gouv.qc.ca",
    "c": "Environnement",
    "d": "Protection agricole Québec",
    "date": "2025"
  },
  {
    "n": "Commission des droits de la personne et des droits de la jeunesse",
    "u": "http://www.cdpdj.qc.ca",
    "c": "Gouvernement",
    "d": "Droits personne Québec",
    "date": "2025"
  },
  {
    "n": "Commission des partenaires du marché du travail",
    "u": "http://www.cpmt.gouv.qc.ca",
    "c": "Emploi",
    "d": "Marché travail Québec",
    "date": "2025"
  },
  {
    "n": "Commission des services juridiques",
    "u": "http://www.csj.qc.ca/commission-des-services-juridiques",
    "c": "Gouvernement",
    "d": "Services juridiques Québec",
    "date": "2025"
  },
  {
    "n": "Commission des transports du Québec",
    "u": "http://www.ctq.gouv.qc.ca",
    "c": "Transport",
    "d": "Transports Québec",
    "date": "2025"
  },
  {
    "n": "Commission de toponymie",
    "u": "http://www.toponymie.gouv.qc.ca",
    "c": "Culture",
    "d": "Toponymie Québec",
    "date": "2025"
  },
  {
    "n": "Commission d’évaluation de l’enseignement collégial",
    "u": "http://www.ceec.gouv.qc.ca",
    "c": "Éducation",
    "d": "Évaluation collégial Québec",
    "date": "2025"
  },
  {
    "n": "Commission municipale du Québec",
    "u": "http://www.cmq.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Municipale Québec",
    "date": "2025"
  },
  {
    "n": "Commission québécoise des libérations conditionnelles",
    "u": "https://www.cqlc.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Libérations conditionnelles Québec",
    "date": "2025"
  },
  {
    "n": "Conseil de gestion de l’assurance parentale",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-de-gestion-de-lassurance-parentale",
    "c": "Gouvernement",
    "d": "Assurance parentale Québec",
    "date": "2025"
  },
  {
    "n": "Conseil de la justice administrative",
    "u": "http://www.cja.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Justice administrative Québec",
    "date": "2025"
  },
  {
    "n": "Conseil de la magistrature",
    "u": "http://www.conseildelamagistrature.qc.ca",
    "c": "Gouvernement",
    "d": "Magistrature Québec",
    "date": "2025"
  },
  {
    "n": "Conseil des arts et des lettres du Québec",
    "u": "http://www.calq.gouv.qc.ca",
    "c": "Culture",
    "d": "Arts lettres Québec",
    "date": "2025"
  },
  {
    "n": "Conseil du patrimoine culturel du Québec",
    "u": "http://www.cpcq.gouv.qc.ca",
    "c": "Culture",
    "d": "Patrimoine culturel Québec",
    "date": "2025"
  },
  {
    "n": "Conseil du statut de la femme",
    "u": "http://www.csf.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Statut femme Québec",
    "date": "2025"
  },
  {
    "n": "Conseil supérieur de l’éducation",
    "u": "http://www.cse.gouv.qc.ca",
    "c": "Éducation",
    "d": "Éducation supérieure Québec",
    "date": "2025"
  },
  {
    "n": "Conservatoire de musique et d’art dramatique du Québec",
    "u": "http://www.conservatoire.gouv.qc.ca",
    "c": "Culture",
    "d": "Musique art dramatique Québec",
    "date": "2025"
  },
  {
    "n": "Corporation d’urgences-santé",
    "u": "http://www.urgences-sante.qc.ca",
    "c": "Santé",
    "d": "Urgences santé Québec",
    "date": "2025"
  },
  {
    "n": "Curateur public du Québec",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/curateur-public",
    "c": "Gouvernement",
    "d": "Curateur public Québec",
    "date": "2025"
  },
  {
    "n": "Directeur des poursuites criminelles et pénales",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/directeur-poursuites-criminelles-penales",
    "c": "Gouvernement",
    "d": "Poursuites criminelles Québec",
    "date": "2025"
  },
  {
    "n": "Santé Québec",
    "u": "https://www.sante.quebec",
    "c": "Santé",
    "d": "Santé Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la Capitale-Nationale",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-capitale-nationale",
    "c": "Gouvernement",
    "d": "Capitale nationale Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la communication gouvernementale",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-communication-gouvernementale",
    "c": "Gouvernement",
    "d": "Communication gouvernementale Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la condition féminine",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-condition-feminine",
    "c": "Gouvernement",
    "d": "Condition féminine Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la jeunesse",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-jeunesse",
    "c": "Gouvernement",
    "d": "Jeunesse Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la législation",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-legislation",
    "c": "Gouvernement",
    "d": "Législation Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la réforme des institutions démocratiques, à l'accès à l'information et à la laïcité",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/institutions-democratique-acces-information-laicite",
    "c": "Gouvernement",
    "d": "Réforme démocratique Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat à la sélection des candidats à la fonction de juge",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/justice/coordonnees-structure/secretariat-selection-candidats-fonction-juge",
    "c": "Gouvernement",
    "d": "Sélection juges Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat aux emplois supérieurs",
    "u": "http://www.emplois-superieurs.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Emplois supérieurs Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat aux priorités et aux projets stratégiques",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-priorites-projets-strategiques",
    "c": "Gouvernement",
    "d": "Priorités stratégiques Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat aux relations avec les Premières Nations et les Inuit",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-premieres-nations-inuit",
    "c": "Gouvernement",
    "d": "Relations autochtones Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat aux relations avec les Québécois d’expression anglaise",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-relations-quebecois-expression-anglaise",
    "c": "Gouvernement",
    "d": "Relations anglophones Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat du comité ministériel de l’économie et de l’environnement",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-comite-ministeriel-economie-environnement",
    "c": "Gouvernement",
    "d": "Économie environnement Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat du comité ministériel des services aux citoyens",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-comite-ministeriel-services-citoyens",
    "c": "Gouvernement",
    "d": "Services citoyens Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat du Conseil exécutif",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-conseil-executif",
    "c": "Gouvernement",
    "d": "Conseil exécutif Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat du Québec aux relations canadiennes",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/secretariat-relations-canadiennes",
    "c": "Gouvernement",
    "d": "Relations canadiennes Québec",
    "date": "2025"
  },
  {
    "n": "Secrétariat général, coordination gouvernementale et administration",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-executif/mission-services/mission-mandats/secretariat-general-coordination-gouvernementale-administration",
    "c": "Gouvernement",
    "d": "Coordination gouvernementale Québec",
    "date": "2025"
  },
  {
    "n": "Société de développement de la Baie James",
    "u": "http://www.sdbj.gouv.qc.ca",
    "c": "Commerce",
    "d": "Développement Baie James Québec",
    "date": "2025"
  },
  {
    "n": "Société de développement des entreprises culturelles",
    "u": "http://www.sodec.gouv.qc.ca",
    "c": "Culture",
    "d": "Entreprises culturelles Québec",
    "date": "2025"
  },
  {
    "n": "Société de financement des infrastructures locales du Québec",
    "u": "http://www.sofil.gouv.qc.ca",
    "c": "Commerce",
    "d": "Financement infrastructures Québec",
    "date": "2025"
  },
  {
    "n": "Société de l’assurance automobile du Québec",
    "u": "http://www.saaq.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Assurance automobile Québec",
    "date": "2025"
  },
  {
    "n": "Société de protection des forêts contre le feu",
    "u": "https://sopfeu.qc.ca",
    "c": "Environnement",
    "d": "Protection feux forêts Québec",
    "date": "2025"
  },
  {
    "n": "Société des alcools du Québec",
    "u": "https://www.saq.com",
    "c": "Commerce",
    "d": "Vente alcools Québec",
    "date": "2025"
  },
  {
    "n": "Société des établissements de plein air du Québec",
    "u": "http://www.sepaq.com",
    "c": "Culture",
    "d": "Plein air Québec",
    "date": "2025"
  },
  {
    "n": "Société des Traversiers du Québec",
    "u": "http://www.traversiers.com/fr/accueil",
    "c": "Transport",
    "d": "Traversiers Québec",
    "date": "2025"
  },
  {
    "n": "Société de télédiffusion du Québec",
    "u": "http://www.telequebec.tv",
    "c": "Culture",
    "d": "Télédiffusion Québec",
    "date": "2025"
  },
  {
    "n": "Société d’habitation du Québec",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/societe-habitation",
    "c": "Gouvernement",
    "d": "Habitation Québec",
    "date": "2025"
  },
  {
    "n": "Société d'habitation et de développement de Montréal",
    "u": "https://www.shdm.org",
    "c": "Gouvernement",
    "d": "Habitation Montréal Québec",
    "date": "2025"
  },
  {
    "n": "Société du Centre des congrès de Québec",
    "u": "http://www.convention.qc.ca",
    "c": "Commerce",
    "d": "Congrès Québec",
    "date": "2025"
  },
  {
    "n": "Société du Grand Théâtre de Québec",
    "u": "http://www.grandtheatre.qc.ca",
    "c": "Culture",
    "d": "Théâtre Québec",
    "date": "2025"
  },
  {
    "n": "Société du parc industriel et portuaire de Bécancour",
    "u": "http://www.spipb.com",
    "c": "Commerce",
    "d": "Parc industriel Bécancour Québec",
    "date": "2025"
  },
  {
    "n": "Société du Plan Nord",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/societe-plan-nord",
    "c": "Gouvernement",
    "d": "Plan Nord Québec",
    "date": "2025"
  },
  {
    "n": "Société québécoise des infrastructures",
    "u": "http://www.sqi.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Infrastructures Québec",
    "date": "2025"
  },
  {
    "n": "Société québécoise d’information juridique",
    "u": "http://soquij.qc.ca",
    "c": "Gouvernement",
    "d": "Information juridique Québec",
    "date": "2025"
  },
  {
    "n": "Sûreté du Québec",
    "u": "https://www.sq.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Police Québec",
    "date": "2025"
  },
  {
    "n": "Vérificateur général du Québec",
    "u": "https://www.vgq.qc.ca",
    "c": "Gouvernement",
    "d": "Vérification générale Québec",
    "date": "2025"
  },
  {
    "n": "Acadie Nouvelle",
    "u": "http://www.acadienouvelle.com",
    "c": "Médias",
    "d": "Journal francophone Acadie",
    "date": "2025"
  },
  {
    "n": "Franco.ca",
    "u": "http://franco.ca",
    "c": "Médias",
    "d": "Portail actualité francophone Canada",
    "date": "2025"
  },
  {
    "n": "Francopresse",
    "u": "https://francopresse.ca",
    "c": "Médias",
    "d": "Agence presse français Canada",
    "date": "2025"
  },
  {
    "n": "Journal L'Aquilon",
    "u": "http://www.aquilon.nt.ca",
    "c": "Médias",
    "d": "Hebdo francophone Territoires Nord-Ouest",
    "date": "2025"
  },
  {
    "n": "Le Franco",
    "u": "https://lefranco.ab.ca",
    "c": "Médias",
    "d": "Journal franco-albertain",
    "date": "2025"
  },
  {
    "n": "Le Gaboteur",
    "u": "http://www.gaboteur.ca",
    "c": "Médias",
    "d": "Journal francophone Terre-Neuve-Labrador",
    "date": "2025"
  },
  {
    "n": "Revue scientifique virtuelle Éducation et francophonie",
    "u": "https://www.erudit.org/fr/revues/ef/#back-issues",
    "c": "Médias",
    "d": "Revue éducation francophone",
    "date": "2025"
  },
  {
    "n": "ACCENT",
    "u": "http://www.accentalberta.ca/index.php",
    "c": "Culture",
    "d": "Répertoire activités culturelles francophones Alberta",
    "date": "2025"
  },
  {
    "n": "ACCENT sur le patrimoine",
    "u": "http://accent-patrimoine.ca",
    "c": "Culture",
    "d": "Origines francophonie Alberta",
    "date": "2025"
  },
  {
    "n": "Alliance française d’Edmonton",
    "u": "https://www.afedmonton.com",
    "c": "Culture",
    "d": "Promotion culture francophone",
    "date": "2025"
  },
  {
    "n": "Assemblée communautaire fransaskoise",
    "u": "http://www.fransaskois.sk.ca",
    "c": "Culture",
    "d": "Représentation francophone Saskatchewan",
    "date": "2025"
  },
  {
    "n": "Association canadienne-française de l'Alberta",
    "u": "http://www.acfa.ab.ca",
    "c": "Culture",
    "d": "Promotion français Alberta",
    "date": "2025"
  },
  {
    "n": "Association canadienne-française de l'Alberta régionale de Calgary",
    "u": "http://www.acfa.ab.ca/calgary/?url=accueil",
    "c": "Culture",
    "d": "Section régionale Calgary",
    "date": "2025"
  },
  {
    "n": "Association canadienne-française de l’Alberta régionale de Grande-Prairie",
    "u": "https://www.acfa.ab.ca/grandeprairie",
    "c": "Culture",
    "d": "Section régionale Grande-Prairie",
    "date": "2025"
  },
  {
    "n": "Centre culturel franco-manitobain",
    "u": "http://ccfm.mb.ca",
    "c": "Culture",
    "d": "Centre culturel Manitoba",
    "date": "2025"
  },
  {
    "n": "Congrès annuel de la francophonie albertaine",
    "u": "https://acfa.ab.ca/evenement/congres-annuel-de-la-francophonie-albertaine",
    "c": "Culture",
    "d": "Événement annuel francophonie Alberta",
    "date": "2025"
  },
  {
    "n": "Fédération des aînés franco-albertains",
    "u": "https://fafalta.ca",
    "c": "Culture",
    "d": "Fédération aînés francophones Alberta",
    "date": "2025"
  },
  {
    "n": "Fédération du sport francophone de l’Alberta",
    "u": "http://www.lafsfa.ca",
    "c": "Culture",
    "d": "Sport francophone Alberta",
    "date": "2025"
  },
  {
    "n": "Francophonie Calgary",
    "u": "http://www.acfa.ab.ca/francophoniecalgary/?url=accueil",
    "c": "Culture",
    "d": "Initiative francophone Calgary",
    "date": "2025"
  },
  {
    "n": "Francophonie jeunesse de l'Alberta",
    "u": "http://fja.ab.ca",
    "c": "Culture",
    "d": "Programme jeunesse francophone Alberta",
    "date": "2025"
  },
  {
    "n": "La Cité francophone",
    "u": "https://www.lacitefranco.ca",
    "c": "Culture",
    "d": "Ressources francophones",
    "date": "2025"
  },
  {
    "n": "Portail de l’Immigrant Association (PIA)",
    "u": "https://pia-calgary.ca",
    "c": "Culture",
    "d": "Soutien immigrants francophones Calgary",
    "date": "2025"
  },
  {
    "n": "Secrétariat aux affaires francophones du Manitoba",
    "u": "http://www.gov.mb.ca/fls-slf/intro.fr.html",
    "c": "Culture",
    "d": "Affaires francophones Manitoba",
    "date": "2025"
  },
  {
    "n": "Société canadienne-française de Prince-Albert",
    "u": "https://www.scfpa.net",
    "c": "Culture",
    "d": "Société francophone Prince-Albert",
    "date": "2025"
  },
  {
    "n": "Société franco-manitobaine",
    "u": "http://www.sfm.mb.ca",
    "c": "Culture",
    "d": "Promotion culture francophone Manitoba",
    "date": "2025"
  },
  {
    "n": "Ministère du Patrimoine canadien",
    "u": "https://www.canada.ca/fr/patrimoine-canadien.html",
    "c": "Gouvernement",
    "d": "Soutien financier publications francophones",
    "date": "2025"
  },
  {
    "n": "Conseil des Arts du Canada",
    "u": "https://conseildesarts.ca",
    "c": "Gouvernement",
    "d": "Soutien arts francophones",
    "date": "2025"
  },
  {
    "n": "Société de développement des entreprises culturelles du Québec (SODEC)",
    "u": "http://www.sodec.gouv.qc.ca",
    "c": "Culture",
    "d": "Soutien entreprises culturelles Québec",
    "date": "2025"
  },
  {
    "n": "Bibliothèque nationale du Canada",
    "u": "https://www.bac-lac.gc.ca",
    "c": "Gouvernement",
    "d": "Catalogage publications francophones",
    "date": "2025"
  },
  {
    "n": "Bibliothèque nationale du Québec",
    "u": "https://www.banq.qc.ca",
    "c": "Gouvernement",
    "d": "Dépôt légal Québec",
    "date": "2025"
  },
  {
    "n": "École nationale d'administration publique (ENAP)",
    "u": "https://enap.ca",
    "c": "Gouvernement",
    "d": "Conseils administration publique",
    "date": "2025"
  },
  {
    "n": "Conseil supérieur de l'éducation",
    "u": "http://www.cse.gouv.qc.ca",
    "c": "Éducation",
    "d": "Conseils éducation",
    "date": "2025"
  },
  {
    "n": "Conseil de la santé et du bien-être du Québec",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/conseil-sante-bien-etre",
    "c": "Santé",
    "d": "Conseils santé",
    "date": "2025"
  },
  {
    "n": "Centre d'analyse des politiques publiques (CAPP)",
    "u": "https://capp.ulaval.ca",
    "c": "Gouvernement",
    "d": "Analyse politiques publiques",
    "date": "2025"
  },
  {
    "n": "Centre de recherche interuniversitaire sur la formation et la profession enseignante (CRIFPE)",
    "u": "https://www.crifpe.ca",
    "c": "Éducation",
    "d": "Recherches formation enseignement",
    "date": "2025"
  },
  {
    "n": "Centre de recherche interuniversitaire sur la littérature et la culture québécoises (CRILCQ)",
    "u": "https://www.crilcq.org",
    "c": "Culture",
    "d": "Recherches littérature culture québécoises",
    "date": "2025"
  },
  {
    "n": "Centre d'études sur les médias (CEM)",
    "u": "https://cem.ulaval.ca",
    "c": "Culture",
    "d": "Études médias",
    "date": "2025"
  },
  {
    "n": "Centre interdisciplinaire de recherches sur la science et la technologie (CIRST)",
    "u": "https://www.cirst.uqam.ca",
    "c": "Éducation",
    "d": "Recherches science technologie",
    "date": "2025"
  },
  {
    "n": "Institut de recherche en politiques publiques (IRPP)",
    "u": "https://irpp.org",
    "c": "Gouvernement",
    "d": "Recherches politiques publiques",
    "date": "2025"
  },
  {
    "n": "Institut national de la recherche scientifique (INRS)",
    "u": "https://inrs.ca",
    "c": "Éducation",
    "d": "Recherches scientifiques",
    "date": "2025"
  },
  {
    "n": "Urbanisation, Culture et Société",
    "u": "https://ucs.inrs.ca",
    "c": "Culture",
    "d": "Études urbanisation culture",
    "date": "2025"
  },
  {
    "n": "Observatoire Jeunes et Société",
    "u": "https://www.jeunesetmedia.ca",
    "c": "Éducation",
    "d": "Études jeunes société",
    "date": "2025"
  },
  {
    "n": "Réseau Villes Régions Monde",
    "u": "https://vrm.ca",
    "c": "Gouvernement",
    "d": "Études régions villes",
    "date": "2025"
  },
  {
    "n": "Revue Inroads",
    "u": "https://inroadsjournal.ca",
    "c": "Culture",
    "d": "Références bibliographiques",
    "date": "2025"
  },
  {
    "n": "Association internationale des études québécoises (AIEQ)",
    "u": "https://aieq.net",
    "c": "Culture",
    "d": "Études québécoises internationales",
    "date": "2025"
  },
  {
    "n": "Ministère du Développement économique et régional du Québec",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/developpement-economique-regional",
    "c": "Gouvernement",
    "d": "Données économiques régionales",
    "date": "2025"
  },
  {
    "n": "Emploi-Québec",
    "u": "https://www.quebec.ca/gouvernement/ministeres-organismes/emploi-quebec",
    "c": "Emploi",
    "d": "Carrières prometteuses",
    "date": "2025"
  },
  {
    "n": "Entreprises Canada",
    "u": "https://www.entreprisescanada.ca/gol/cbec/site.nsf/fr/index.html",
    "c": "Commerce",
    "d": "Informations entreprises canadiennes",
    "date": "2025"
  },
  {
    "n": "Ministère de la Citoyenneté et de l'Immigration Canada",
    "u": "https://www.cic.gc.ca",
    "c": "Gouvernement",
    "d": "Immigration visas permis Canada",
    "date": "2025"
  },
  {
    "n": "Secrétariat du Conseil du Trésor du Canada",
    "u": "https://www.tbs-sct.gc.ca",
    "c": "Gouvernement",
    "d": "Gestion ressources gouvernementales Canada",
    "date": "2025"
  },
  {
    "n": "Services Canada",
    "u": "https://www.servicescanada.gc.ca",
    "c": "Gouvernement",
    "d": "Renseignements services Canada",
    "date": "2025"
  },
  {
    "n": "Associations des Universités et Collèges du Canada",
    "u": "https://www.aucc.ca",
    "c": "Éducation",
    "d": "Universités collèges Canada",
    "date": "2025"
  },
  {
    "n": "Le Centre de Recherche pour le Développement International",
    "u": "https://www.idrc.ca/fr/ev-29572-201-1-DO_TOPIC.html",
    "c": "Éducation",
    "d": "Sites universités canadiennes internationalisation",
    "date": "2025"
  },
  {
    "n": "THOT",
    "u": "https://thot.cursus.edu/rubrique.asp?no=16345",
    "c": "Éducation",
    "d": "Répertoire e-formation francophone",
    "date": "2025"
  },
  {
    "n": "Université d'Ottawa",
    "u": "https://www.crccf.uottawa.ca",
    "c": "Éducation",
    "d": "Centre Recherche Civilisation Canadienne-Française",
    "date": "2025"
  },
  {
    "n": "Wikipédia : Liste des universités du Canada",
    "u": "https://fr.wikipedia.org/wiki/Liste_des_universit%c3%A9s_du_Canada",
    "c": "Éducation",
    "d": "Liste universités Canada",
    "date": "2025"
  },
  {
    "n": "kelformation",
    "u": "https://www.kelformation.com",
    "c": "Éducation",
    "d": "Moteur recherche formation",
    "date": "2025"
  },
  {
    "n": "Site d'information générale pour l'enseignement post-secondaire",
    "u": "https://www.nlimmigration.ca/vivre-ici/enseignement-postsecondaire.aspx",
    "c": "Éducation",
    "d": "Information enseignement post-secondaire",
    "date": "2025"
  },
  {
    "n": "Association internationale des études québécoises (AIEQ)",
    "u": "https://aieq.qc.ca",
    "c": "Culture",
    "d": "Promotion études québécoises dans le monde",
    "date": "2025"
  },
  {
    "n": "Fédération Histoire Québec",
    "u": "https://federationhistoirequebec.ca",
    "c": "Culture",
    "d": "Réseau sociétés histoire et patrimoine",
    "date": "2025"
  },
  {
    "n": "Société des musées du Québec",
    "u": "https://smq.qc.ca",
    "c": "Culture",
    "d": "Réseau muséal québécois",
    "date": "2025"
  },
  {
    "n": "Réseau des organismes culturels de Montréal",
    "u": "https://rocm.ca",
    "c": "Culture",
    "d": "Regroupement organismes culturels Montréal",
    "date": "2025"
  },
  {
    "n": "Culture Montréal",
    "u": "https://culturemontreal.ca",
    "c": "Culture",
    "d": "Défense et promotion culture Montréal",
    "date": "2025"
  },
  {
    "n": "Les Arts et la Ville",
    "u": "https://arts-ville.org",
    "c": "Culture",
    "d": "Culture en milieu municipal Québec",
    "date": "2025"
  },
  {
    "n": "Conseil québécois du patrimoine vivant",
    "u": "https://patrimoinevivant.qc.ca",
    "c": "Culture",
    "d": "Traditions et patrimoine immatériel",
    "date": "2025"
  },
  {
    "n": "Regroupement des arts de rue du Québec",
    "u": "https://rarrq.com",
    "c": "Culture",
    "d": "Arts de rue et cirque",
    "date": "2025"
  },
  {
    "n": "Regroupement des centres d’artistes autogérés du Québec",
    "u": "https://rcaaq.org",
    "c": "Culture",
    "d": "Art actuel et diffusion",
    "date": "2025"
  },
  {
    "n": "En Piste - Regroupement national des arts du cirque",
    "u": "https://enpiste.qc.ca",
    "c": "Culture",
    "d": "Cirque contemporain Québec",
    "date": "2025"
  },
  {
    "n": "Théâtre à l’affiche",
    "u": "https://theatrealaffich.com",
    "c": "Culture",
    "d": "Répertoire théâtral Québec",
    "date": "2025"
  },
  {
    "n": "Association des théâtres francophones du Canada",
    "u": "https://atfc.ca",
    "c": "Culture",
    "d": "Théâtre francophone hors Québec",
    "date": "2025"
  },
  {
    "n": "Réseau des grands espaces",
    "u": "https://grandsespaces.ca",
    "c": "Culture",
    "d": "Salles de spectacles Québec",
    "date": "2025"
  },
  {
    "n": "Scènes de musique alternative Québec",
    "u": "https://smaq.qc.ca",
    "c": "Culture",
    "d": "Musique émergente réseau",
    "date": "2025"
  },
  {
    "n": "Regroupement des festivals régionaux artistiques",
    "u": "https://refraquebec.ca",
    "c": "Culture",
    "d": "Festivals régionaux Québec",
    "date": "2025"
  },
  {
    "n": "Fédération culturelle canadienne-française",
    "u": "https://fccf.ca",
    "c": "Culture",
    "d": "Francophonie culturelle canadienne",
    "date": "2025"
  },
  {
    "n": "Alliance des radios communautaires du Canada",
    "u": "https://arcq.qc.ca",
    "c": "Médias",
    "d": "Radios communautaires francophones",
    "date": "2025"
  },
  {
    "n": "Association de la presse francophone",
    "u": "https://apf.ca",
    "c": "Médias",
    "d": "Journaux francophones hors Québec",
    "date": "2025"
  },
  {
    "n": "Regroupement des éditeurs franco-canadiens",
    "u": "https://refc.ca",
    "c": "Culture",
    "d": "Édition francophonie canadienne",
    "date": "2025"
  },
  {
    "n": "Fédération des communautés francophones et acadienne",
    "u": "https://fcfa.ca",
    "c": "Culture",
    "d": "Représentation francophonie Canada",
    "date": "2025"
  },
  {
    "n": "Office national du film du Canada",
    "u": "https://www.onf.ca",
    "c": "Culture",
    "d": "Production documentaire et animation",
    "date": "2025"
  },
  {
    "n": "Téléfilm Canada",
    "u": "https://telefilm.ca",
    "c": "Culture",
    "d": "Financement cinéma et télévision",
    "date": "2025"
  },
  {
    "n": "SODEC",
    "u": "https://sodec.gouv.qc.ca",
    "c": "Culture",
    "d": "Société développement entreprises culturelles",
    "date": "2025"
  },
  {
    "n": "Conseil des arts et des lettres du Québec",
    "u": "https://www.calq.gouv.qc.ca",
    "c": "Culture",
    "d": "Subventions arts et lettres",
    "date": "2025"
  },
  {
    "n": "Conseil des arts de Montréal",
    "u": "https://artsmontreal.org",
    "c": "Culture",
    "d": "Soutien arts Montréal",
    "date": "2025"
  },
  {
    "n": "Fonds de recherche du Québec",
    "u": "https://frq.gouv.qc.ca",
    "c": "Éducation",
    "d": "Recherche scientifique et société",
    "date": "2025"
  },
  {
    "n": "Mitacs Québec",
    "u": "https://www.mitacs.ca/fr",
    "c": "Éducation",
    "d": "Stages recherche partenariats",
    "date": "2025"
  },
  {
    "n": "IVADO",
    "u": "https://ivado.ca",
    "c": "Technologie",
    "d": "Institut intelligence artificielle Montréal",
    "date": "2025"
  },
  {
    "n": "Mila - Institut québécois d’IA",
    "u": "https://mila.quebec",
    "c": "Technologie",
    "d": "Recherche fondamentale IA",
    "date": "2025"
  },
  {
    "n": "Centech",
    "u": "https://centech.co",
    "c": "Technologie",
    "d": "Accélérateur ÉTS",
    "date": "2025"
  },
  {
    "n": "District 3 Concordia",
    "u": "https://d3center.ca",
    "c": "Technologie",
    "d": "Innovation et entrepreneuriat",
    "date": "2025"
  },
  {
    "n": "Zú",
    "u": "https://zu.is",
    "c": "Technologie",
    "d": "Industrie du divertissement",
    "date": "2025"
  },
  {
    "n": "MT Lab",
    "u": "https://mtlab.ca",
    "c": "Technologie",
    "d": "Incubateur tourisme culture",
    "date": "2025"
  },
  {
    "n": "Real Ventures",
    "u": "https://realventures.com",
    "c": "Technologie",
    "d": "Capital-risque Montréal",
    "date": "2025"
  },
  {
    "n": "Inovia Capital",
    "u": "https://inovia.vc",
    "c": "Technologie",
    "d": "Fonds croissance tech",
    "date": "2025"
  },
  {
    "n": "Scale AI",
    "u": "https://scaleai.ca",
    "c": "Technologie",
    "d": "Supercluster intelligence artificielle",
    "date": "2025"
  },
  {
    "n": "Montréal International",
    "u": "https://www.montrealinternational.com",
    "c": "Commerce",
    "d": "Attractivité Grand Montréal",
    "date": "2025"
  },
  {
    "n": "Investissement Québec",
    "u": "https://www.investquebec.com",
    "c": "Commerce",
    "d": "Investissement entreprises",
    "date": "2025"
  },
  {
    "n": "Fonds de solidarité FTQ",
    "u": "https://www.fondsftq.com",
    "c": "Commerce",
    "d": "Fonds travailleurs Québec",
    "date": "2025"
  },
  {
    "n": "Desjardins Capital",
    "u": "https://www.desjardinscapital.com",
    "c": "Commerce",
    "d": "Capital-risque coopératif",
    "date": "2025"
  },
  {
    "n": "Bonjour Startup Montréal",
    "u": "https://bonjourstartupmtl.com",
    "c": "Technologie",
    "d": "Écosystème startup Montréal",
    "date": "2025"
  },
  {
    "n": "Startup Québec",
    "u": "https://startupquebec.org",
    "c": "Technologie",
    "d": "Réseau provincial startups",
    "date": "2025"
  },
  {
    "n": "TechnoMontréal",
    "u": "https://technomontreal.com",
    "c": "Technologie",
    "d": "Cluster technologies information",
    "date": "2025"
  },
  {
    "n": "Finance Montréal",
    "u": "https://www.finance-montreal.com",
    "c": "Commerce",
    "d": "Pôle financier Québec",
    "date": "2025"
  },
  {
    "n": "CargoM",
    "u": "https://cargom.com",
    "c": "Commerce",
    "d": "Logistique Grand Montréal",
    "date": "2025"
  },
  {
    "n": "Aéro Montréal",
    "u": "https://www.aeromontreal.ca",
    "c": "Commerce",
    "d": "Cluster aérospatial Québec",
    "date": "2025"
  },
  {
    "n": "Montréal InVivo",
    "u": "https://www.montreal-invivo.com",
    "c": "Santé",
    "d": "Sciences vie santé Montréal",
    "date": "2025"
  },
  {
    "n": "MEDTEQ+",
    "u": "https://medteq.ca",
    "c": "Santé",
    "d": "Technologies médicales Québec",
    "date": "2025"
  },
  {
    "n": "Tourisme Montréal",
    "u": "https://www.mtl.org",
    "c": "Tourisme",
    "d": "Office tourisme Montréal",
    "date": "2025"
  },
  {
    "n": "Bonjour Québec",
    "u": "https://www.quebecoriginal.com",
    "c": "Tourisme",
    "d": "Tourisme officiel Québec",
    "date": "2025"
  },
  {
    "n": "Alliance de l’industrie touristique du Québec",
    "u": "https://allianceindustrie.com",
    "c": "Tourisme",
    "d": "Regroupement touristique Québec",
    "date": "2025"
  },
  {
    "n": "Fédération des pourvoiries du Québec",
    "u": "https://pourvoiries.com",
    "c": "Tourisme",
    "d": "Chasse pêche Québec",
    "date": "2025"
  },
  {
    "n": "Aventure Écotourisme Québec",
    "u": "https://aventure-ecotourisme.qc.ca",
    "c": "Tourisme",
    "d": "Tourisme d’aventure",
    "date": "2025"
  },
  {
    "n": "Chambre de commerce du Montréal métropolitain",
    "u": "https://ccmm.ca",
    "c": "Commerce",
    "d": "Plus grande chambre commerce Québec",
    "date": "2025"
  },
  {
    "n": "Fédération des chambres de commerce du Québec",
    "u": "https://fccq.ca",
    "c": "Commerce",
    "d": "Réseau provincial chambres commerce",
    "date": "2025"
  },
  {
    "n": "MEQ - Manufacturiers et Exportateurs Québec",
    "u": "https://meq.ca",
    "c": "Commerce",
    "d": "Industrie manufacturière Québec",
    "date": "2025"
  },
  {
    "n": "Conseil du patronat du Québec",
    "u": "https://cpq.qc.ca",
    "c": "Commerce",
    "d": "Regroupement employeurs Québec",
    "date": "2025"
  },
  {
    "n": "Hydro-Québec",
    "u": "https://www.hydroquebec.com",
    "c": "Énergie",
    "d": "Production distribution électricité Québec",
    "date": "2025"
  },
  {
    "n": "Énergir",
    "u": "https://www.energir.com",
    "c": "Énergie",
    "d": "Distribution gaz naturel Québec",
    "date": "2025"
  },
  {
    "n": "Bombardier",
    "u": "https://bombardier.com",
    "c": "Commerce",
    "d": "Avions d’affaires et trains",
    "date": "2025"
  },
  {
    "n": "CAE",
    "u": "https://www.cae.com",
    "c": "Commerce",
    "d": "Simulation aviation mondiale",
    "date": "2025"
  },
  {
    "n": "CGI",
    "u": "https://www.cgi.com",
    "c": "Technologie",
    "d": "Services TI mondial",
    "date": "2025"
  },
  {
    "n": "Cirque du Soleil",
    "u": "https://www.cirquedusoleil.com",
    "c": "Culture",
    "d": "Cirque contemporain Montréal",
    "date": "2025"
  },
  {
    "n": "Ubisoft Montréal",
    "u": "https://montreal.ubisoft.com",
    "c": "Technologie",
    "d": "Jeux vidéo AAA",
    "date": "2025"
  },
  {
    "n": "Warner Bros Games Montréal",
    "u": "https://wbgamesmontreal.com",
    "c": "Technologie",
    "d": "Studio jeux vidéo",
    "date": "2025"
  },
  {
    "n": "Behaviour Interactive",
    "u": "https://www.bhvr.com",
    "c": "Technologie",
    "d": "Dead by Daylight",
    "date": "2025"
  },
  {
    "n": "Loto-Québec",
    "u": "https://lotoquebec.com",
    "c": "Commerce",
    "d": "Jeux de hasard et casinos",
    "date": "2025"
  },
  {
    "n": "SAQ",
    "u": "https://www.saq.com",
    "c": "Commerce",
    "d": "Société des alcools du Québec",
    "date": "2025"
  },
  {
    "n": "Couche-Tard",
    "u": "https://corpo.couche-tard.com",
    "c": "Commerce",
    "d": "Dépanneurs internationaux",
    "date": "2025"
  },
  {
    "n": "Metro",
    "u": "https://www.metro.ca",
    "c": "Commerce",
    "d": "Épicerie Québec",
    "date": "2025"
  },
  {
    "n": "Jean Coutu",
    "u": "https://www.jeancoutu.com",
    "c": "Commerce",
    "d": "Pharmacies Québec",
    "date": "2025"
  },
  {
    "n": "Rona",
    "u": "https://www.rona.ca",
    "c": "Commerce",
    "d": "Quincaillerie et rénovation",
    "date": "2025"
  },
  {
    "n": "Vidéotron",
    "u": "https://www.videotron.com",
    "c": "Médias",
    "d": "Télécom et internet Québec",
    "date": "2025"
  },
  {
    "n": "Québecor",
    "u": "https://www.quebecor.com",
    "c": "Médias",
    "d": "Médias, télécom, édition Québec",
    "date": "2025"
  },
  {
    "n": "Festival d’été de Québec",
    "u": "https://www.feq.ca",
    "c": "Culture",
    "d": "11 jours Plaines Abraham",
    "date": "2025"
  },
  {
    "n": "Juste pour rire",
    "u": "https://www.hahaha.com",
    "c": "Culture",
    "d": "Festival humour mondial",
    "date": "2025"
  },
  {
    "n": "Les Francos de Montréal",
    "u": "https://www.francofolies.com",
    "c": "Culture",
    "d": "Musique francophone",
    "date": "2025"
  },
  {
    "n": "Festival international de jazz de Montréal",
    "u": "https://www.montrealjazzfest.com",
    "c": "Culture",
    "d": "Plus grand festival jazz",
    "date": "2025"
  },
  {
    "n": "Osheaga",
    "u": "https://www.osheaga.com/fr",
    "c": "Culture",
    "d": "Musique Parc Jean-Drapeau",
    "date": "2025"
  },
  {
    "n": "Fête nationale du Québec",
    "u": "https://www.fetenationale.quebec",
    "c": "Culture",
    "d": "24 juin Saint-Jean-Baptiste",
    "date": "2025"
  },
  {
    "n": "Carnaval de Québec",
    "u": "https://carnaval.qc.ca",
    "c": "Culture",
    "d": "Plus grand carnaval hiver",
    "date": "2025"
  },
  {
    "n": "Théâtre du Nouveau Monde",
    "u": "https://tnm.qc.ca",
    "c": "Culture",
    "d": "Théâtre majeur Montréal",
    "date": "2025"
  },
  {
    "n": "Place des Arts",
    "u": "https://placedesarts.com",
    "c": "Culture",
    "d": "Complexe spectacles Montréal",
    "date": "2025"
  },
  {
    "n": "Orchestre symphonique de Montréal",
    "u": "https://www.osm.ca",
    "c": "Culture",
    "d": "OSM Maison symphonique",
    "date": "2025"
  },
  {
    "n": "Musée des beaux-arts de Montréal",
    "u": "https://www.mbam.qc.ca",
    "c": "Culture",
    "d": "Plus grand musée Québec",
    "date": "2025"
  },
  {
    "n": "Musée national des beaux-arts du Québec",
    "u": "https://www.mnbaq.org",
    "c": "Culture",
    "d": "Art québécois Québec ville",
    "date": "2025"
  },
  {
    "n": "Oratoire Saint-Joseph",
    "u": "https://www.saint-joseph.org",
    "c": "Culture",
    "d": "Sanctuaire Saint-Joseph Montréal",
    "date": "2025"
  },
  {
    "n": "Basilique Notre-Dame Montréal",
    "u": "https://basiliquenotredame.ca",
    "c": "Culture",
    "d": "Joyau gothique Vieux-Montréal",
    "date": "2025"
  },
  {
    "n": "Basilique Sainte-Anne-de-Beaupré",
    "u": "https://sanctuairesainteanne.org",
    "c": "Culture",
    "d": "Sanctuaire national",
    "date": "2025"
  },
  {
    "n": "Sanctuaire Notre-Dame-du-Cap",
    "u": "https://sanctuaire-ndc.ca",
    "c": "Culture",
    "d": "Sanctuaire marial Trois-Rivières",
    "date": "2025"
  },
  {
    "n": "Université de Montréal",
    "u": "https://www.umontreal.ca",
    "c": "Éducation",
    "d": "Plus grande université francophone Amérique",
    "date": "2025"
  },
  {
    "n": "Université Laval",
    "u": "https://www.ulaval.ca",
    "c": "Éducation",
    "d": "Plus ancienne université francophone Amérique",
    "date": "2025"
  },
  {
    "n": "UQAM",
    "u": "https://www.uqam.ca",
    "c": "Éducation",
    "d": "Université publique Montréal",
    "date": "2025"
  },
  {
    "n": "Université de Sherbrooke",
    "u": "https://www.usherbrooke.ca",
    "c": "Éducation",
    "d": "Université coopérative Estrie",
    "date": "2025"
  },
  {
    "n": "HEC Montréal",
    "u": "https://www.hec.ca",
    "c": "Éducation",
    "d": "École de gestion",
    "date": "2025"
  },
  {
    "n": "Polytechnique Montréal",
    "u": "https://www.polymtl.ca",
    "c": "Éducation",
    "d": "École d’ingénierie",
    "date": "2025"
  },
  {
    "n": "ÉTS",
    "u": "https://www.etsmtl.ca",
    "c": "Éducation",
    "d": "École technologie supérieure",
    "date": "2025"
  },
  {
    "n": "Cégep du Vieux Montréal",
    "u": "https://www.cvm.qc.ca",
    "c": "Éducation",
    "d": "Plus grand cégep Québec",
    "date": "2025"
  },
  {
    "n": "Collège de Maisonneuve",
    "u": "https://www.cmaisonneuve.qc.ca",
    "c": "Éducation",
    "d": "Cégep Est Montréal",
    "date": "2025"
  },
  {
    "n": "Collège Ahuntsic",
    "u": "https://www.collegeahuntsic.qc.ca",
    "c": "Éducation",
    "d": "Cégep Nord Montréal",
    "date": "2025"
  },
  {
    "n": "Office québécois de la langue française",
    "u": "https://www.oqlf.gouv.qc.ca",
    "c": "Culture",
    "d": "Protection et promotion du français",
    "date": "2025"
  },
  {
    "n": "Bibliothèque et Archives nationales du Québec",
    "u": "https://www.banq.qc.ca",
    "c": "Culture",
    "d": "Grande bibliothèque Montréal",
    "date": "2025"
  },
  {
    "n": "Télé-Québec",
    "u": "https://www.telequebec.tv",
    "c": "Médias",
    "d": "Télévision éducative publique",
    "date": "2025"
  },
  {
    "n": "ICI Radio-Canada",
    "u": "https://ici.radio-canada.ca",
    "c": "Médias",
    "d": "Radio-télévision publique",
    "date": "2025"
  },
  {
    "n": "TVA",
    "u": "https://www.tva.canoe.ca",
    "c": "Médias",
    "d": "Réseau télévision privé Québec",
    "date": "2025"
  },
  {
    "n": "Noovo",
    "u": "https://www.noovo.ca",
    "c": "Médias",
    "d": "Réseau télé Bell Media Québec",
    "date": "2025"
  },
  {
    "n": "Le Devoir",
    "u": "https://www.ledevoir.com",
    "c": "Médias",
    "d": "Journal indépendant",
    "date": "2025"
  },
  {
    "n": "La Presse",
    "u": "https://www.lapresse.ca",
    "c": "Médias",
    "d": "100% numérique Montréal",
    "date": "2025"
  },
  {
    "n": "Journal de Montréal",
    "u": "https://www.journaldemontreal.com",
    "c": "Médias",
    "d": "Tabloïd le plus lu",
    "date": "2025"
  },
  {
    "n": "98,5 FM",
    "u": "https://www.985fm.ca",
    "c": "Médias",
    "d": "Radio parlée leader Montréal",
    "date": "2025"
  },
  {
    "n": "CKOI",
    "u": "https://www.ckoi.com",
    "c": "Médias",
    "d": "Radio hits Québec",
    "date": "2025"
  },
  {
    "n": "Rythme FM",
    "u": "https://www.rythme.fm",
    "c": "Médias",
    "d": "Adulte contemporain",
    "date": "2025"
  },
  {
    "n": "Énergie",
    "u": "https://www.energie.ca",
    "c": "Médias",
    "d": "Réseau rock Québec",
    "date": "2025"
  },
  {
    "n": "Gouvernement du Québec",
    "u": "https://www.quebec.ca",
    "c": "Gouvernement",
    "d": "Portail officiel du gouvernement du Québec",
    "date": "2025"
  },
  {
    "n": "Assemblée nationale du Québec",
    "u": "https://www.assnat.qc.ca",
    "c": "Gouvernement",
    "d": "Site officiel de l'Assemblée nationale",
    "date": "2025"
  },
  {
    "n": "Ministère des Relations internationales et Francophonie",
    "u": "https://www.mrif.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Francophonie internationale Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Environnement Québec",
    "u": "https://www.environnement.gouv.qc.ca",
    "c": "Environnement",
    "d": "Environnement et climat",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Agriculture, Pêcheries et Alimentation",
    "u": "https://www.mapaq.gouv.qc.ca",
    "c": "Commerce",
    "d": "Agriculture et alimentation Québec",
    "date": "2025"
  },
  {
    "n": "Ministère des Transports Québec",
    "u": "https://www.transports.gouv.qc.ca",
    "c": "Transport",
    "d": "Transports et infrastructures",
    "date": "2025"
  },
  {
    "n": "Ministère du Travail, Emploi et Solidarité sociale",
    "u": "https://www.travail.gouv.qc.ca",
    "c": "Emploi",
    "d": "Emploi et solidarité sociale",
    "date": "2025"
  },
  {
    "n": "Ministère de la Famille Québec",
    "u": "https://www.mfa.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Famille et enfance",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Immigration, Francisation et Intégration",
    "u": "https://www.immigration-quebec.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Immigration et francisation",
    "date": "2025"
  },
  {
    "n": "Ministère des Affaires municipales et Habitation",
    "u": "https://www.mamh.gouv.qc.ca",
    "c": "Gouvernement",
    "d": "Municipalités et logement",
    "date": "2025"
  },
  {
    "n": "Ministère des Forêts, Faune et Parcs",
    "u": "https://www.mffp.gouv.qc.ca",
    "c": "Environnement",
    "d": "Forêts et parcs nationaux",
    "date": "2025"
  },
  {
    "n": "Ministère du Tourisme Québec",
    "u": "https://www.tourisme.gouv.qc.ca",
    "c": "Tourisme",
    "d": "Tourisme officiel Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Énergie et Ressources naturelles",
    "u": "https://mern.gouv.qc.ca",
    "c": "Environnement",
    "d": "Énergie et mines Québec",
    "date": "2025"
  },
  {
    "n": "Ministère de l'Enseignement supérieur",
    "u": "https://www.quebec.ca/enseignement-superieur",
    "c": "Éducation",
    "d": "Universités et recherche Québec",
    "date": "2025"
  },
  {
    "n": "Ville de Montréal",
    "u": "https://montreal.ca",
    "c": "Gouvernement",
    "d": "Site officiel de la ville de Montréal",
    "date": "2025"
  },
  {
    "n": "Ville de Québec",
    "u": "https://www.ville.quebec.qc.ca",
    "c": "Gouvernement",
    "d": "Capitale nationale Québec",
    "date": "2025"
  },
  {
    "n": "Ville de Gatineau",
    "u": "https://www.gatineau.ca",
    "c": "Gouvernement",
    "d": "Ville francophone Outaouais",
    "date": "2025"
  },
  {
    "n": "Ville de Laval",
    "u": "https://www.laval.ca",
    "c": "Gouvernement",
    "d": "Troisième ville Québec",
    "date": "2025"
  },
  {
    "n": "Ville de Longueuil",
    "u": "https://longueuil.quebec",
    "c": "Gouvernement",
    "d": "Agglomération Longueuil",
    "date": "2025"
  },
  {
    "n": "Ville de Sherbrooke",
    "u": "https://www.sherbrooke.ca",
    "c": "Gouvernement",
    "d": "Estrie capitale",
    "date": "2025"
  },
  {
    "n": "Ville de Trois-Rivières",
    "u": "https://www.v3r.net",
    "c": "Gouvernement",
    "d": "Mauricie capitale",
    "date": "2025"
  },
  {
    "n": "Ville de Saguenay",
    "u": "https://ville.saguenay.ca",
    "c": "Gouvernement",
    "d": "Saguenay–Lac-Saint-Jean",
    "date": "2025"
  },
  {
    "n": "Bibliothèque et Archives nationales du Québec (BAnQ)",
    "u": "https://www.banq.qc.ca",
    "c": "Culture",
    "d": "Bibliothèque nationale Québec",
    "date": "2025"
  },
  {
    "n": "Journal de Québec",
    "u": "https://www.journaldequebec.com",
    "c": "Médias",
    "d": "Journal Québec ville",
    "date": "2025"
  },
  {
    "n": "Le Soleil",
    "u": "https://www.lesoleil.com",
    "c": "Médias",
    "d": "Journal Capitale-Nationale",
    "date": "2025"
  },
  {
    "n": "98,5 FM Montréal",
    "u": "https://www.985fm.ca",
    "c": "Médias",
    "d": "Radio parlée leader Montréal",
    "date": "2025"
  },
  {
    "n": "ICI Première",
    "u": "https://ici.radio-canada.ca/premiere",
    "c": "Médias",
    "d": "Radio publique information",
    "date": "2025"
  },
  {
    "n": "CKOI 96.9",
    "u": "https://www.ckoi.com",
    "c": "Médias",
    "d": "Radio musicale Montréal",
    "date": "2025"
  },
  {
    "n": "Université du Québec à Montréal (UQAM)",
    "u": "https://www.uqam.ca",
    "c": "Éducation",
    "d": "Université publique Montréal",
    "date": "2025"
  },
  {
    "n": "Université McGill (programmes français)",
    "u": "https://www.mcgill.ca/fr",
    "c": "Éducation",
    "d": "Programmes en français McGill",
    "date": "2025"
  },
  {
    "n": "ÉTS - École de technologie supérieure",
    "u": "https://www.etsmtl.ca",
    "c": "Éducation",
    "d": "Génie appliqué Montréal",
    "date": "2025"
  },
  {
    "n": "Université Concordia (départements français)",
    "u": "https://www.concordia.ca/fr",
    "c": "Éducation",
    "d": "Programmes francophones Concordia",
    "date": "2025"
  },
  {
    "n": "Cégep de Saint-Laurent",
    "u": "https://www.cstlaurent.qc.ca",
    "c": "Éducation",
    "d": "Cégep Montréal",
    "date": "2025"
  },
  {
    "n": "Collège de Rosemont",
    "u": "https://www.crosemont.qc.ca",
    "c": "Éducation",
    "d": "Cégep Rosemont Montréal",
    "date": "2025"
  },
  {
    "n": "Cégep Édouard-Montpetit",
    "u": "https://www.cegepmontpetit.ca",
    "c": "Éducation",
    "d": "Longueuil et aérospatiale",
    "date": "2025"
  },
  {
    "n": "Cégep André-Laurendeau",
    "u": "https://claurendeau.qc.ca",
    "c": "Éducation",
    "d": "LaSalle Montréal",
    "date": "2025"
  },
  {
    "n": "Cégep de Saint-Jérôme",
    "u": "https://www.cstj.qc.ca",
    "c": "Éducation",
    "d": "Laurentides",
    "date": "2025"
  },
  {
    "n": "Cégep de l'Outaouais",
    "u": "https://www.cegepoutaouais.qc.ca",
    "c": "Éducation",
    "d": "Gatineau",
    "date": "2025"
  },
  {
    "n": "Cégep de Trois-Rivières",
    "u": "https://www.cegeptr.qc.ca",
    "c": "Éducation",
    "d": "Mauricie",
    "date": "2025"
  },
  {
    "n": "Office québécois de la langue française (OQLF)",
    "u": "https://www.oqlf.gouv.qc.ca",
    "c": "Culture",
    "d": "Protection et promotion français Québec",
    "date": "2025"
  },
  {
    "n": "Conseil supérieur de la langue française",
    "u": "https://www.cslf.gouv.qc.ca",
    "c": "Culture",
    "d": "Conseil langue française Québec",
    "date": "2025"
  },
  {
    "n": "TFO - Télévision française Ontario",
    "u": "https://www.tfo.org",
    "c": "Médias",
    "d": "Télé éducative franco-ontarienne",
    "date": "2025"
  },
  {
    "n": "Unis TV",
    "u": "https://unis.ca",
    "c": "Médias",
    "d": "Chaîne nationale francophone Canada",
    "date": "2025"
  },
  {
    "n": "ICI ARTV",
    "u": "https://ici.artv.ca",
    "c": "Médias",
    "d": "Chaîne arts et culture",
    "date": "2025"
  },
  {
    "n": "ICI Explora",
    "u": "https://ici.explora.ca",
    "c": "Médias",
    "d": "Chaîne science et découverte",
    "date": "2025"
  },
  {
    "n": "Festival d'été de Québec",
    "u": "https://www.feq.ca",
    "c": "Culture",
    "d": "Plus grand festival francophone extérieur",
    "date": "2025"
  },
  {
    "n": "Juste pour rire Montréal",
    "u": "https://www.hahaha.com",
    "c": "Culture",
    "d": "Festival humour Montréal",
    "date": "2025"
  },
  {
    "n": "Francofolies de Montréal",
    "u": "https://www.francofolies.com",
    "c": "Culture",
    "d": "Festival musique francophone",
    "date": "2025"
  },
  {
    "n": "Mundial Montréal",
    "u": "https://mundialmontreal.com",
    "c": "Culture",
    "d": "Musiques monde showcase",
    "date": "2025"
  },
  {
    "n": "Coup de cœur francophone",
    "u": "https://coupdecoeur.ca",
    "c": "Culture",
    "d": "Festival chanson francophone",
    "date": "2025"
  },
  {
    "n": "Théâtre Denise-Pelletier",
    "u": "https://denise-pelletier.qc.ca",
    "c": "Culture",
    "d": "Théâtre jeunesse Montréal",
    "date": "2025"
  },
  {
    "n": "Centaur Theatre",
    "u": "https://centaurtheatre.com/fr",
    "c": "Culture",
    "d": "Théâtre bilingue Montréal",
    "date": "2025"
  },
  {
    "n": "Musée de la civilisation Québec",
    "u": "https://www.mcq.org",
    "c": "Culture",
    "d": "Musée société Québec",
    "date": "2025"
  },
  {
    "n": "Orchestre symphonique de Montréal (OSM)",
    "u": "https://www.osm.ca",
    "c": "Culture",
    "d": "Orchestre symphonique Maison symphonique",
    "date": "2025"
  },
  {
    "n": "Orchestre Métropolitain",
    "u": "https://orchestremetropolitain.com",
    "c": "Culture",
    "d": "Orchestre Yannick Nézet-Séguin",
    "date": "2025"
  },
  {
    "n": "Les Grands Ballets Canadiens",
    "u": "https://grandsballets.com",
    "c": "Culture",
    "d": "Compagnie ballet Montréal",
    "date": "2025"
  },
  {
    "n": "Opéra de Montréal",
    "u": "https://www.operademontreal.com",
    "c": "Culture",
    "d": "Opéra Montréal",
    "date": "2025"
  },
  {
    "n": "Société des arts technologiques (SAT)",
    "u": "https://sat.qc.ca",
    "c": "Culture",
    "d": "Immersion numérique Montréal",
    "date": "2025"
  },
  {
    "n": "TOHU",
    "u": "https://tohu.ca",
    "c": "Culture",
    "d": "Cité des arts du cirque",
    "date": "2025"
  },
  {
    "n": "Maison symphonique de Montréal",
    "u": "https://maisonesymphonique.com",
    "c": "Culture",
    "d": "Salle OSM",
    "date": "2025"
  },
  {
    "n": "Théâtre St-Denis",
    "u": "https://theatrestdenis.com",
    "c": "Culture",
    "d": "Salle spectacles Montréal",
    "date": "2025"
  },
  {
    "n": "Olympia de Montréal",
    "u": "https://theolympia.com",
    "c": "Culture",
    "d": "Salle historique",
    "date": "2025"
  },
  {
    "n": "MTELUS",
    "u": "https://mtelus.com",
    "c": "Culture",
    "d": "Salle rock Montréal",
    "date": "2025"
  },
  {
    "n": "Club Soda",
    "u": "https://clubsoda.ca",
    "c": "Culture",
    "d": "Salle spectacles centre-ville",
    "date": "2025"
  },
  {
    "n": "L'Astral",
    "u": "https://lastral.com",
    "c": "Culture",
    "d": "Salle Maison du Festival",
    "date": "2025"
  },
  {
    "n": "Théâtre Maisonneuve",
    "u": "https://placedesarts.com",
    "c": "Culture",
    "d": "Grande salle Place des Arts",
    "date": "2025"
  },
  {
    "n": "Théâtre Outremont",
    "u": "https://theatreoutremont.ca",
    "c": "Culture",
    "d": "Théâtre historique",
    "date": "2025"
  },
  {
    "n": "Cinéma Beaubien",
    "u": "https://cinemabeaubien.com",
    "c": "Culture",
    "d": "Cinéma art et essai",
    "date": "2025"
  },
  {
    "n": "Cinéma du Parc",
    "u": "https://www.cinemaduparc.com",
    "c": "Culture",
    "d": "Cinéma indépendant",
    "date": "2025"
  },
  {
    "n": "Cinéma Impérial",
    "u": "https://www.cinemaimperial.com",
    "c": "Culture",
    "d": "Cinéma patrimoine Québec",
    "date": "2025"
  },
  {
    "n": "Cinématique québécoise",
    "u": "https://www.cinematheque.qc.ca",
    "c": "Culture",
    "d": "Archives film Québec",
    "date": "2025"
  },
  {
    "n": "Festival du nouveau cinéma",
    "u": "https://nouveaucinema.ca",
    "c": "Culture",
    "d": "Festival cinéma expérimental",
    "date": "2025"
  },
  {
    "n": "Regard - Festival cinéma Saguenay",
    "u": "https://regard.org",
    "c": "Culture",
    "d": "Court-métrage Saguenay",
    "date": "2025"
  },
  {
    "n": "Festival de cinéma de la ville de Québec",
    "u": "https://fcvq.ca",
    "c": "Culture",
    "d": "Cinéma Québec ville",
    "date": "2025"
  },
  {
    "n": "RIDM - Rencontres internationales documentaire Montréal",
    "u": "https://ridm.ca",
    "c": "Culture",
    "d": "Documentaire Montréal",
    "date": "2025"
  },
  {
    "n": "Festival international du film sur l'art (FIFA)",
    "u": "https://www.artfifa.com",
    "c": "Culture",
    "d": "Art et cinéma",
    "date": "2025"
  },
  {
    "n": "Vues d'Afrique",
    "u": "https://vuesdafrique.com",
    "c": "Culture",
    "d": "Cinéma africain et créole",
    "date": "2025"
  },
  {
    "n": "Cinémathèque québécoise",
    "u": "https://www.cinematheque.qc.ca",
    "c": "Culture",
    "d": "Conservation patrimoine cinéma",
    "date": "2025"
  },
  {
    "n": "Office national du film (ONF)",
    "u": "https://www.onf.ca",
    "c": "Culture",
    "d": "Production cinéma public Canada",
    "date": "2025"
  },
  {
    "n": "Conseil des arts et lettres du Québec",
    "u": "https://www.calq.gouv.qc.ca",
    "c": "Culture",
    "d": "Subventions arts Québec",
    "date": "2025"
  },
  {
    "n": "Conseil des arts de Montréal",
    "u": "https://www.artsmontreal.org",
    "c": "Culture",
    "d": "Soutien arts Montréal",
    "date": "2025"
  },
  {
    "n": "CRSH Canada",
    "u": "https://www.sshrc-crsh.gc.ca",
    "c": "Éducation",
    "d": "Recherche sciences humaines",
    "date": "2025"
  },
  {
    "n": "IRSC",
    "u": "https://cihr-irsc.gc.ca",
    "c": "Santé",
    "d": "Recherche santé Canada",
    "date": "2025"
  },
  {
    "n": "CRSNG",
    "u": "https://www.nserc-crsng.gc.ca",
    "c": "Éducation",
    "d": "Recherche sciences naturelles",
    "date": "2025"
  },
  {
    "n": "Mitacs",
    "u": "https://www.mitacs.ca",
    "c": "Éducation",
    "d": "Stages recherche entreprises",
    "date": "2025"
  },
  {
    "n": "Mila - Institut québécois d'IA",
    "u": "https://mila.quebec",
    "c": "Technologie",
    "d": "Recherche IA Montréal",
    "date": "2025"
  },
  {
    "n": "Element AI (maintenant ServiceNow)",
    "u": "https://www.servicenow.com",
    "c": "Technologie",
    "d": "IA appliquée Montréal",
    "date": "2025"
  },
  {
    "n": "Scale AI",
    "u": "https://www.scaleai.ca",
    "c": "Technologie",
    "d": "Supercluster intelligence artificielle Canada",
    "date": "2025"
  },
  {
    "n": "District 3 Montréal",
    "u": "https://d3center.ca",
    "c": "Technologie",
    "d": "Innovation Concordia",
    "date": "2025"
  },
  {
    "n": "Notman House",
    "u": "https://notman.org",
    "c": "Technologie",
    "d": "Campus startups Montréal",
    "date": "2025"
  },
  {
    "n": "Maison Notman",
    "u": "https://osmo.ca",
    "c": "Technologie",
    "d": "Osmo fondation startups",
    "date": "2025"
  },
  {
    "n": "InnoCité MTL",
    "u": "https://innocitemtl.com",
    "c": "Technologie",
    "d": "Smart city accélérateur",
    "date": "2025"
  },
  {
    "n": "Technopôle Angus",
    "u": "https://technopoleangus.com",
    "c": "Technologie",
    "d": "Campus innovation Rosemont",
    "date": "2025"
  },
  {
    "n": "Esplanade Montréal",
    "u": "https://esplanade.quebec",
    "c": "Technologie",
    "d": "Impact social accélérateur",
    "date": "2025"
  },
  {
    "n": "Brightspark Ventures",
    "u": "https://brightspark.com",
    "c": "Technologie",
    "d": "Capital-risque canadien",
    "date": "2025"
  },
  {
    "n": "Panache Ventures",
    "u": "https://panache.vc",
    "c": "Technologie",
    "d": "Pré-amorçage Canada",
    "date": "2025"
  },
  {
    "n": "BDC Capital",
    "u": "https://www.bdc.ca",
    "c": "Commerce",
    "d": "Banque développement Canada",
    "date": "2025"
  },
  {
    "n": "Anges Québec",
    "u": "https://angesquebec.com",
    "c": "Commerce",
    "d": "Réseau anges investisseurs",
    "date": "2025"
  },
  {
    "n": "Startup Montréal",
    "u": "https://startupmontreal.com",
    "c": "Technologie",
    "d": "Communauté startups Montréal",
    "date": "2025"
  },
  {
    "n": "Montréal Inc.",
    "u": "https://montrealinc.ca",
    "c": "Technologie",
    "d": "Soutien entrepreneuriat Montréal",
    "date": "2025"
  },
  {
    "n": "Québec International",
    "u": "https://www.quebecinternational.ca",
    "c": "Commerce",
    "d": "Développement économique Québec",
    "date": "2025"
  },
  {
    "n": "Bonjours Québec",
    "u": "https://www.quebecoriginal.com",
    "c": "Tourisme",
    "d": "Tourisme officiel Québec",
    "date": "2025"
  },
  {
    "n": "Fédération des chambres de commerce du Québec",
    "u": "https://www.fccq.ca",
    "c": "Commerce",
    "d": "Réseau chambres commerce Québec",
    "date": "2025"
  },
  {
    "n": "CPQ - Conseil du patronat Québec",
    "u": "https://cpq.qc.ca",
    "c": "Commerce",
    "d": "Regroupement employeurs Québec",
    "date": "2025"
  },
  {
    "n": "Alliance de l'industrie touristique du Québec",
    "u": "https://allianceindustrie.com",
    "c": "Tourisme",
    "d": "Tourisme Québec",
    "date": "2025"
  },
  {
    "n": "Société des casinos du Québec",
    "u": "https://casinos.lotoquebec.com",
    "c": "Commerce",
    "d": "Casinos Québec",
    "date": "2025"
  },
  {
    "n": "SAQ - Société des alcools du Québec",
    "u": "https://www.saq.com",
    "c": "Commerce",
    "d": "Vente alcools monopole",
    "date": "2025"
  },
  {
    "n": "Desjardins",
    "u": "https://www.desjardins.com",
    "c": "Commerce",
    "d": "Coopérative financière Québec",
    "date": "2025"
  },
  {
    "n": "Banque Nationale",
    "u": "https://www.bnc.ca",
    "c": "Commerce",
    "d": "Banque québécoise",
    "date": "2025"
  },
  {
    "n": "Provigo",
    "u": "https://www.provigo.ca",
    "c": "Commerce",
    "d": "Épicerie Loblaw Québec",
    "date": "2025"
  },
  {
    "n": "IGA",
    "u": "https://www.iga.net",
    "c": "Commerce",
    "d": "Épicerie Sobeys Québec",
    "date": "2025"
  },
  {
    "n": "Uniprix",
    "u": "https://www.uniprix.com",
    "c": "Commerce",
    "d": "Pharmacies Québec",
    "date": "2025"
  },
  {
    "n": "Brunet",
    "u": "https://www.brunet.ca",
    "c": "Commerce",
    "d": "Pharmacies McMahon",
    "date": "2025"
  },
  {
    "n": "Familiprix",
    "u": "https://www.familiprix.com",
    "c": "Commerce",
    "d": "Pharmacies Québec",
    "date": "2025"
  },
  {
    "n": "Réno-Dépôt",
    "u": "https://www.renodepot.com",
    "c": "Commerce",
    "d": "Rénovation gros format",
    "date": "2025"
  },
  {
    "n": "Canac",
    "u": "https://www.canac.ca",
    "c": "Commerce",
    "d": "Quincaillerie Québec",
    "date": "2025"
  },
  {
    "n": "BMR",
    "u": "https://www.bmr.co",
    "c": "Commerce",
    "d": "Matériaux construction Québec",
    "date": "2025"
  },
  {
    "n": "Moment Factory",
    "u": "https://momentfactory.com",
    "c": "Culture",
    "d": "Expériences multimédia Montréal",
    "date": "2025"
  },
  {
    "n": "Electronic Arts Montréal",
    "u": "https://www.ea.com/studios/montreal",
    "c": "Technologie",
    "d": "EA Sports FIFA",
    "date": "2025"
  },
  {
    "n": "Beenox Québec",
    "u": "https://www.beenox.com",
    "c": "Technologie",
    "d": "Call of Duty studio Activision",
    "date": "2025"
  },
  {
    "n": "Squeeze Studio Animation",
    "u": "https://squeezeanimation.com",
    "c": "Culture",
    "d": "Animation 3D Québec",
    "date": "2025"
  },
  {
    "n": "Framestore Montréal",
    "u": "https://montreal.framestore.com",
    "c": "Culture",
    "d": "Effets visuels films",
    "date": "2025"
  },
  {
    "n": "Rodeo FX",
    "u": "https://rodeofx.com",
    "c": "Culture",
    "d": "VFX Oscar Québec",
    "date": "2025"
  },
  {
    "n": "Cinesite Montréal",
    "u": "https://cinesite.com/montreal",
    "c": "Culture",
    "d": "Animation et VFX",
    "date": "2025"
  },
  {
    "n": "DNEG Montréal",
    "u": "https://www.dneg.com",
    "c": "Culture",
    "d": "Effets visuels blockbusters",
    "date": "2025"
  },
  {
    "n": "National Film Board (ONF)",
    "u": "https://www.onf.ca",
    "c": "Culture",
    "d": "Production cinéma public",
    "date": "2025"
  },
  {
    "n": "TVA Group",
    "u": "https://groupetva.ca",
    "c": "Médias",
    "d": "Télévision et production",
    "date": "2025"
  },
  {
    "n": "Bell Média Québec",
    "u": "https://bellmedia.ca",
    "c": "Médias",
    "d": "Noovo et chaînes spécialisées",
    "date": "2025"
  },
  {
    "n": "Cogeco",
    "u": "https://www.cogeco.ca",
    "c": "Médias",
    "d": "Câble radio Québec Ontario",
    "date": "2025"
  },
  {
    "n": "Groupe CH Médias",
    "u": "https://www.groupech.ca",
    "c": "Médias",
    "d": "Journaux régionaux Québec",
    "date": "2025"
  },
  {
    "n": "Transcontinental",
    "u": "https://tctranscontinental.com",
    "c": "Médias",
    "d": "Imprimerie et médias Québec",
    "date": "2025"
  },
  {
    "n": "La Presse+",
    "u": "https://www.lapresse.ca",
    "c": "Médias",
    "d": "Numérique seulement depuis 2016",
    "date": "2025"
  },
  {
    "n": "Le Journal de Montréal",
    "u": "https://www.journaldemontreal.com",
    "c": "Médias",
    "d": "Tabloïd leader Québec",
    "date": "2025"
  },
  {
    "n": "Les Affaires",
    "u": "https://www.lesaffaires.com",
    "c": "Médias",
    "d": "Journal économique Québec",
    "date": "2025"
  },
  {
    "n": "Finance et Investissement",
    "u": "https://www.finance-investissement.com",
    "c": "Médias",
    "d": "Finance professionnelle Québec",
    "date": "2025"
  },
  {
    "n": "La Voix de l'Est",
    "u": "https://www.lavoixdelest.ca",
    "c": "Médias",
    "d": "Journal Granby Estrie",
    "date": "2025"
  },
  {
    "n": "Le Nouvelliste",
    "u": "https://www.lenouvelliste.ca",
    "c": "Médias",
    "d": "Journal Trois-Rivières",
    "date": "2025"
  },
  {
    "n": "Le Droit",
    "u": "https://www.ledroit.com",
    "c": "Médias",
    "d": "Journal Outaouais franco-ontarien",
    "date": "2025"
  },
  {
    "n": "L'Acadie Nouvelle",
    "u": "https://www.acadienouvelle.com",
    "c": "Médias",
    "d": "Journal Acadie Nouveau-Brunswick",
    "date": "2025"
  },
  {
    "n": "L'Aurore boréale",
    "u": "https://auroreboreale.ca",
    "c": "Médias",
    "d": "Journal Yukon",
    "date": "2025"
  },
  {
    "n": "L'Eau vive",
    "u": "https://eauvive.ca",
    "c": "Médias",
    "d": "Journal Saskatchewan francophone",
    "date": "2025"
  },
  {
    "n": "Le Voyageur",
    "u": "https://levoyageur.ca",
    "c": "Médias",
    "d": "Journal Sudbury Ontario",
    "date": "2025"
  },
  {
    "n": "Le Rempart",
    "u": "https://lerempart.ca",
    "c": "Médias",
    "d": "Journal Windsor Ontario",
    "date": "2025"
  },
  {
    "n": "Le Métropolitain",
    "u": "https://lemetropolitain.com",
    "c": "Médias",
    "d": "Journal Toronto francophone",
    "date": "2025"
  },
  {
    "n": "Radio-Canada Acadie",
    "u": "https://ici.radio-canada.ca/acadie",
    "c": "Médias",
    "d": "Radio télé Acadie",
    "date": "2025"
  },
  {
    "n": "Radio-Canada Ottawa-Gatineau",
    "u": "https://ici.radio-canada.ca/ottawa-gatineau",
    "c": "Médias",
    "d": "Région capitale",
    "date": "2025"
  },
  {
    "n": "Radio-Canada Estrie",
    "u": "https://ici.radio-canada.ca/estrie",
    "c": "Médias",
    "d": "Sherbrooke région",
    "date": "2025"
  },
  {
    "n": "Radio-Canada Saguenay",
    "u": "https://ici.radio-canada.ca/saguenay",
    "c": "Médias",
    "d": "Saguenay–Lac-Saint-Jean",
    "date": "2025"
  },
  {
    "n": "CKRL 89,1 Québec",
    "u": "https://ckrl.qc.ca",
    "c": "Médias",
    "d": "Radio communautaire Québec",
    "date": "2025"
  },
  {
    "n": "CHYZ 94,3 Québec",
    "u": "https://chyz.ca",
    "c": "Médias",
    "d": "Radio étudiante Université Laval",
    "date": "2025"
  },
  {
    "n": "CISM 89,3 Montréal",
    "u": "https://cism893.ca",
    "c": "Médias",
    "d": "Radio étudiante UdeM",
    "date": "2025"
  },
  {
    "n": "CJSR 88,5 Montréal",
    "u": "https://cjsr.quebec",
    "c": "Médias",
    "d": "Radio juive sépharade",
    "date": "2025"
  },
  {
    "n": "CKUT 90,3 Montréal",
    "u": "https://ckut.ca",
    "c": "Médias",
    "d": "Radio campus McGill",
    "date": "2025"
  },
  {
    "n": "CIBL 101,5 Montréal",
    "u": "https://cibl1015.com",
    "c": "Médias",
    "d": "Radio communautaire Montréal",
    "date": "2025"
  },
  {
    "n": "CHOQ.ca Montréal",
    "u": "https://choq.ca",
    "c": "Médias",
    "d": "Radio UQAM web",
    "date": "2025"
  },
  {
    "n": "CILM 107,1 Laval",
    "u": "https://cilm1037.ca",
    "c": "Médias",
    "d": "Radio communautaire Laval",
    "date": "2025"
  },
  {
    "n": "CFEL 102,1 Québec",
    "u": "https://www.blvd1021.com",
    "c": "Médias",
    "d": "Radio rock Québec",
    "date": "2025"
  },
  {
    "n": "FM93 Québec",
    "u": "https://www.fm93.com",
    "c": "Médias",
    "d": "Radio parlée Québec",
    "date": "2025"
  },
  {
    "n": "CHOM 97,7 Montréal",
    "u": "https://iheartradio.ca/chom",
    "c": "Médias",
    "d": "Rock classique Montréal",
    "date": "2025"
  },
  {
    "n": "The Beat 92,5 Montréal",
    "u": "https://www.thebeat925.ca",
    "c": "Médias",
    "d": "Hits anglophone mais auditoire bilingue",
    "date": "2025"
  },
  {
    "n": "Virgin Radio Montréal",
    "u": "https://iheartradio.ca/virginradio/montreal",
    "c": "Médias",
    "d": "Hits contemporains",
    "date": "2025"
  },
  {
    "n": "Énergie Québec",
    "u": "https://www.energie.ca",
    "c": "Médias",
    "d": "Réseau rock Québec",
    "date": "2025"
  },
  {
    "n": "Rouge FM",
    "u": "https://www.rouge.fm",
    "c": "Médias",
    "d": "Adulte contemporain Bell",
    "date": "2025"
  },
  {
    "n": "Semaine de la francophonie Québec",
    "u": "https://semainefrancophonie.com",
    "c": "Culture",
    "d": "Événements mars Québec",
    "date": "2025"
  },
  {
    "n": "Mois de la francophonie Montréal",
    "u": "https://moisdelafrancophonie.com",
    "c": "Culture",
    "d": "Mars événements Montréal",
    "date": "2025"
  },
  {
    "n": "Fête de la Saint-Jean-Baptiste",
    "u": "https://fetenationale.quebec",
    "c": "Culture",
    "d": "24 juin Québec",
    "date": "2025"
  },
  {
    "n": "Fête du Canada Québec",
    "u": "https://www.canada.ca/fr/fete-canada.html",
    "c": "Culture",
    "d": "1er juillet célébrations francophones",
    "date": "2025"
  },
  {
    "n": "Journées de la culture",
    "u": "https://www.journeesdelaculture.qc.ca",
    "c": "Culture",
    "d": "Dernier weekend septembre",
    "date": "2025"
  },
  {
    "n": "Nuit blanche Montréal",
    "u": "https://www.mtlunescopole.org/nuit-blanche",
    "c": "Culture",
    "d": "Nuit arts Montréal",
    "date": "2025"
  },
  {
    "n": "MUTEK",
    "u": "https://mutek.org",
    "c": "Culture",
    "d": "Festival musique électronique",
    "date": "2025"
  },
  {
    "n": "Igloofest",
    "u": "https://igloofest.ca",
    "c": "Culture",
    "d": "Festival électro extérieur hiver",
    "date": "2025"
  },
  {
    "n": "Piknic Électronik",
    "u": "https://piknicelectronik.com",
    "c": "Culture",
    "d": "Électro Parc Jean-Drapeau",
    "date": "2025"
  },
  {
    "n": "FestiVoix Trois-Rivières",
    "u": "https://festivoix.com",
    "c": "Culture",
    "d": "Festival musique Mauricie",
    "date": "2025"
  },
  {
    "n": "Festival d'été Québec",
    "u": "https://feq.ca",
    "c": "Culture",
    "d": "11 jours Plaines Abraham",
    "date": "2025"
  },
  {
    "n": "Festival de Lanaudière",
    "u": "https://lanaudiere.org",
    "c": "Culture",
    "d": "Musique classique Joliette",
    "date": "2025"
  },
  {
    "n": "Festival Orford Musique",
    "u": "https://orford.mu",
    "c": "Culture",
    "d": "Musique classique Estrie",
    "date": "2025"
  },
  {
    "n": "Festival de musique émergente (FME) Rouyn-Noranda",
    "u": "https://fme.ca",
    "c": "Culture",
    "d": "Musique émergente Abitibi",
    "date": "2025"
  },
  {
    "n": "Festival en chanson Petite-Vallée",
    "u": "https://festivalenchanson.com",
    "c": "Culture",
    "d": "Chanson Gaspésie",
    "date": "2025"
  },
  {
    "n": "ComediHa! Québec",
    "u": "https://comediha.com",
    "c": "Culture",
    "d": "Humour Québec",
    "date": "2025"
  },
  {
    "n": "Grand Montréal Comique",
    "u": "https://grandmontrealcomique.ca",
    "c": "Culture",
    "d": "Humour Montréal",
    "date": "2025"
  },
  {
    "n": "Zoofest",
    "u": "https://zoofest.com",
    "c": "Culture",
    "d": "Humour alternatif",
    "date": "2025"
  },
  {
    "n": "Montréal complètement cirque",
    "u": "https://montrealcompletementcirque.com",
    "c": "Culture",
    "d": "Festival cirque contemporain",
    "date": "2025"
  },
  {
    "n": "Fête des neiges Montréal",
    "u": "https://www.fetedesneiges.com",
    "c": "Culture",
    "d": "Activités hiver Parc Jean-Drapeau",
    "date": "2025"
  },
  {
    "n": "Fête du lac des nations Sherbrooke",
    "u": "https://fetedulacdesnations.com",
    "c": "Culture",
    "d": "Feux artifices Sherbrooke",
    "date": "2025"
  },
  {
    "n": "Festival international de montgolfières Saint-Jean-sur-Richelieu",
    "u": "https://montgolfieres.com",
    "c": "Culture",
    "d": "Plus grand festival montgolfières Amérique",
    "date": "2025"
  },
  {
    "n": "Festival Western Saint-Tite",
    "u": "https://festivalwestern.com",
    "c": "Culture",
    "d": "Plus grand festival western Amérique",
    "date": "2025"
  },
  {
    "n": "Festival de la galette de sarrasin Louiseville",
    "u": "https://festivalgalette.com",
    "c": "Culture",
    "d": "Gastronomie traditionnelle",
    "date": "2025"
  },
  {
    "n": "Festival de la poutine Drummondville",
    "u": "https://festivalpoutine.com",
    "c": "Culture",
    "d": "Poutine festival",
    "date": "2025"
  },
  {
    "n": "Festival du homard Îles-de-la-Madeleine",
    "u": "https://festivalhomard.com",
    "c": "Culture",
    "d": "Homard Madelinot",
    "date": "2025"
  },
  {
    "n": "Festival de l'érable Saint-Pie",
    "u": "https://festivalerable.com",
    "c": "Culture",
    "d": "Cabane à sucre",
    "date": "2025"
  },
  {
    "n": "Festival du bleuet Mistassini",
    "u": "https://festivalbleuet.com",
    "c": "Culture",
    "d": "Bleuet Lac-Saint-Jean",
    "date": "2025"
  },
  {
    "n": "Festival des fromages fins Victoriaville",
    "u": "https://fromagesfins.com",
    "c": "Culture",
    "d": "Fromages artisanaux Québec",
    "date": "2025"
  },
  {
    "n": "Festival de la gibelotte Sorel",
    "u": "https://festivalgibelotte.com",
    "c": "Culture",
    "d": "Spécialité soreloise",
    "date": "2025"
  },
  {
    "n": "Festival de la Saint-Patrick Montréal",
    "u": "https://parademontreal.com",
    "c": "Culture",
    "d": "Défilé irlandais Montréal",
    "date": "2025"
  },
  {
    "n": "Carifiesta Montréal",
    "u": "https://carifiesta.com",
    "c": "Culture",
    "d": "Carnaval caribéen Montréal",
    "date": "2025"
  },
  {
    "n": "Festival orientalys",
    "u": "https://orientalys.com",
    "c": "Culture",
    "d": "Cultures orientales Vieux-Port",
    "date": "2025"
  },
  {
    "n": "Festival afro-montréalais",
    "u": "https://festivalafromonde.com",
    "c": "Culture",
    "d": "Cultures africaines",
    "date": "2025"
  },
  {
    "n": "Festival du monde arabe",
    "u": "https://festivalarabe.com",
    "c": "Culture",
    "d": "Monde arabe Montréal",
    "date": "2025"
  },
  {
    "n": "Festival international de la littérature (FIL)",
    "u": "https://festival-fil.com",
    "c": "Culture",
    "d": "Littérature Montréal",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Montréal",
    "u": "https://salondulivredemontreal.com",
    "c": "Culture",
    "d": "Plus grand salon livre francophone Amérique",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Québec",
    "u": "https://sildq.com",
    "c": "Culture",
    "d": "Salon livre Québec ville",
    "date": "2025"
  },
  {
    "n": "Salon du livre de l'Outaouais",
    "u": "https://slo.qc.ca",
    "c": "Culture",
    "d": "Gatineau salon livre",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Rimouski",
    "u": "https://salondulivrerimouski.com",
    "c": "Culture",
    "d": "Bas-Saint-Laurent",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Trois-Rivières",
    "u": "https://salondulivretr.com",
    "c": "Culture",
    "d": "Mauricie salon livre",
    "date": "2025"
  },
  {
    "n": "Métro Montréal",
    "u": "https://journalmetro.com",
    "c": "Médias",
    "d": "Journal gratuit métro Montréal",
    "date": "2025"
  },
  {
    "n": "24 heures",
    "u": "https://www.24heures.ca",
    "c": "Médias",
    "d": "Journal gratuit Montréal",
    "date": "2025"
  },
  {
    "n": "Voir",
    "u": "https://voir.ca",
    "c": "Médias",
    "d": "Hebdo culturel Montréal",
    "date": "2025"
  },
  {
    "n": "Cult MTL",
    "u": "https://cultmtl.com",
    "c": "Médias",
    "d": "Culture bilingue Montréal",
    "date": "2025"
  },
  {
    "n": "Nightlife.ca",
    "u": "https://nightlife.ca",
    "c": "Médias",
    "d": "Sorties Montréal",
    "date": "2025"
  },
  {
    "n": "Ton petit lookout",
    "u": "https://tonpetitlookout.com",
    "c": "Médias",
    "d": "Mode et culture Montréal",
    "date": "2025"
  },
  {
    "n": "La Cordée",
    "u": "https://lacordee.com",
    "c": "Commerce",
    "d": "Plein air Québec",
    "date": "2025"
  },
  {
    "n": "Sail",
    "u": "https://sail.ca",
    "c": "Commerce",
    "d": "Plein air et chasse pêche",
    "date": "2025"
  },
  {
    "n": "Atmosphère",
    "u": "https://atmosphere.ca",
    "c": "Commerce",
    "d": "Sport plein air Québec",
    "date": "2025"
  },
  {
    "n": "Sports Experts",
    "u": "https://sportsexperts.ca",
    "c": "Commerce",
    "d": "Sport équipement",
    "date": "2025"
  },
  {
    "n": "L'Équipeur",
    "u": "https://lequipeur.com",
    "c": "Commerce",
    "d": "Vêtements travail Québec",
    "date": "2025"
  },
  {
    "n": "Aubainerie",
    "u": "https://aubainerie.com",
    "c": "Commerce",
    "d": "Vêtements famille Québec",
    "date": "2025"
  },
  {
    "n": "Boutique Courir",
    "u": "https://courir.com",
    "c": "Commerce",
    "d": "Course à pied Québec",
    "date": "2025"
  },
  {
    "n": "Club Piscine",
    "u": "https://clubpiscine.ca",
    "c": "Commerce",
    "d": "Piscine spa Québec",
    "date": "2025"
  },
  {
    "n": "Brault & Martineau",
    "u": "https://braultetmartineau.com",
    "c": "Commerce",
    "d": "Meubles électroménagers",
    "date": "2025"
  },
  {
    "n": "Tanguay",
    "u": "https://tanguay.ca",
    "c": "Commerce",
    "d": "Meubles Québec",
    "date": "2025"
  },
  {
    "n": "Meubles RD",
    "u": "https://meublesrd.com",
    "c": "Commerce",
    "d": "Meubles Rive-Sud",
    "date": "2025"
  },
  {
    "n": "Structube",
    "u": "https://www.structube.com",
    "c": "Commerce",
    "d": "Meubles design abordables",
    "date": "2025"
  },
  {
    "n": "IKEA Québec",
    "u": "https://www.ikea.com/ca/fr/stores/quebec",
    "c": "Commerce",
    "d": "Meubles suédois Québec",
    "date": "2025"
  },
  {
    "n": "Léon",
    "u": "https://leon.ca",
    "c": "Commerce",
    "d": "Meubles Québec",
    "date": "2025"
  },
  {
    "n": "Dormez-vous",
    "u": "https://dormezvous.com",
    "c": "Commerce",
    "d": "Matelas Québec",
    "date": "2025"
  },
  {
    "n": "Best Buy Québec",
    "u": "https://www.bestbuy.ca/fr",
    "c": "Commerce",
    "d": "Électronique Québec",
    "date": "2025"
  },
  {
    "n": "Bureau en gros",
    "u": "https://www.bureauengros.com",
    "c": "Commerce",
    "d": "Fournitures bureau",
    "date": "2025"
  },
  {
    "n": "Archambault",
    "u": "https://www.archambault.ca",
    "c": "Culture",
    "d": "Livres musique Québec",
    "date": "2025"
  },
  {
    "n": "Renaud-Bray",
    "u": "https://www.renaud-bray.com",
    "c": "Culture",
    "d": "Plus grande chaîne librairie Québec",
    "date": "2025"
  },
  {
    "n": "Indigo Québec",
    "u": "https://www.indigo.ca/fr-ca",
    "c": "Culture",
    "d": "Librairies Chapters Indigo",
    "date": "2025"
  },
  {
    "n": "Frite Alors!",
    "u": "https://fritealors.com",
    "c": "Commerce",
    "d": "Friterie belge Québec",
    "date": "2025"
  },
  {
    "n": "La Banquise",
    "u": "https://labanquise.com",
    "c": "Commerce",
    "d": "Poutine 24h Montréal",
    "date": "2025"
  },
  {
    "n": "Chez Claudette",
    "u": "https://chezclaudette.com",
    "c": "Commerce",
    "d": "Poutine Montréal",
    "date": "2025"
  },
  {
    "n": "Maamm Bolduc",
    "u": "https://maammbolduc.com",
    "c": "Commerce",
    "d": "Poutine institution",
    "date": "2025"
  },
  {
    "n": "Patati Patata",
    "u": "https://patatipatata.ca",
    "c": "Commerce",
    "d": "Poutine mini format",
    "date": "2025"
  },
  {
    "n": "Poutineville",
    "u": "https://poutineville.com",
    "c": "Commerce",
    "d": "Poutine personnalisée",
    "date": "2025"
  },
  {
    "n": "Décarie Hot Dog",
    "u": "https://decariehotdog.com",
    "c": "Commerce",
    "d": "Hot dog steamé Montréal",
    "date": "2025"
  },
  {
    "n": "Montreal Pool Room",
    "u": "https://montrealpoolroom.com",
    "c": "Commerce",
    "d": "Hot dog steamé historique",
    "date": "2025"
  },
  {
    "n": "Lafleur",
    "u": "https://lafleur.ca",
    "c": "Commerce",
    "d": "Hot dog et poutine chaîne",
    "date": "2025"
  },
  {
    "n": "St-Hubert",
    "u": "https://www.st-hubert.com",
    "c": "Commerce",
    "d": "Poulet rôti Québec",
    "date": "2025"
  },
  {
    "n": "Scores",
    "u": "https://scores.ca",
    "c": "Commerce",
    "d": "Poulet grill Québec",
    "date": "2025"
  },
  {
    "n": "Cage aux Sports",
    "u": "https://cage.ca",
    "c": "Commerce",
    "d": "Resto sportif Québec",
    "date": "2025"
  },
  {
    "n": "Bâton Rouge",
    "u": "https://batonrouge.ca",
    "c": "Commerce",
    "d": "Grill steak Québec",
    "date": "2025"
  },
  {
    "n": "Mikes",
    "u": "https://mikes.ca",
    "c": "Commerce",
    "d": "Pizza et sous-marin Québec",
    "date": "2025"
  },
  {
    "n": "Pizza Salvatore",
    "u": "https://salvatore.com",
    "c": "Commerce",
    "d": "Pizza Québec",
    "date": "2025"
  },
  {
    "n": "Stratos Pizzeria",
    "u": "https://stratospizzeria.com",
    "c": "Commerce",
    "d": "Poutine pizza Montréal",
    "date": "2025"
  },
  {
    "n": "Tim Hortons Québec",
    "u": "https://timhortons.ca",
    "c": "Commerce",
    "d": "Café beignes omniprésent",
    "date": "2025"
  },
  {
    "n": "Second Cup Québec",
    "u": "https://secondcup.com",
    "c": "Commerce",
    "d": "Café québécois",
    "date": "2025"
  },
  {
    "n": "Brûlerie Saint-Denis",
    "u": "https://brulerie.com",
    "c": "Commerce",
    "d": "Café torréfié Québec",
    "date": "2025"
  },
  {
    "n": "Toi Moi & Café",
    "u": "https://toimoicafe.com",
    "c": "Commerce",
    "d": "Café de quartier",
    "date": "2025"
  },
  {
    "n": "Paquebot",
    "u": "https://paquebot.ca",
    "c": "Commerce",
    "d": "Café troisième vague Montréal",
    "date": "2025"
  },
  {
    "n": "Café Myriade",
    "u": "https://cafemyriade.com",
    "c": "Commerce",
    "d": "Café spécialisé",
    "date": "2025"
  },
  {
    "n": "Pikolo Espresso Bar",
    "u": "https://pikoloespresso.com",
    "c": "Commerce",
    "d": "Café centre-ville",
    "date": "2025"
  },
  {
    "n": "Dispatch Coffee",
    "u": "https://dispatchcoffee.ca",
    "c": "Commerce",
    "d": "Café écoresponsable",
    "date": "2025"
  },
  {
    "n": "Noble Café",
    "u": "https://noblecafe.com",
    "c": "Commerce",
    "d": "Café Mile End",
    "date": "2025"
  },
  {
    "n": "Falco",
    "u": "https://falco.ca",
    "c": "Commerce",
    "d": "Café japonais Mile End",
    "date": "2025"
  },
  {
    "n": "Bagels Fairmount",
    "u": "https://fairmountbagel.com",
    "c": "Commerce",
    "d": "Bagels Montréal 24h",
    "date": "2025"
  },
  {
    "n": "St-Viateur Bagel",
    "u": "https://stviateurbagel.com",
    "c": "Commerce",
    "d": "Bagels institution",
    "date": "2025"
  },
  {
    "n": "Beauty's",
    "u": "https://beautys.ca",
    "c": "Commerce",
    "d": "Brunch Montréal 1942",
    "date": "2025"
  },
  {
    "n": "Laronde",
    "u": "https://laronde.com",
    "c": "Commerce",
    "d": "Parc d'attractions Montréal",
    "date": "2025"
  },
  {
    "n": "Biodôme",
    "u": "https://biodome.ca",
    "c": "Culture",
    "d": "Écosystèmes vivants",
    "date": "2025"
  },
  {
    "n": "Planétarium Rio Tinto Alcan",
    "u": "https://espacepourlavie.ca/planetarium",
    "c": "Culture",
    "d": "Planétarium Montréal",
    "date": "2025"
  },
  {
    "n": "Jardin botanique",
    "u": "https://espacepourlavie.ca/jardin-botanique",
    "c": "Culture",
    "d": "Plus grand jardin botanique Canada",
    "date": "2025"
  },
  {
    "n": "Insectarium",
    "u": "https://espacepourlavie.ca/insectarium",
    "c": "Culture",
    "d": "Insectes vivants",
    "date": "2025"
  },
  {
    "n": "Biosphère",
    "u": "https://espacepourlavie.ca/biosphere",
    "c": "Culture",
    "d": "Musée environnement Buckminster Fuller",
    "date": "2025"
  },
  {
    "n": "Parc Jean-Drapeau",
    "u": "https://parcjeandrapeau.com",
    "c": "Culture",
    "d": "Île Sainte-Hélène et Notre-Dame",
    "date": "2025"
  },
  {
    "n": "Casino de Montréal",
    "u": "https://casinos.lotoquebec.com/fr/montreal",
    "c": "Commerce",
    "d": "Casino Loto-Québec",
    "date": "2025"
  },
  {
    "n": "Marché Jean-Talon",
    "u": "https://marchejeantalon.com",
    "c": "Commerce",
    "d": "Plus grand marché public Amérique Nord",
    "date": "2025"
  },
  {
    "n": "Marché Atwater",
    "u": "https://marchespublics-mtl.com/marches/atwater",
    "c": "Commerce",
    "d": "Marché historique canal Lachine",
    "date": "2025"
  },
  {
    "n": "Marché Maisonneuve",
    "u": "https://marchespublics-mtl.com/marches/maisonneuve",
    "c": "Commerce",
    "d": "Marché Hochelaga",
    "date": "2025"
  },
  {
    "n": "Vieux-Port de Montréal",
    "u": "https://vieuxportdemontreal.com",
    "c": "Tourisme",
    "d": "Site historique et récréatif",
    "date": "2025"
  },
  {
    "n": "Mont Royal",
    "u": "https://mont-royal.ca",
    "c": "Tourisme",
    "d": "Parc montagne Montréal",
    "date": "2025"
  },
  {
    "n": "Parc La Fontaine",
    "u": "https://montreal.ca/parcs/parc-la-fontaine",
    "c": "Tourisme",
    "d": "Parc Plateau",
    "date": "2025"
  },
  {
    "n": "Parc Jarry",
    "u": "https://montreal.ca/parcs/parc-jarry",
    "c": "Tourisme",
    "d": "Parc Villeray tennis",
    "date": "2025"
  },
  {
    "n": "Canal Lachine",
    "u": "https://parcscanada.gc.ca/lachine",
    "c": "Tourisme",
    "d": "Piste cyclable historique",
    "date": "2025"
  },
  {
    "n": "Quartier des Spectacles",
    "u": "https://quartierdesspectacles.com",
    "c": "Culture",
    "d": "Cœur festivals Montréal",
    "date": "2025"
  },
  {
    "n": "Village gai",
    "u": "https://le-village.ca",
    "c": "Tourisme",
    "d": "Village LGBTQ+ Montréal",
    "date": "2025"
  },
  {
    "n": "Plateau-Mont-Royal",
    "u": "https://montreal.ca/quartiers/plateau-mont-royal",
    "c": "Tourisme",
    "d": "Quartier emblématique Montréal",
    "date": "2025"
  },
  {
    "n": "Mile End",
    "u": "https://mile-end.mtl",
    "c": "Tourisme",
    "d": "Quartier hipster Montréal",
    "date": "2025"
  },
  {
    "n": "Hochelaga-Maisonneuve",
    "u": "https://homa-mtl.com",
    "c": "Tourisme",
    "d": "Quartier populaire Est Montréal",
    "date": "2025"
  },
  {
    "n": "Petite Italie",
    "u": "https://petiteitalie.com",
    "c": "Tourisme",
    "d": "Quartier italien Montréal",
    "date": "2025"
  },
  {
    "n": "Chinatown Montréal",
    "u": "https://montrealchinatown.com",
    "c": "Tourisme",
    "d": "Quartier chinois",
    "date": "2025"
  },
  {
    "n": "Vieux-Montréal",
    "u": "https://vieuxmontreal.ca",
    "c": "Tourisme",
    "d": "Site historique fondateur",
    "date": "2025"
  },
  {
    "n": "Îles-de-Boucherville",
    "u": "https://www.sepaq.com/pq/ilb",
    "c": "Tourisme",
    "d": "Parc national archipel",
    "date": "2025"
  },
  {
    "n": "Parc national du Mont-Tremblant",
    "u": "https://www.sepaq.com/pq/mot",
    "c": "Tourisme",
    "d": "Parc Laurentides",
    "date": "2025"
  },
  {
    "n": "Parc de la Gatineau",
    "u": "https://ncc-ccn.gc.ca/lieux/parc-de-la-gatineau",
    "c": "Tourisme",
    "d": "Parc Outaouais",
    "date": "2025"
  },
  {
    "n": "Parc Omega",
    "u": "https://parcomega.ca",
    "c": "Tourisme",
    "d": "Safari animaux Outaouais",
    "date": "2025"
  },
  {
    "n": "Village québécois d'antan",
    "u": "https://villagequebecois.com",
    "c": "Tourisme",
    "d": "Village historique Drummondville",
    "date": "2025"
  },
  {
    "n": "Zoo de Granby",
    "u": "https://zoodegranby.com",
    "c": "Tourisme",
    "d": "Plus grand zoo Québec",
    "date": "2025"
  },
  {
    "n": "Zoo de Saint-Édouard",
    "u": "https://zoosaint-edouard.com",
    "c": "Tourisme",
    "d": "Zoo privé Québec",
    "date": "2025"
  },
  {
    "n": "Bioparc de la Gaspésie",
    "u": "https://bioparc.ca",
    "c": "Tourisme",
    "d": "Animaux faune québécoise Bonaventure",
    "date": "2025"
  },
  {
    "n": "Aquarium du Québec",
    "u": "https://www.sepaq.com/aquarium",
    "c": "Tourisme",
    "d": "Aquarium Québec ville",
    "date": "2025"
  },
  {
    "n": "Centre des sciences de Montréal",
    "u": "https://centredessciencesdemontreal.com",
    "c": "Culture",
    "d": "Musée science Vieux-Port",
    "date": "2025"
  },
  {
    "n": "Pointe-à-Callière",
    "u": "https://pointe-a-calliere.qc.ca",
    "c": "Culture",
    "d": "Musée archéologie histoire Montréal",
    "date": "2025"
  },
  {
    "n": "Musée d'art contemporain",
    "u": "https://macm.org",
    "c": "Culture",
    "d": "Art contemporain Montréal",
    "date": "2025"
  },
  {
    "n": "Musée McCord",
    "u": "https://musee-mccord.qc.ca",
    "c": "Culture",
    "d": "Histoire sociale Montréal",
    "date": "2025"
  },
  {
    "n": "Musée Redpath",
    "u": "https://www.mcgill.ca/redpath",
    "c": "Culture",
    "d": "Histoire naturelle McGill",
    "date": "2025"
  },
  {
    "n": "Château Ramezay",
    "u": "https://chateauramezay.qc.ca",
    "c": "Culture",
    "d": "Musée histoire Montréal",
    "date": "2025"
  },
  {
    "n": "Écomusée Montréal",
    "u": "https://ecomusee.qc.ca",
    "c": "Culture",
    "d": "Patrimoine industriel",
    "date": "2025"
  },
  {
    "n": "Musée Marguerite-Bourgeoys",
    "u": "https://marguerite-bourgeoys.com",
    "c": "Culture",
    "d": "Première école Montréal",
    "date": "2025"
  },
  {
    "n": "Musée Grévin Montréal",
    "u": "https://grevinnontreal.com",
    "c": "Culture",
    "d": "Musée cire",
    "date": "2025"
  },
  {
    "n": "SOS Labyrinthe",
    "u": "https://soslabyrinthe.ca",
    "c": "Culture",
    "d": "Labyrinthe Vieux-Port",
    "date": "2025"
  },
  {
    "n": "iSci",
    "u": "https://centredessciencesdemontreal.com/isci",
    "c": "Culture",
    "d": "Science interactive",
    "date": "2025"
  },
  {
    "n": "Voiles en Voiles",
    "u": "https://voilesenvoiles.com",
    "c": "Culture",
    "d": "Parc aventure Vieux-Port",
    "date": "2025"
  },
  {
    "n": "Baggagerie du Vieux-Montréal",
    "u": "https://baggagerie.com",
    "c": "Tourisme",
    "d": "Consigne bagages",
    "date": "2025"
  },
  {
    "n": "Ça Roule Montréal",
    "u": "https://caroulemontreal.com",
    "c": "Tourisme",
    "d": "Location vélos Bixi",
    "date": "2025"
  },
  {
    "n": "Guidatour",
    "u": "https://guidatour.qc.ca",
    "c": "Tourisme",
    "d": "Visites guidées Vieux-Montréal",
    "date": "2025"
  },
  {
    "n": "Local Montréal Tours",
    "u": "https://localmontrealtours.com",
    "c": "Tourisme",
    "d": "Visites guidées locales",
    "date": "2025"
  },
  {
    "n": "Spade & Palacio",
    "u": "https://spadeandpalacio.com",
    "c": "Tourisme",
    "d": "Tours non touristiques Montréal",
    "date": "2025"
  },
  {
    "n": "Fitz Montréal Bike Tours",
    "u": "https://fitz.tours",
    "c": "Tourisme",
    "d": "Tours vélo Montréal",
    "date": "2025"
  },
  {
    "n": "Dyad Cycle Tours",
    "u": "https://dyad.ca",
    "c": "Tourisme",
    "d": "Tours scooter électrique",
    "date": "2025"
  },
  {
    "n": "MTL Detours",
    "u": "https://mtldetours.com",
    "c": "Tourisme",
    "d": "Visites guidées à pied",
    "date": "2025"
  },
  {
    "n": "Ghost Tours Montréal",
    "u": "https://fantomesmontreal.com",
    "c": "Tourisme",
    "d": "Tours hantés Vieux-Montréal",
    "date": "2025"
  },
  {
    "n": "La Balade à Toronto",
    "u": "https://labalade.ca",
    "c": "Tourisme",
    "d": "Visites guidées Toronto francophone",
    "date": "2025"
  },
  {
    "n": "Amphi-Tour",
    "u": "https://amphi-tour.com",
    "c": "Tourisme",
    "d": "Amphibus Vieux-Québec",
    "date": "2025"
  },
  {
    "n": "Cyclo Services Québec",
    "u": "https://cycloservices.net",
    "c": "Tourisme",
    "d": "Location vélos Québec",
    "date": "2025"
  },
  {
    "n": "Ghost Tours Québec",
    "u": "https://ghosttoursofquebec.com",
    "c": "Tourisme",
    "d": "Visites hantées Québec",
    "date": "2025"
  },
  {
    "n": "Unitours Québec",
    "u": "https://unitours.com",
    "c": "Tourisme",
    "d": "Autobus touristiques Québec",
    "date": "2025"
  },
  {
    "n": "Kava Tours",
    "u": "https://kavatours.ca",
    "c": "Tourisme",
    "d": "Visites guidées Montréal",
    "date": "2025"
  },
  {
    "n": "Vieux-Port de Québec",
    "u": "https://vieuxportdequebec.com",
    "c": "Tourisme",
    "d": "Port historique Québec",
    "date": "2025"
  },
  {
    "n": "Plaines d'Abraham",
    "u": "https://theplainsofabraham.ca",
    "c": "Tourisme",
    "d": "Parc historique Québec",
    "date": "2025"
  },
  {
    "n": "Château Frontenac",
    "u": "https://www.fairmont.com/fr/frontenac-quebec",
    "c": "Tourisme",
    "d": "Hôtel emblématique Québec",
    "date": "2025"
  },
  {
    "n": "Hôtel de Glace",
    "u": "https://www.hoteldeglace-canada.com",
    "c": "Tourisme",
    "d": "Hôtel de glace Québec",
    "date": "2025"
  },
  {
    "n": "Village Vacances Valcartier",
    "u": "https://valcartier.com",
    "c": "Tourisme",
    "d": "Parc aquatique glissades hiver",
    "date": "2025"
  },
  {
    "n": "Mont-Sainte-Anne",
    "u": "https://mont-sainte-anne.com",
    "c": "Tourisme",
    "d": "Ski et vélo montagne",
    "date": "2025"
  },
  {
    "n": "Stoneham",
    "u": "https://ski-stoneham.com",
    "c": "Tourisme",
    "d": "Station ski près Québec",
    "date": "2025"
  },
  {
    "n": "Le Massif de Charlevoix",
    "u": "https://www.lemassif.com",
    "c": "Tourisme",
    "d": "Ski vue fleuve",
    "date": "2025"
  },
  {
    "n": "Tremblant",
    "u": "https://www.tremblant.ca",
    "c": "Tourisme",
    "d": "Station ski Laurentides",
    "date": "2025"
  },
  {
    "n": "Mont Saint-Sauveur",
    "u": "https://montsaintsauveur.com",
    "c": "Tourisme",
    "d": "Ski de soirée Laurentides",
    "date": "2025"
  },
  {
    "n": "Bromont",
    "u": "https://bromont.com",
    "c": "Tourisme",
    "d": "Ski et parc aquatique",
    "date": "2025"
  },
  {
    "n": "Sutton",
    "u": "https://montsutton.com",
    "c": "Tourisme",
    "d": "Ski Cantons-de-l'Est",
    "date": "2025"
  },
  {
    "n": "Orford",
    "u": "https://orford.com",
    "c": "Tourisme",
    "d": "Ski et golf Estrie",
    "date": "2025"
  },
  {
    "n": "Owl's Head",
    "u": "https://owlshead.com",
    "c": "Tourisme",
    "d": "Ski Memphrémagog",
    "date": "2025"
  },
  {
    "n": "Station touristique Duchesnay",
    "u": "https://sepaq.com/duchesnay",
    "c": "Tourisme",
    "d": "Plein air près Québec",
    "date": "2025"
  },
  {
    "n": "Parc de la Chute-Montmorency",
    "u": "https://www.sepaq.com/chutemontmorency",
    "c": "Tourisme",
    "d": "Chute plus haute Niagara",
    "date": "2025"
  },
  {
    "n": "Île d'Orléans",
    "u": "https://iledorleans.com",
    "c": "Tourisme",
    "d": "Île gourmande Québec",
    "date": "2025"
  },
  {
    "n": "Wendake",
    "u": "https://tourismewendake.ca",
    "c": "Tourisme",
    "d": "Communauté huronne-wendat",
    "date": "2025"
  },
  {
    "n": "Charlevoix",
    "u": "https://tourisme-charlevoix.com",
    "c": "Tourisme",
    "d": "Région UNESCO",
    "date": "2025"
  },
  {
    "n": "Gaspésie",
    "u": "https://tourisme-gaspesie.com",
    "c": "Tourisme",
    "d": "Tour de la Gaspésie",
    "date": "2025"
  },
  {
    "n": "Îles-de-la-Madeleine",
    "u": "https://tourismeilesdelamadeleine.com",
    "c": "Tourisme",
    "d": "Archipel golfe Saint-Laurent",
    "date": "2025"
  },
  {
    "n": "Saguenay–Lac-Saint-Jean",
    "u": "https://saguenaylacsaintjean.ca",
    "c": "Tourisme",
    "d": "Région fjord et bleuets",
    "date": "2025"
  },
  {
    "n": "Mauricie",
    "u": "https://tourismemauricie.com",
    "c": "Tourisme",
    "d": "Parc national Mauricie",
    "date": "2025"
  },
  {
    "n": "Lanaudière",
    "u": "https://tourismelanaudiere.com",
    "c": "Tourisme",
    "d": "Région lacs et forêts",
    "date": "2025"
  },
  {
    "n": "Laurentides",
    "u": "https://laurentides.com",
    "c": "Tourisme",
    "d": "Ski et villégiature",
    "date": "2025"
  },
  {
    "n": "Cantons-de-l'Est",
    "u": "https://cantonsdelest.com",
    "c": "Tourisme",
    "d": "Vignobles et villages",
    "date": "2025"
  },
  {
    "n": "Outaouais",
    "u": "https://tourismeoutaouais.com",
    "c": "Tourisme",
    "d": "Gatineau et nature",
    "date": "2025"
  },
  {
    "n": "Abitibi-Témiscamingue",
    "u": "https://tourisme-abitibi-temiscamingue.org",
    "c": "Tourisme",
    "d": "Or et forêts",
    "date": "2025"
  },
  {
    "n": "Côte-Nord",
    "u": "https://tourismecote-nord.com",
    "c": "Tourisme",
    "d": "Baleines et Manicouagan",
    "date": "2025"
  },
  {
    "n": "Bas-Saint-Laurent",
    "u": "https://bssaintlaurent.ca",
    "c": "Tourisme",
    "d": "Fleuve et phares",
    "date": "2025"
  },
  {
    "n": "Centre-du-Québec",
    "u": "https://tourismecentreduquebec.com",
    "c": "Tourisme",
    "d": "Région Drummondville Victoriaville",
    "date": "2025"
  },
  {
    "n": "Chaudière-Appalaches",
    "u": "https://chaudiereappalaches.com",
    "c": "Tourisme",
    "d": "Beauce et Lévis",
    "date": "2025"
  },
  {
    "n": "Montérégie",
    "u": "https://tourismemonteregie.ca",
    "c": "Tourisme",
    "d": "Vignobles et Fort Chambly",
    "date": "2025"
  },
  {
    "n": "Laval",
    "u": "https://tourismelaval.com",
    "c": "Tourisme",
    "d": "Île Jésus Montréal",
    "date": "2025"
  },
  {
    "n": "Québec Original",
    "u": "https://www.quebecoriginal.com",
    "c": "Tourisme",
    "d": "Tourisme officiel Québec",
    "date": "2025"
  },
  {
    "n": "Bonjour Québec",
    "u": "https://www.bonjourquebec.com",
    "c": "Tourisme",
    "d": "Portail tourisme gouvernemental",
    "date": "2025"
  },
  {
    "n": "Réseau de veille touristique",
    "u": "https://veilletouristique.ca",
    "c": "Tourisme",
    "d": "Observatoire tourisme Québec",
    "date": "2025"
  },
  {
    "n": "Chaises musicales",
    "u": "https://chaisesmusicales.com",
    "c": "Culture",
    "d": "Événements culturels Québec",
    "date": "2025"
  },
  {
    "n": "Québec Issime",
    "u": "https://quebecissime.com",
    "c": "Culture",
    "d": "Spectacle musique québécoise",
    "date": "2025"
  },
  {
    "n": "Capitole de Québec",
    "u": "https://lecapitole.com",
    "c": "Culture",
    "d": "Théâtre et spectacles Québec",
    "date": "2025"
  },
  {
    "n": "Palais Montcalm",
    "u": "https://palaismontcalm.ca",
    "c": "Culture",
    "d": "Musique classique Québec",
    "date": "2025"
  },
  {
    "n": "Grand Théâtre de Québec",
    "u": "https://grandtheatre.qc.ca",
    "c": "Culture",
    "d": "Opéra théâtre Québec",
    "date": "2025"
  },
  {
    "n": "Impérial Bell",
    "u": "https://imperialbell.com",
    "c": "Culture",
    "d": "Salle spectacles Québec",
    "date": "2025"
  },
  {
    "n": "Théâtre du Trident",
    "u": "https://letrident.com",
    "c": "Culture",
    "d": "Théâtre Québec",
    "date": "2025"
  },
  {
    "n": "Théâtre Périscope",
    "u": "https://theatreperiscope.qc.ca",
    "c": "Culture",
    "d": "Théâtre création Québec",
    "date": "2025"
  },
  {
    "n": "Duceppe",
    "u": "https://duceppe.com",
    "c": "Culture",
    "d": "Théâtre contemporain Montréal",
    "date": "2025"
  },
  {
    "n": "Théâtre Jean-Duceppe",
    "u": "https://placedesarts.com/programmation/jean-duceppe",
    "c": "Culture",
    "d": "Grande salle Place des Arts",
    "date": "2025"
  },
  {
    "n": "Théâtre du Rideau Vert",
    "u": "https://rideauvert.qc.ca",
    "c": "Culture",
    "d": "Plus ancien théâtre Montréal",
    "date": "2025"
  },
  {
    "n": "Théâtre Espace Go",
    "u": "https://espacego.com",
    "c": "Culture",
    "d": "Théâtre femmes création",
    "date": "2025"
  },
  {
    "n": "Théâtre La Licorne",
    "u": "https://theatrelalicorne.com",
    "c": "Culture",
    "d": "Théâtre création contemporaine",
    "date": "2025"
  },
  {
    "n": "Usine C",
    "u": "https://usine-c.com",
    "c": "Culture",
    "d": "Théâtre expérimental",
    "date": "2025"
  },
  {
    "n": "Cinquième Salle",
    "u": "https://placedesarts.com",
    "c": "Culture",
    "d": "Théâtre intime Place des Arts",
    "date": "2025"
  },
  {
    "n": "Théâtre de Quat'Sous",
    "u": "https://quat-sous.com",
    "c": "Culture",
    "d": "Théâtre création Montréal",
    "date": "2025"
  },
  {
    "n": "Théâtre Prospero",
    "u": "https://theatreprospero.com",
    "c": "Culture",
    "d": "Théâtre de création",
    "date": "2025"
  },
  {
    "n": "Segal Centre",
    "u": "https://segalcentre.org",
    "c": "Culture",
    "d": "Théâtre anglophone mais programmation FR",
    "date": "2025"
  },
  {
    "n": "Opéra de Québec",
    "u": "https://operadequebec.com",
    "c": "Culture",
    "d": "Opéra Québec ville",
    "date": "2025"
  },
  {
    "n": "L'Olympia",
    "u": "https://theolympia.com",
    "c": "Culture",
    "d": "Salle historique Montréal",
    "date": "2025"
  },
  {
    "n": "Corona Theatre",
    "u": "https://thecorona.ca",
    "c": "Culture",
    "d": "Théâtre Virginie",
    "date": "2025"
  },
  {
    "n": "Beanfield Theatre",
    "u": "https://beanfieldtheatre.com",
    "c": "Culture",
    "d": "Ancien Corona",
    "date": "2025"
  },
  {
    "n": "Salle Wilfrid-Pelletier",
    "u": "https://placedesarts.com",
    "c": "Culture",
    "d": "Plus grande salle Montréal",
    "date": "2025"
  },
  {
    "n": "Maison symphonique",
    "u": "https://maisonesymphonique.com",
    "c": "Culture",
    "d": "Salle OSM acoustique parfaite",
    "date": "2025"
  },
  {
    "n": "Cinéma du Parc",
    "u": "https://cinemaduparc.com",
    "c": "Culture",
    "d": "Cinéma indépendant",
    "date": "2025"
  },
  {
    "n": "Cinéma Impérial",
    "u": "https://cinemaimperial.com",
    "c": "Culture",
    "d": "Cinéma patrimoine",
    "date": "2025"
  },
  {
    "n": "Cinéma Moderne",
    "u": "https://cinemamoderne.com",
    "c": "Culture",
    "d": "Cinéma art et essai",
    "date": "2025"
  },
  {
    "n": "Cinéma Public",
    "u": "https://cinemapublic.ca",
    "c": "Culture",
    "d": "Cinéma documentaire",
    "date": "2025"
  },
  {
    "n": "Cinéma du Musée",
    "u": "https://mbam.qc.ca/cinema",
    "c": "Culture",
    "d": "Cinéma MBAM",
    "date": "2025"
  },
  {
    "n": "Excentris (maintenant fermé mais historique)",
    "u": "https://fr.wikipedia.org/wiki/Excentris",
    "c": "Culture",
    "d": "Cinéma parallèle",
    "date": "2025"
  },
  {
    "n": "Festival de cinéma québécois Cinemania",
    "u": "https://cinemaniafilms.org",
    "c": "Culture",
    "d": "Cinéma francophone Montréal",
    "date": "2025"
  },
  {
    "n": "Fantasia",
    "u": "https://fantasiafestival.com",
    "c": "Culture",
    "d": "Fantastique et genre",
    "date": "2025"
  },
  {
    "n": "FNC",
    "u": "https://nouveaucinema.ca",
    "c": "Culture",
    "d": "Nouveau cinéma",
    "date": "2025"
  },
  {
    "n": "Image+Nation",
    "u": "https://image-nation.org",
    "c": "Culture",
    "d": "Festival LGBTQ+",
    "date": "2025"
  },
  {
    "n": "Présence autochtone",
    "u": "https://nativementv.com",
    "c": "Culture",
    "d": "Cinéma et arts autochtones",
    "date": "2025"
  },
  {
    "n": "Regard Saguenay",
    "u": "https://regard.org",
    "c": "Culture",
    "d": "Court-métrage international",
    "date": "2025"
  },
  {
    "n": "Abribus",
    "u": "https://abribus.ca",
    "c": "Culture",
    "d": "Festival film étudiant",
    "date": "2025"
  },
  {
    "n": "Longue vue sur le court",
    "u": "https://longuevuesurlecourt.com",
    "c": "Culture",
    "d": "Court-métrage Québec",
    "date": "2025"
  },
  {
    "n": "Kino",
    "u": "https://kino00.com",
    "c": "Culture",
    "d": "Mouvement cinéma guérilla",
    "date": "2025"
  },
  {
    "n": "Slam Montréal",
    "u": "https://slamontreal.com",
    "c": "Culture",
    "d": "Poésie slam",
    "date": "2025"
  },
  {
    "n": "Poetry Slam Québec",
    "u": "https://slamquebec.com",
    "c": "Culture",
    "d": "Compétitions slam",
    "date": "2025"
  },
  {
    "n": "Maison de la littérature",
    "u": "https://maisondelalitterature.qc.ca",
    "c": "Culture",
    "d": "Bibliothèque littéraire Québec",
    "date": "2025"
  },
  {
    "n": "Foire du livre de Bruxelles section Québec",
    "u": "https://flb.be",
    "c": "Culture",
    "d": "Québec invité d'honneur",
    "date": "2025"
  },
  {
    "n": "Foire du livre de Francfort Québec",
    "u": "https://buchmesse.de",
    "c": "Culture",
    "d": "Marché droits internationaux",
    "date": "2025"
  },
  {
    "n": "Livres comme l'air",
    "u": "https://livrescommelair.org",
    "c": "Culture",
    "d": "Livres pour détenus",
    "date": "2025"
  },
  {
    "n": "Union des écrivaines et écrivains québécois (UNEQ)",
    "u": "https://uneq.qc.ca",
    "c": "Culture",
    "d": "Syndicat auteurs Québec",
    "date": "2025"
  },
  {
    "n": "Association nationale des éditeurs de livres (ANEL)",
    "u": "https://anel.qc.ca",
    "c": "Culture",
    "d": "Édition Québec",
    "date": "2025"
  },
  {
    "n": "Bibliothèques Québec",
    "u": "https://www.bibliothequesdequebec.qc.ca",
    "c": "Culture",
    "d": "Réseau bibliothèques publiques",
    "date": "2025"
  },
  {
    "n": "Réseau BIBLIO du Québec",
    "u": "https://reseaubiblioqca.ca",
    "c": "Culture",
    "d": "Bibliothèques régionales",
    "date": "2025"
  },
  {
    "n": "Asted",
    "u": "https://asted.org",
    "c": "Culture",
    "d": "Bibliothéconomie Québec",
    "date": "2025"
  },
  {
    "n": "Association des libraires du Québec (ALQ)",
    "u": "https://alq.qc.ca",
    "c": "Culture",
    "d": "Libraires indépendants Québec",
    "date": "2025"
  },
  {
    "n": "Les Libraires",
    "u": "https://leslibraires.ca",
    "c": "Culture",
    "d": "Portail librairies indépendantes",
    "date": "2025"
  },
  {
    "n": "Librairie Pantoute",
    "u": "https://librairiepantoute.com",
    "c": "Culture",
    "d": "Librairie Québec ville",
    "date": "2025"
  },
  {
    "n": "Librairie Le Port de tête",
    "u": "https://leportdetete.com",
    "c": "Culture",
    "d": "Librairie Plateau Montréal",
    "date": "2025"
  },
  {
    "n": "Librairie Gallimard",
    "u": "https://librairiegallimard.com",
    "c": "Culture",
    "d": "Librairie Parisienne Montréal",
    "date": "2025"
  },
  {
    "n": "Librairie Olivieri",
    "u": "https://librairieolivieri.com",
    "c": "Culture",
    "d": "Librairie bistro",
    "date": "2025"
  },
  {
    "n": "Librairie de Verdun",
    "u": "https://librairiedeverdun.com",
    "c": "Culture",
    "d": "Librairie Verdun",
    "date": "2025"
  },
  {
    "n": "Librairie Moderne",
    "u": "https://librairiemoderne.ca",
    "c": "Culture",
    "d": "Saint-Jean-sur-Richelieu",
    "date": "2025"
  },
  {
    "n": "Librairie Raffin",
    "u": "https://raffin.ca",
    "c": "Culture",
    "d": "Chaîne librairies Québec",
    "date": "2025"
  },
  {
    "n": "Librairie Renaud-Bray",
    "u": "https://renaud-bray.com",
    "c": "Culture",
    "d": "Plus grande chaîne Québec",
    "date": "2025"
  },
  {
    "n": "Librairie Paulines",
    "u": "https://librairiepaulines.ca",
    "c": "Culture",
    "d": "Spirituelle Montréal",
    "date": "2025"
  },
  {
    "n": "Librairie Le Fureteur",
    "u": "https://lefureteur.com",
    "c": "Culture",
    "d": "Saint-Lambert",
    "date": "2025"
  },
  {
    "n": "Librairie Carcajou",
    "u": "https://carcajou.ca",
    "c": "Culture",
    "d": "Rosemère",
    "date": "2025"
  },
  {
    "n": "Librairie Monet",
    "u": "https://librairiemonet.com",
    "c": "Culture",
    "d": "McGill ghetto",
    "date": "2025"
  },
  {
    "n": "Librairie Bertrand",
    "u": "https://librairiebertrand.com",
    "c": "Culture",
    "d": "Vieux-Québec",
    "date": "2025"
  },
  {
    "n": "Librairie du Square",
    "u": "https://librairiedusquare.com",
    "c": "Culture",
    "d": "Outremont",
    "date": "2025"
  },
  {
    "n": "Librairie Millepages",
    "u": "https://millepages.ca",
    "c": "Culture",
    "d": "Val-David Laurentides",
    "date": "2025"
  },
  {
    "n": "Librairie L'Écuyer",
    "u": "https://librairielecuyer.com",
    "c": "Culture",
    "d": "Trois-Rivières",
    "date": "2025"
  },
  {
    "n": "Librairie Les Bouquinistes",
    "u": "https://lesbouquinistes.ca",
    "c": "Culture",
    "d": "Chicoutimi",
    "date": "2025"
  },
  {
    "n": "Librairie Vieux Bouc",
    "u": "https://vieuxbouc.com",
    "c": "Culture",
    "d": "Shawinigan",
    "date": "2025"
  },
  {
    "n": "Librairie Morency",
    "u": "https://librairiemorency.com",
    "c": "Culture",
    "d": "Québec ville",
    "date": "2025"
  },
  {
    "n": "Librairie La Liberté",
    "u": "https://laliberte.qc.ca",
    "c": "Culture",
    "d": "Québec ville",
    "date": "2025"
  },
  {
    "n": "Librairie Au Carrefour",
    "u": "https://aucarrefour.com",
    "c": "Culture",
    "d": "Drummondville",
    "date": "2025"
  },
  {
    "n": "Librairie Appalaches",
    "u": "https://librairieappalaches.com",
    "c": "Culture",
    "d": "Thetford Mines",
    "date": "2025"
  },
  {
    "n": "Librairie Sélect",
    "u": "https://librairieselect.com",
    "c": "Culture",
    "d": "Longueuil",
    "date": "2025"
  },
  {
    "n": "Librairie Laurier",
    "u": "https://librairielaurier.com",
    "c": "Culture",
    "d": "Victoriaville",
    "date": "2025"
  },
  {
    "n": "Librairie Biblairie GGC",
    "u": "https://biblairieggc.com",
    "c": "Culture",
    "d": "Gatineau",
    "date": "2025"
  },
  {
    "n": "Librairie Rose-Dragon",
    "u": "https://rosedragon.ca",
    "c": "Culture",
    "d": "Jonquière",
    "date": "2025"
  },
  {
    "n": "Librairie Les Libraires",
    "u": "https://leslibraires.ca",
    "c": "Culture",
    "d": "Collectif librairies indépendantes",
    "date": "2025"
  },
  {
    "n": "Coopérative libraires indépendants",
    "u": "https://leslibraires.ca/cooperative",
    "c": "Culture",
    "d": "Réseau libraires Québec",
    "date": "2025"
  },
  {
    "n": "Fête de la lecture et du livre jeunesse",
    "u": "https://fetelecturejeunesse.com",
    "c": "Culture",
    "d": "Événements jeunesse",
    "date": "2025"
  },
  {
    "n": "Salon du livre jeunesse de Longueuil",
    "u": "https://salonlivresjeunesse.com",
    "c": "Culture",
    "d": "Livre jeunesse Montérégie",
    "date": "2025"
  },
  {
    "n": "Salon du livre de l'Outaouais jeunesse",
    "u": "https://slo.qc.ca/jeunesse",
    "c": "Culture",
    "d": "Section jeunesse Gatineau",
    "date": "2025"
  },
  {
    "n": "Communication-Jeunesse",
    "u": "https://communication-jeunesse.qc.ca",
    "c": "Culture",
    "d": "Littérature jeunesse Québec",
    "date": "2025"
  },
  {
    "n": "Prix TD littérature jeunesse",
    "u": "https://prixtd.ca",
    "c": "Culture",
    "d": "Prix livre jeunesse canadien",
    "date": "2025"
  },
  {
    "n": "Prix jeunesse des libraires",
    "u": "https://prixjeunessedeslibraires.qc.ca",
    "c": "Culture",
    "d": "Choix libraires Québec",
    "date": "2025"
  },
  {
    "n": "Prix Cécile-Gagnon",
    "u": "https://prixcecilegagnon.com",
    "c": "Culture",
    "d": "Premier roman jeunesse Québec",
    "date": "2025"
  },
  {
    "n": "Prix Harry Black",
    "u": "https://prixharryblack.com",
    "c": "Culture",
    "d": "Littérature jeunesse Québec",
    "date": "2025"
  },
  {
    "n": "Prix Raymond Plante",
    "u": "https://prixraymondplante.com",
    "c": "Culture",
    "d": "Lecture jeunesse",
    "date": "2025"
  },
  {
    "n": "Prix Alvine-Bélisle",
    "u": "https://alvinebelisle.com",
    "c": "Culture",
    "d": "Meilleur livre jeunesse Québec",
    "date": "2025"
  },
  {
    "n": "Les Débroussailles",
    "u": "https://debroussailles.com",
    "c": "Culture",
    "d": "Club lecture jeunesse",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Trois-Pistoles",
    "u": "https://salontroispistoles.com",
    "c": "Culture",
    "d": "Bas-Saint-Laurent",
    "date": "2025"
  },
  {
    "n": "Salon du livre de l'Abitibi-Témiscamingue",
    "u": "https://salonlivreat.com",
    "c": "Culture",
    "d": "Rouyn-Noranda",
    "date": "2025"
  },
  {
    "n": "Salon du livre de Saguenay",
    "u": "https://salondulivresaguenay.com",
    "c": "Culture",
    "d": "Saguenay livre",
    "date": "2025"
  },
  {
    "n": "Salon du livre de l'Estrie",
    "u": "https://salonlivrestries.com",
    "c": "Culture",
    "d": "Sherbrooke",
    "date": "2025"
  },
  {
    "n": "Salon du livre de la Côte-Nord",
    "u": "https://salonlivrecotenord.com",
    "c": "Culture",
    "d": "Baie-Comeau Sept-Îles",
    "date": "2025"
  },
  {
    "n": "Foire du livre de Saint-Hyacinthe",
    "u": "https://foiredulivre.ca",
    "c": "Culture",
    "d": "Maskoutains",
    "date": "2025"
  },
  {
    "n": "Foire du livre de Bruxelles Québec",
    "u": "https://flb.be",
    "c": "Culture",
    "d": "Québec invité d'honneur",
    "date": "2025"
  },
  {
    "n": "Marché de la poésie de Montréal",
    "u": "https://maisondelapoesie.qc.ca/marche",
    "c": "Culture",
    "d": "Poésie Montréal",
    "date": "2025"
  },
  {
    "n": "Festival de poésie de Montréal",
    "u": "https://festivalpoesie.com",
    "c": "Culture",
    "d": "Poésie internationale",
    "date": "2025"
  },
  {
    "n": "Maison de la poésie de Montréal",
    "u": "https://maisondelapoesie.qc.ca",
    "c": "Culture",
    "d": "Poésie contemporaine",
    "date": "2025"
  },
  {
    "n": "Festival international de la poésie de Trois-Rivières",
    "u": "https://fiptr.com",
    "c": "Culture",
    "d": "Plus grand festival poésie francophone",
    "date": "2025"
  },
  {
    "n": "Poètes de brousse",
    "u": "https://poetesdebrousse.com",
    "c": "Culture",
    "d": "Édition poésie Québec",
    "date": "2025"
  },
  {
    "n": "Éditions du Noroît",
    "u": "https://lenoroit.com",
    "c": "Culture",
    "d": "Poésie Québec",
    "date": "2025"
  },
  {
    "n": "Éditions de l'Hexagone",
    "u": "https://edhexagone.com",
    "c": "Culture",
    "d": "Poésie classique Québec",
    "date": "2025"
  },
  {
    "n": "Éditions du passage",
    "u": "https://editionsdupassage.com",
    "c": "Culture",
    "d": "Poésie contemporaine",
    "date": "2025"
  },
  {
    "n": "Éditions Mémoire d'encrier",
    "u": "https://memoiredencrier.com",
    "c": "Culture",
    "d": "Poésie autochtones et monde",
    "date": "2025"
  },
  {
    "n": "Éditions Perce-Neige",
    "u": "https://perceneige.ca",
    "c": "Culture",
    "d": "Poésie Acadie",
    "date": "2025"
  },
  {
    "n": "Éditions Prise de parole",
    "u": "https://prisedeparole.ca",
    "c": "Culture",
    "d": "Franco-Ontarien littérature",
    "date": "2025"
  },
  {
    "n": "Éditions David",
    "u": "https://editionsdavid.com",
    "c": "Culture",
    "d": "Franco-Ontarien",
    "date": "2025"
  },
  {
    "n": "Éditions L'Interligne",
    "u": "https://interligne.ca",
    "c": "Culture",
    "d": "Ottawa franco-ontarien",
    "date": "2025"
  },
  {
    "n": "Éditions du Blé",
    "u": "https://editionsduble.com",
    "c": "Culture",
    "d": "Manitoba francophone",
    "date": "2025"
  },
  {
    "n": "Éditions des Plaines",
    "u": "https://plaines.ca",
    "c": "Culture",
    "d": "Manitoba littérature",
    "date": "2025"
  },
  {
    "n": "Éditions Bouton d'or Acadie",
    "u": "https://boutondoracadie.com",
    "c": "Culture",
    "d": "Jeunesse Acadie",
    "date": "2025"
  },
  {
    "n": "Éditions La Grande Marée",
    "u": "https://grandemaree.ca",
    "c": "Culture",
    "d": "Nouveau-Brunswick",
    "date": "2025"
  },
  {
    "n": "Éditions du Boréal",
    "u": "https://editionsboreal.qc.ca",
    "c": "Culture",
    "d": "Littérature générale Québec",
    "date": "2025"
  },
  {
    "n": "Éditions Québec Amérique",
    "u": "https://quebec-amerique.com",
    "c": "Culture",
    "d": "Romans et jeunesse",
    "date": "2025"
  },
  {
    "n": "Éditions Alto",
    "u": "https://editionsalto.com",
    "c": "Culture",
    "d": "Littérature contemporaine",
    "date": "2025"
  },
  {
    "n": "Éditions La Peuplade",
    "u": "https://lapeuplade.com",
    "c": "Culture",
    "d": "Saguenay littérature",
    "date": "2025"
  },
  {
    "n": "Éditions XYZ",
    "u": "https://editionsxyz.com",
    "c": "Culture",
    "d": "Polars et romans Québec",
    "date": "2025"
  },
  {
    "n": "Éditions Libre Expression",
    "u": "https://libreexpression.com",
    "c": "Culture",
    "d": "Groupe Québecor",
    "date": "2025"
  },
  {
    "n": "Éditions de l'Homme",
    "u": "https://editions-homme.com",
    "c": "Culture",
    "d": "Pratique développement personnel",
    "date": "2025"
  },
  {
    "n": "Éditions Hurtubise",
    "u": "https://edhurtubise.com",
    "c": "Culture",
    "d": "Littérature Québec",
    "date": "2025"
  },
  {
    "n": "Éditions Leméac",
    "u": "https://lemeac.com",
    "c": "Culture",
    "d": "Théâtre et littérature",
    "date": "2025"
  },
  {
    "n": "Éditions VLB",
    "u": "https://vlbéditeur.com",
    "c": "Culture",
    "d": "Romans et essais",
    "date": "2025"
  },
  {
    "n": "Éditions Marchand de feuilles",
    "u": "https://marchanddefeuilles.com",
    "c": "Culture",
    "d": "Littérature indépendante",
    "date": "2025"
  },
  {
    "n": "Éditions Hamac",
    "u": "https://edhamac.com",
    "c": "Culture",
    "d": "Nouvelles et poésie",
    "date": "2025"
  },
  {
    "n": "Éditions du Quartanier",
    "u": "https://lequartanier.com",
    "c": "Culture",
    "d": "Littérature expérimentale",
    "date": "2025"
  },
  {
    "n": "Éditions Poètes de brousse",
    "u": "https://poetesdebrousse.com",
    "c": "Culture",
    "d": "Poésie contemporaine",
    "date": "2025"
  },
  {
    "n": "Éditions de Ta Mère",
    "u": "https://editionsdetamere.com",
    "c": "Culture",
    "d": "Humour et BD",
    "date": "2025"
  },
  {
    "n": "Éditions Pow Pow",
    "u": "https://powpow.ca",
    "c": "Culture",
    "d": "Bande dessinée indépendante",
    "date": "2025"
  },
  {
    "n": "Éditions Nouvelle Adresse",
    "u": "https://nouvelleadresse.ca",
    "c": "Culture",
    "d": "BD et romans graphiques",
    "date": "2025"
  },
  {
    "n": "Éditions La Pastèque",
    "u": "https://lapasteque.com",
    "c": "Culture",
    "d": "BD et jeunesse",
    "date": "2025"
  },
  {
    "n": "Éditions Mécanique générale",
    "u": "https://mecaniquegenerale.com",
    "c": "Culture",
    "d": "BD alternative",
    "date": "2025"
  },
  {
    "n": "Éditions Front Froid",
    "u": "https://frontfroid.com",
    "c": "Culture",
    "d": "BD indépendante",
    "date": "2025"
  },
  {
    "n": "Éditions Moelle Graphique",
    "u": "https://moellegraphik.com",
    "c": "Culture",
    "d": "BD expérimentale",
    "date": "2025"
  },
  {
    "n": "Éditions Trip",
    "u": "https://editionstrip.com",
    "c": "Culture",
    "d": "BD jeunesse",
    "date": "2025"
  },
  {
    "n": "Éditions Glénat Québec",
    "u": "https://glenatbd.com",
    "c": "Culture",
    "d": "BD franco-belge",
    "date": "2025"
  },
  {
    "n": "Presses de l'Université de Montréal",
    "u": "https://pum.umontreal.ca",
    "c": "Éducation",
    "d": "Édition universitaire",
    "date": "2025"
  },
  {
    "n": "Presses de l'Université Laval",
    "u": "https://www.pulaval.com",
    "c": "Éducation",
    "d": "Édition universitaire Québec",
    "date": "2025"
  },
  {
    "n": "Presses de l'UQAM",
    "u": "https://presse.uqam.ca",
    "c": "Éducation",
    "d": "Édition universitaire",
    "date": "2025"
  },
  {
    "n": "Presses de l'Université du Québec",
    "u": "https://puq.ca",
    "c": "Éducation",
    "d": "Réseau PUQ",
    "date": "2025"
  },
  {
    "n": "Presses de l'Université d'Ottawa",
    "u": "https://press.uottawa.ca",
    "c": "Éducation",
    "d": "Édition bilingue Ottawa",
    "date": "2025"
  },
  {
    "n": "Éditions Fides",
    "u": "https://editionsfides.com",
    "c": "Culture",
    "d": "Littérature religieuse et générale",
    "date": "2025"
  },
  {
    "n": "Éditions Novalis",
    "u": "https://novalis.ca",
    "c": "Culture",
    "d": "Spirituel catholique",
    "date": "2025"
  },
  {
    "n": "Éditions Médiaspaul",
    "u": "https://mediaspaul.ca",
    "c": "Culture",
    "d": "Religieux catholique",
    "date": "2025"
  },
  {
    "n": "Éditions Paulines",
    "u": "https://editionspaulines.ca",
    "c": "Culture",
    "d": "Spirituel catholique",
    "date": "2025"
  },
  {
    "n": "Éditions Anne Sigier",
    "u": "https://annesigier.com",
    "c": "Culture",
    "d": "Spirituel Québec",
    "date": "2025"
  },
  {
    "n": "Éditions Bayard Canada",
    "u": "https://bayardcanada.com",
    "c": "Culture",
    "d": "Presse jeunesse catholique",
    "date": "2025"
  },
  {
    "n": "Éditions du Cerf",
    "u": "https://editionsducerf.fr",
    "c": "Culture",
    "d": "Théologie catholique",
    "date": "2025"
  },
  {
    "n": "Éditions Salvator",
    "u": "https://editions-salvator.com",
    "c": "Culture",
    "d": "Spirituel",
    "date": "2025"
  },
  {
    "n": "Éditions Fidélité",
    "u": "https://editions-fidelite.com",
    "c": "Culture",
    "d": "Spiritualité",
    "date": "2025"
  },
  {
    "n": "Éditions Saint-Augustin",
    "u": "https://editions-saint-augustin.ch",
    "c": "Culture",
    "d": "Suisse mais diffusion Québec",
    "date": "2025"
  },
  {
    "n": "Éditions de l'Emmanuel",
    "u": "https://editions-emmanuel.com",
    "c": "Culture",
    "d": "Musique et spirituel",
    "date": "2025"
  },
  {
    "n": "Éditions Béatitudes",
    "u": "https://editions-beatitudes.com",
    "c": "Culture",
    "d": "Charismatique",
    "date": "2025"
  },
  {
    "n": "Éditions des Béatitudes",
    "u": "https://beatitudes.org",
    "c": "Culture",
    "d": "Communauté Nouan-le-Fuzelier",
    "date": "2025"
  },
  {
    "n": "Éditions Vie chrétienne",
    "u": "https://viechretienne.catholique.fr",
    "c": "Culture",
    "d": "Presse catholique",
    "date": "2025"
  },
  {
    "n": "Prions en Église",
    "u": "https://prionseneglise.ca",
    "c": "Culture",
    "d": "Missel mensuel Québec",
    "date": "2025"
  },
  {
    "n": "Magnificat",
    "u": "https://magnificat.ca",
    "c": "Culture",
    "d": "Prières quotidiennes",
    "date": "2025"
  },
  {
    "n": "Parole et Prière",
    "u": "https://paroleetpriere.com",
    "c": "Culture",
    "d": "Missel Québec",
    "date": "2025"
  },
  {
    "n": "Croix du Québec",
    "u": "https://croixduquebec.com",
    "c": "Culture",
    "d": "Croix pectorales",
    "date": "2025"
  },
  {
    "n": "Sel et Lumière",
    "u": "https://seletlumieretv.org",
    "c": "Médias",
    "d": "Télé catholique Canada",
    "date": "2025"
  },
  {
    "n": "Radio VM",
    "u": "https://radiovm.com",
    "c": "Médias",
    "d": "Radio catholique Montréal",
    "date": "2025"
  },
  {
    "n": "Radio Galilée",
    "u": "https://radiogalilee.com",
    "c": "Médias",
    "d": "Radio catholique Québec",
    "date": "2025"
  },
  {
    "n": "Radio Ville-Marie",
    "u": "https://radiovillemarie.org",
    "c": "Médias",
    "d": "Radio catholique Montréal",
    "date": "2025"
  },
  {
    "n": "Radio Maria Canada",
    "u": "https://radiomaria.ca",
    "c": "Médias",
    "d": "Radio catholique internationale",
    "date": "2025"
  },
  {
    "n": "Fondation catholique Sel et Lumière",
    "u": "https://seletlumieretv.org",
    "c": "Culture",
    "d": "Médias catholiques",
    "date": "2025"
  },
  {
    "n": "Aide à l'Église en détresse",
    "u": "https://aed-canada.org",
    "c": "Culture",
    "d": "Œuvre pontificale",
    "date": "2025"
  },
  {
    "n": "Développement et Paix",
    "u": "https://devp.org",
    "c": "Culture",
    "d": "Caritas Canada",
    "date": "2025"
  },
  {
    "n": "Œuvre Pontificale Missionnaire",
    "u": "https://opmcanada.ca",
    "c": "Culture",
    "d": "Missions catholiques",
    "date": "2025"
  },
  {
    "n": "Chevaliers de Colomb Québec",
    "u": "https://kofc-quebec.org",
    "c": "Culture",
    "d": "Ordre fraternel catholique",
    "date": "2025"
  },
  {
    "n": "Cursillos francophones Canada",
    "u": "https://cursillos.ca",
    "c": "Culture",
    "d": "Mouvement charismatique",
    "date": "2025"
  },
  {
    "n": "Renouveau charismatique Québec",
    "u": "https://renouveau-quebec.ca",
    "c": "Culture",
    "d": "Renouveau catholique",
    "date": "2025"
  },
  {
    "n": "Communauté de l'Emmanuel Québec",
    "u": "https://emmanuel.info",
    "c": "Culture",
    "d": "Communauté charismatique",
    "date": "2025"
  },
  {
    "n": "Communauté des Béatitudes Québec",
    "u": "https://beatitudes.ca",
    "c": "Culture",
    "d": "Communauté nouvelle",
    "date": "2025"
  },
  {
    "n": "Focolari Québec",
    "u": "https://focolare.ca",
    "c": "Culture",
    "d": "Mouvement Focolari",
    "date": "2025"
  },
  {
    "n": "Opus Dei Québec",
    "u": "https://opusdei.org/fr-ca/section/quebec",
    "c": "Culture",
    "d": "Prélature personnelle",
    "date": "2025"
  },
  {
    "n": "Légion de Marie Québec",
    "u": "https://legionofmary-quebec.org",
    "c": "Culture",
    "d": "Apostolat laïc",
    "date": "2025"
  },
  {
    "n": "Mouvement des Foyers de Charité",
    "u": "https://foyersdecharite.com",
    "c": "Culture",
    "d": "Retraites spirituelles",
    "date": "2025"
  },
  {
    "n": "Centre de prière Marie Reine de la Paix",
    "u": "https://mariereinedelapaix.com",
    "c": "Culture",
    "d": "Sanctuaire Montréal",
    "date": "2025"
  },
  {
    "n": "Cathédrale Marie-Reine-du-Monde",
    "u": "https://mariereinedumonde.ca",
    "c": "Culture",
    "d": "Cathédrale Montréal",
    "date": "2025"
  },
  {
    "n": "Ermitage Saint-Antoine Lac-Bouchette",
    "u": "https://ermitage.org",
    "c": "Culture",
    "d": "Sanctuaire Saguenay",
    "date": "2025"
  },
  {
    "n": "Chapelle Notre-Dame-de-Lourdes Montréal",
    "u": "https://nddl.org",
    "c": "Culture",
    "d": "Chapelle historique",
    "date": "2025"
  },
  {
    "n": "Église Saint-Viateur d'Outremont",
    "u": "https://saintviateur.org",
    "c": "Culture",
    "d": "Église historique",
    "date": "2025"
  },
  {
    "n": "Église Très-Saint-Nom-de-Jésus",
    "u": "https://tsnj.ca",
    "c": "Culture",
    "d": "Église Hochelaga",
    "date": "2025"
  },
  {
    "n": "Église Saint-Jean-Baptiste Québec",
    "u": "https://saintjeanbaptiste.ca",
    "c": "Culture",
    "d": "Église historique Québec",
    "date": "2025"
  },
  {
    "n": "Église Notre-Dame-des-Victoires",
    "u": "https://ndv.qc.ca",
    "c": "Culture",
    "d": "Plus ancienne église pierre Amérique Nord",
    "date": "2025"
  },
  {
    "n": "Église Saint-Roch Québec",
    "u": "https://saintrochdequebec.org",
    "c": "Culture",
    "d": "Église Saint-Roch",
    "date": "2025"
  },
  {
    "n": "Séminaire de Québec",
    "u": "https://seminairedequebec.org",
    "c": "Éducation",
    "d": "Formation prêtres Québec",
    "date": "2025"
  },
  {
    "n": "Grand Séminaire de Montréal",
    "u": "https://gsmontreal.org",
    "c": "Éducation",
    "d": "Formation sacerdotale Montréal",
    "date": "2025"
  },
  {
    "n": "Séminaire des Pères Maristes",
    "u": "https://maristes.qc.ca",
    "c": "Éducation",
    "d": "Formation religieuse",
    "date": "2025"
  },
  {
    "n": "Institut de formation théologique de Montréal",
    "u": "https://iftm.ca",
    "c": "Éducation",
    "d": "Théologie laïcs",
    "date": "2025"
  },
  {
    "n": "Faculté de théologie évangélique",
    "u": "https://faculte-theologie-evangelique.com",
    "c": "Éducation",
    "d": "Théologie protestante",
    "date": "2025"
  },
  {
    "n": "Collège Biblique Québec",
    "u": "https://cbq.qc.ca",
    "c": "Éducation",
    "d": "Formation biblique",
    "date": "2025"
  },
  {
    "n": "Institut de pastorale des Dominicains",
    "u": "https://ipastorale.ca",
    "c": "Éducation",
    "d": "Théologie dominicaine",
    "date": "2025"
  },
  {
    "n": "Faculté de théologie et de sciences religieuses Laval",
    "u": "https://ftsr.ulaval.ca",
    "c": "Éducation",
    "d": "Théologie universitaire",
    "date": "2025"
  },
  {
    "n": "Faculté de théologie Montréal",
    "u": "https://theologie.umontreal.ca",
    "c": "Éducation",
    "d": "Théologie UdeM",
    "date": "2025"
  },
  {
    "n": "Dominican University College Ottawa",
    "u": "https://dominicanu.ca",
    "c": "Éducation",
    "d": "Philosophie théologie",
    "date": "2025"
  },
  {
    "n": "Collège Universitaire Dominicain",
    "u": "https://cud.udominicaine.ca",
    "c": "Éducation",
    "d": "Ottawa bilingue",
    "date": "2025"
  },
  {
    "n": "Université Saint-Paul Ottawa",
    "u": "https://ustpaul.ca",
    "c": "Éducation",
    "d": "Université catholique bilingue",
    "date": "2025"
  },
  {
    "n": "Collège de théologie orthodoxe Montréal",
    "u": "https://orthodoxmontreal.org",
    "c": "Éducation",
    "d": "Théologie orthodoxe",
    "date": "2025"
  },
  {
    "n": "École biblique de Montréal",
    "u": "https://ebm.qc.ca",
    "c": "Éducation",
    "d": "Formation évangélique",
    "date": "2025"
  },
  {
    "n": "Institut de théologie pour la francophonie",
    "u": "https://itf.qc.ca",
    "c": "Éducation",
    "d": "Théologie évangélique",
    "date": "2025"
  },
  {
    "n": "Séminaire baptiste évangélique Québec",
    "u": "https://sembeq.qc.ca",
    "c": "Éducation",
    "d": "Formation pasteurs baptistes",
    "date": "2025"
  },
  {
    "n": "Assemblée de Dieu Québec",
    "u": "https://adquebec.com",
    "c": "Culture",
    "d": "Églises pentecôtistes Québec",
    "date": "2025"
  },
  {
    "n": "Église Nouvelle Vie",
    "u": "https://nouvellevie.com",
    "c": "Culture",
    "d": "Église évangélique Longueuil",
    "date": "2025"
  },
  {
    "n": "Église Momentum",
    "u": "https://momentumeglise.com",
    "c": "Culture",
    "d": "Église évangélique Montréal",
    "date": "2025"
  },
  {
    "n": "Église Le Portail",
    "u": "https://leportail.ca",
    "c": "Culture",
    "d": "Église Québec ville",
    "date": "2025"
  },
  {
    "n": "Église Évangélique Baptiste",
    "u": "https://eebq.ca",
    "c": "Culture",
    "d": "Réseau baptiste Québec",
    "date": "2025"
  },
  {
    "n": "Église Protestante Évangélique",
    "u": "https://epeq.ca",
    "c": "Culture",
    "d": "Réseau évangélique Québec",
    "date": "2025"
  },
  {
    "n": "Église Unie du Canada Québec",
    "u": "https://egliseunie.ca",
    "c": "Culture",
    "d": "Église protestante historique",
    "date": "2025"
  },
  {
    "n": "Anglican Church of Canada Québec",
    "u": "https://quebec.anglican.ca",
    "c": "Culture",
    "d": "Diocèse Québec anglican",
    "date": "2025"
  },
  {
    "n": "Église orthodoxe russe Montréal",
    "u": "https://stnicholascathedral.ca",
    "c": "Culture",
    "d": "Cathédrale Saint-Nicolas",
    "date": "2025"
  },
  {
    "n": "Église grecque orthodoxe Montréal",
    "u": "https://koimisis.ca",
    "c": "Culture",
    "d": "Communauté hellénique",
    "date": "2025"
  },
  {
    "n": "Communauté juive sépharade Québec",
    "u": "https://csuq.ca",
    "c": "Culture",
    "d": "Sépharades Montréal",
    "date": "2025"
  },
  {
    "n": "Communauté juive ashkénaze",
    "u": "https://jewishmontreal.ca",
    "c": "Culture",
    "d": "Ashkénazes Montréal",
    "date": "2025"
  },
  {
    "n": "Synagogue espagnole et portugaise",
    "u": "https://thespanish.org",
    "c": "Culture",
    "d": "Plus ancienne synagogue Canada",
    "date": "2025"
  },
  {
    "n": "Mosquée Al-Omah Montréal",
    "u": "https://alomah.ca",
    "c": "Culture",
    "d": "Mosquée sunnite",
    "date": "2025"
  },
  {
    "n": "Centre islamique québécois",
    "u": "https://ciq.qc.ca",
    "c": "Culture",
    "d": "Islam Québec",
    "date": "2025"
  },
  {
    "n": "Association musulmane Québec",
    "u": "https://musulmansquebec.org",
    "c": "Culture",
    "d": "Musulmans Québec",
    "date": "2025"
  },
  {
    "n": "Temple bouddhiste vietnamien",
    "u": "https://chua.vn",
    "c": "Culture",
    "d": "Bouddhisme vietnamien Montréal",
    "date": "2025"
  },
  {
    "n": "Temple hindou Montréal",
    "u": "https://hindutemple.ca",
    "c": "Culture",
    "d": "Temple hindou",
    "date": "2025"
  },
  {
    "n": "Gurdwara Sikh Montréal",
    "u": "https://gurdwaramontreal.com",
    "c": "Culture",
    "d": "Temple sikh",
    "date": "2025"
  },
  {
    "n": "Centre Zen de Montréal",
    "u": "https://zenmontreal.ca",
    "c": "Culture",
    "d": "Zen soto",
    "date": "2025"
  },
  {
    "n": "Kio-o Centre zen",
    "u": "https://kioo.ca",
    "c": "Culture",
    "d": "Zen rinzai",
    "date": "2025"
  },
  {
    "n": "Rigpe Dorje Montréal",
    "u": "https://rigpedorje.org",
    "c": "Culture",
    "d": "Bouddhisme tibétain",
    "date": "2025"
  },
  {
    "n": "Shambhala Montréal",
    "u": "https://montreal.shambhala.org",
    "c": "Culture",
    "d": "Méditation Shambhala",
    "date": "2025"
  },
  {
    "n": "Atisha Centre bouddhiste",
    "u": "https://atisha.qc.ca",
    "c": "Culture",
    "d": "Kadampa Québec",
    "date": "2025"
  },
  {
    "n": "Dojo zen de Montréal",
    "u": "https://dojozenmontreal.ca",
    "c": "Culture",
    "d": "Zen soto",
    "date": "2025"
  },
  {
    "n": "Centre bouddhiste Triratna",
    "u": "https://triratna-montreal.org",
    "c": "Culture",
    "d": "Bouddhisme occidental",
    "date": "2025"
  },
  {
    "n": "Association bouddhiste vietnamienne",
    "u": "https://phapvan.ca",
    "c": "Culture",
    "d": "Bouddhisme vietnamien",
    "date": "2025"
  },
  {
    "n": "Pagode Chua Quan Am",
    "u": "https://quanam.ca",
    "c": "Culture",
    "d": "Bouddhisme vietnamien",
    "date": "2025"
  },
  {
    "n": "Temple Cao Dai Montréal",
    "u": "https://caodai.ca",
    "c": "Culture",
    "d": "Religion vietnamienne",
    "date": "2025"
  },
  {
    "n": "Église mormone Québec",
    "u": "https://churchofjesuschrist.org",
    "c": "Culture",
    "d": "Église de Jésus-Christ des Saints des Derniers Jours",
    "date": "2025"
  },
  {
    "n": "Témoins de Jéhovah Québec",
    "u": "https://jw.org/fr",
    "c": "Culture",
    "d": "Témoins de Jéhovah",
    "date": "2025"
  },
  {
    "n": "Science chrétienne Montréal",
    "u": "https://christianscience.com/fr",
    "c": "Culture",
    "d": "Église Science chrétienne",
    "date": "2025"
  },
  {
    "n": "Unification Church Québec",
    "u": "https://familyfed.org",
    "c": "Culture",
    "d": "Église de l'Unification",
    "date": "2025"
  },
  {
    "n": "Baha'i Québec",
    "u": "https://bahai.qc.ca",
    "c": "Culture",
    "d": "Communauté baha'ie",
    "date": "2025"
  },
  {
    "n": "Franc-maçonnerie Québec",
    "u": "https://glqf.qc.ca",
    "c": "Culture",
    "d": "Grande Loge Québec",
    "date": "2025"
  },
  {
    "n": "Rose-Croix AMORC Québec",
    "u": "https://amorc.qc.ca",
    "c": "Culture",
    "d": "Ordre rosicrucien",
    "date": "2025"
  },
  {
    "n": "Ordre hermétique de l'Aube dorée",
    "u": "https://golden-dawn.ca",
    "c": "Culture",
    "d": "Occultisme Québec",
    "date": "2025"
  },
  {
    "n": "Wicca Québec",
    "u": "https://wiccaquebec.ca",
    "c": "Culture",
    "d": "Communauté wiccane",
    "date": "2025"
  },
  {
    "n": "Pagan Federation Québec",
    "u": "https://pfq.ca",
    "c": "Culture",
    "d": "Paganisme Québec",
    "date": "2025"
  },
  {
    "n": "Association athée Québec",
    "u": "https://athee.ca",
    "c": "Culture",
    "d": "Athéisme laïcité",
    "date": "2025"
  },
  {
    "n": "Humanistes Québec",
    "u": "https://humanistes-quebec.org",
    "c": "Culture",
    "d": "Humanisme laïc",
    "date": "2025"
  },
  {
    "n": "Raeliens Québec",
    "u": "https://rael.org",
    "c": "Culture",
    "d": "Mouvement raëlien",
    "date": "2025"
  },
  {
    "n": "Scientologie Montréal",
    "u": "https://scientologie-montreal.org",
    "c": "Culture",
    "d": "Église scientologie",
    "date": "2025"
  },
  {
    "n": "Centre Sivananda Yoga Vedanta",
    "u": "https://sivananda.org/montreal",
    "c": "Culture",
    "d": "Yoga traditionnel",
    "date": "2025"
  },
  {
    "n": "Kripalu Yoga Montréal",
    "u": "https://kripalu.org",
    "c": "Culture",
    "d": "Yoga Kripalu",
    "date": "2025"
  },
  {
    "n": "Ashtanga Yoga Montréal",
    "u": "https://ashtangayogamontreal.com",
    "c": "Culture",
    "d": "Ashtanga traditionnel",
    "date": "2025"
  },
  {
    "n": "Yoga Sangha",
    "u": "https://yogasangha.ca",
    "c": "Culture",
    "d": "Yoga communautaire",
    "date": "2025"
  },
  {
    "n": "Studio Bliss",
    "u": "https://studiobliss.ca",
    "c": "Culture",
    "d": "Yoga et méditation",
    "date": "2025"
  },
  {
    "n": "Naada Yoga",
    "u": "https://naadayoga.ca",
    "c": "Culture",
    "d": "Yoga et musique",
    "date": "2025"
  },
  {
    "n": "Luna Yoga",
    "u": "https://lunayoga.ca",
    "c": "Culture",
    "d": "Yoga féminin Montréal",
    "date": "2025"
  },
  {
    "n": "HappyTree Yoga",
    "u": "https://happytreeyoga.com",
    "c": "Culture",
    "d": "Yoga Mile End",
    "date": "2025"
  },
  {
    "n": "Moksha Yoga",
    "u": "https://mokshayoga.ca",
    "c": "Culture",
    "d": "Yoga chaud Québec",
    "date": "2025"
  },
  {
    "n": "Yoga Vieux-Montréal",
    "u": "https://yogavieuxmontreal.com",
    "c": "Culture",
    "d": "Yoga historique",
    "date": "2025"
  },
  {
    "n": "Modo Yoga",
    "u": "https://modoyoga.com/montreal",
    "c": "Culture",
    "d": "Yoga chaud écologique",
    "date": "2025"
  },
  {
    "n": "Union Yoga",
    "u": "https://union.yoga",
    "c": "Culture",
    "d": "Yoga Outremont",
    "date": "2025"
  },
  {
    "n": "Satya Yoga",
    "u": "https://satyayoga.ca",
    "c": "Culture",
    "d": "Yoga traditionnel",
    "date": "2025"
  },
  {
    "n": "Yoga Monde",
    "u": "https://yogamonde.ca",
    "c": "Culture",
    "d": "Yoga Rosemont",
    "date": "2025"
  },
  {
    "n": "Centre yoga santé",
    "u": "https://centreyogasante.com",
    "c": "Culture",
    "d": "Yoga thérapeutique",
    "date": "2025"
  },
  {
    "n": "Association yoga Québec",
    "u": "https://yoga-quebec.ca",
    "c": "Culture",
    "d": "Regroupement professeurs",
    "date": "2025"
  },
  {
    "n": "Fédération francophone de yoga",
    "u": "https://ffyoga.ca",
    "c": "Culture",
    "d": "Yoga francophone Canada",
    "date": "2025"
  },
  {
    "n": "Méditation transcendantale Québec",
    "u": "https://mtquebec.org",
    "c": "Culture",
    "d": "Méditation TM",
    "date": "2025"
  },
  {
    "n": "Vipassana Québec",
    "u": "https://qc.dhamma.org",
    "c": "Culture",
    "d": "Retraites 10 jours",
    "date": "2025"
  },
  {
    "n": "Art of Living Québec",
    "u": "https://artofliving.org/ca-fr",
    "c": "Culture",
    "d": "Sri Sri Ravi Shankar",
    "date": "2025"
  },
  {
    "n": "Sahaja Yoga Québec",
    "u": "https://sahajayoga.ca",
    "c": "Culture",
    "d": "Méditation spontanée",
    "date": "2025"
  },
  {
    "n": "Osho Montréal",
    "u": "https://oshoquebec.com",
    "c": "Culture",
    "d": "Méditation active",
    "date": "2025"
  },
  {
    "n": "Kadampa Montréal",
    "u": "https://meditationamontreal.org",
    "c": "Culture",
    "d": "Bouddhisme kadampa",
    "date": "2025"
  },
  {
    "n": "Rigpa Montréal",
    "u": "https://rigpa.org",
    "c": "Culture",
    "d": "Bouddhisme tibétain",
    "date": "2025"
  },
  {
    "n": "Centre bouddhiste Ganden",
    "u": "https://ganden.ca",
    "c": "Culture",
    "d": "Gelugpa tibétain",
    "date": "2025"
  },
  {
    "n": "Diamond Way Montréal",
    "u": "https://diamondway-buddhism.org",
    "c": "Culture",
    "d": "Karma Kagyu",
    "date": "2025"
  },
  {
    "n": "Zen Centre de Montréal",
    "u": "https://zenmontreal.ca",
    "c": "Culture",
    "d": "Soto zen",
    "date": "2025"
  },
  {
    "n": "Mindfulness Montréal",
    "u": "https://mindfulnessmontreal.com",
    "c": "Culture",
    "d": "Pleine conscience laïque",
    "date": "2025"
  },
  {
    "n": "Centre de méditation Kadampa",
    "u": "https://kadampamontreal.org",
    "c": "Culture",
    "d": "Bouddhisme moderne",
    "date": "2025"
  },
  {
    "n": "École de l'Éveil",
    "u": "https://ecoledel-eveil.com",
    "c": "Culture",
    "d": "Méditation non-duelle",
    "date": "2025"
  },
  {
    "n": "Réveil conscient",
    "u": "https://reveilconscient.com",
    "c": "Culture",
    "d": "Éveil spirituel",
    "date": "2025"
  },
  {
    "n": "Institut de méditation de Montréal",
    "u": "https://institutmeditation.com",
    "c": "Culture",
    "d": "Méditation laïque",
    "date": "2025"
  },
  {
    "n": "Association mindfulness Québec",
    "u": "https://mindfulnessquebec.org",
    "c": "Culture",
    "d": "Pleine conscience",
    "date": "2025"
  },
  {
    "n": "Centre de yoga Iyengar Montréal",
    "u": "https://iyengaryogamontreal.com",
    "c": "Culture",
    "d": "Yoga Iyengar",
    "date": "2025"
  },
  {
    "n": "Studio Breathe",
    "u": "https://studiobreathe.com",
    "c": "Culture",
    "d": "Yoga et pilates",
    "date": "2025"
  },
  {
    "n": "Yoga Vieux-Montréal",
    "u": "https://yogavm.com",
    "c": "Culture",
    "d": "Yoga centre historique",
    "date": "2025"
  },
  {
    "n": "Espace Bikram",
    "u": "https://bikramyogamontreal.com",
    "c": "Culture",
    "d": "Yoga chaud Bikram",
    "date": "2025"
  },
  {
    "n": "Yoga Hot Spot",
    "u": "https://hotspotyoga.ca",
    "c": "Culture",
    "d": "Yoga chaud",
    "date": "2025"
  },
  {
    "n": "Yoga Fitness",
    "u": "https://yogafitness.ca",
    "c": "Culture",
    "d": "Yoga et fitness",
    "date": "2025"
  },
  {
    "n": "Ashtanga Yoga Montréal",
    "u": "https://ashtangamontreal.com",
    "c": "Culture",
    "d": "Ashtanga traditionnel",
    "date": "2025"
  },
  {
    "n": "Yoga Kundalini Montréal",
    "u": "https://kundaliniyogamontreal.com",
    "c": "Culture",
    "d": "Kundalini yoga",
    "date": "2025"
  },
  {
    "n": "Yin Yoga Montréal",
    "u": "https://yinyogamontreal.com",
    "c": "Culture",
    "d": "Yoga yin restauratif",
    "date": "2025"
  },
  {
    "n": "Yoga pour enfants Montréal",
    "u": "https://yogapourenfants.com",
    "c": "Culture",
    "d": "Yoga jeunesse",
    "date": "2025"
  },
  {
    "n": "Yoga prénatal Montréal",
    "u": "https://yogaprenatal.ca",
    "c": "Culture",
    "d": "Grossesse yoga",
    "date": "2025"
  },
  {
    "n": "Yoga thérapeutique Montréal",
    "u": "https://yogatherapeutique.ca",
    "c": "Culture",
    "d": "Santé par yoga",
    "date": "2025"
  },
  {
    "n": "Yoga aérien Montréal",
    "u": "https://yogaaerien.com",
    "c": "Culture",
    "d": "Yoga dans hamac",
    "date": "2025"
  },
  {
    "n": "SUP Yoga Montréal",
    "u": "https://supyogamontreal.com",
    "c": "Culture",
    "d": "Yoga sur planche",
    "date": "2025"
  },
  {
    "n": "Yoga sur chaise",
    "u": "https://yogasurchaise.com",
    "c": "Culture",
    "d": "Aînés et bureaux",
    "date": "2025"
  },
  {
    "n": "Yoga du rire Montréal",
    "u": "https://yogadurire.com",
    "c": "Culture",
    "d": "Rire thérapeutique",
    "date": "2025"
  },
  {
    "n": "Yoga nidra Montréal",
    "u": "https://yoganidra.ca",
    "c": "Culture",
    "d": "Relaxation profonde",
    "date": "2025"
  },
  {
    "n": "Méditation sonore",
    "u": "https://meditationsonore.com",
    "c": "Culture",
    "d": "Bains sonores",
    "date": "2025"
  },
  {
    "n": "Cercles de tambours",
    "u": "https://cerclesdetambours.com",
    "c": "Culture",
    "d": "Chamanisme urbain",
    "date": "2025"
  },
  {
    "n": "Cercles de femmes",
    "u": "https://cerclesdefemmes.ca",
    "c": "Culture",
    "d": "Féminin sacré Montréal",
    "date": "2025"
  },
  {
    "n": "Tentes rouges",
    "u": "https://tentesrouges.com",
    "c": "Culture",
    "d": "Cercles lunaires",
    "date": "2025"
  },
  {
    "n": "Chamanisme Québec",
    "u": "https://chamanismequebec.com",
    "c": "Culture",
    "d": "Traditions autochtones",
    "date": "2025"
  },
  {
    "n": "École de chamanisme",
    "u": "https://ecoledechamanisme.com",
    "c": "Culture",
    "d": "Formation chamanique",
    "date": "2025"
  },
  {
    "n": "Voyages chamaniques",
    "u": "https://voyageschamaniques.com",
    "c": "Culture",
    "d": "Tambour et états modifiés",
    "date": "2025"
  },
  {
    "n": "Sweat lodge Québec",
    "u": "https://sweatlodgequebec.com",
    "c": "Culture",
    "d": "Hutte à sudation",
    "date": "2025"
  },
  {
    "n": "Vision quest Québec",
    "u": "https://visionquestquebec.com",
    "c": "Culture",
    "d": "Quête de vision",
    "date": "2025"
  },
  {
    "n": "Cercles de guérison",
    "u": "https://cerclesdeguerison.com",
    "c": "Culture",
    "d": "Guérison énergétique",
    "date": "2025"
  },
  {
    "n": "Reiki Québec",
    "u": "https://reikiquebec.com",
    "c": "Culture",
    "d": "Association reiki",
    "date": "2025"
  },
  {
    "n": "École de reiki Montréal",
    "u": "https://reikimontreal.ca",
    "c": "Culture",
    "d": "Formation reiki",
    "date": "2025"
  },
  {
    "n": "Massothérapie Québec",
    "u": "https://fmq.qc.ca",
    "c": "Santé",
    "d": "Fédération massothérapeutes",
    "date": "2025"
  },
  {
    "n": "Ostéopathie Québec",
    "u": "https://osteopathiequebec.ca",
    "c": "Santé",
    "d": "Association ostéopathes",
    "date": "2025"
  },
  {
    "n": "Naturopathie Québec",
    "u": "https://anqnaturo.com",
    "c": "Santé",
    "d": "Association naturopathes",
    "date": "2025"
  },
  {
    "n": "Acupuncture Québec",
    "u": "https://acupuncturequebec.com",
    "c": "Santé",
    "d": "Ordre acupuncteurs",
    "date": "2025"
  },
  {
    "n": "Homéopathie Québec",
    "u": "https://homeopathiequebec.ca",
    "c": "Santé",
    "d": "Association homéopathes",
    "date": "2025"
  },
  {
    "n": "Médecine traditionnelle chinoise Montréal",
    "u": "https://mtcmontreal.ca",
    "c": "Santé",
    "d": "Cliniques MTC",
    "date": "2025"
  },
  {
    "n": "Ayurvéda Québec",
    "u": "https://ayurvedaquebec.com",
    "c": "Santé",
    "d": "Médecine ayurvédique",
    "date": "2025"
  },
  {
    "n": "CKOI 96.9 Montréal",
    "u": "https://www.ckoi.com",
    "c": "Médias",
    "d": "Radio hits humoristique",
    "date": "2025"
  },
  {
    "n": "TFO Ontario",
    "u": "https://www.tfo.org",
    "c": "Médias",
    "d": "Télévision éducative franco-ontarienne",
    "date": "2025"
  },
  {
    "n": "Musée de la civilisation",
    "u": "https://www.mcq.org",
    "c": "Culture",
    "d": "Histoire et société Québec",
    "date": "2025"
  },
  {
    "n": "District 3",
    "u": "https://d3center.ca",
    "c": "Technologie",
    "d": "Innovation Concordia",
    "date": "2025"
  },
  {
    "n": "Festival de l'érable Plamondon",
    "u": "https://festivalerable.com",
    "c": "Culture",
    "d": "Cabane à sucre",
    "date": "2025"
  },
  {
    "n": "Festival international de la poésie Trois-Rivières",
    "u": "https://fiptr.com",
    "c": "Culture",
    "d": "Plus grand festival poésie francophone",
    "date": "2025"
  },
  {
    "n": "Marché Atwater",
    "u": "https://marchespublics-mtl.com/atwater",
    "c": "Commerce",
    "d": "Marché historique canal Lachine",
    "date": "2025"
  },
  {
    "n": "Ambassade de France aux USA",
    "u": "https://fr.usembassy.gov",
    "c": "Gouvernement",
    "d": "Site officiel en français pour services consulaires et relations franco-américaines",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à New York",
    "u": "https://newyork.consulfrance.org",
    "c": "Gouvernement",
    "d": "Services en français pour francophones aux USA",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Washington",
    "u": "https://washington.consulfrance.org",
    "c": "Gouvernement",
    "d": "Services consulaires Est USA en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Atlanta",
    "u": "https://atlanta.consulfrance.org",
    "c": "Gouvernement",
    "d": "Services Sud-Est USA en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Boston",
    "u": "https://boston.consulfrance.org",
    "c": "Gouvernement",
    "d": "Nouvelle-Angleterre, site bilingue",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Chicago",
    "u": "https://chicago.consulfrance.org",
    "c": "Gouvernement",
    "d": "Midwest USA en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Houston",
    "u": "https://houston.consulfrance.org",
    "c": "Gouvernement",
    "d": "Texas et Sud, ressources en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Los Angeles",
    "u": "https://losangeles.consulfrance.org",
    "c": "Gouvernement",
    "d": "Ouest USA en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Miami",
    "u": "https://miami.consulfrance.org",
    "c": "Gouvernement",
    "d": "Floride et Caraïbes en français",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à La Nouvelle-Orléans",
    "u": "https://nouvelleorleans.consulfrance.org",
    "c": "Gouvernement",
    "d": "Louisiane francophone, services bilingues",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à San Francisco",
    "u": "https://sf.consulfrance.org",
    "c": "Gouvernement",
    "d": "Silicon Valley et Ouest côtier en français",
    "date": "2025"
  },
  {
    "n": "Federation of Alliances Françaises USA",
    "u": "https://www.afusa.org",
    "c": "Culture",
    "d": "Réseau de 100+ Alliances Françaises aux USA",
    "date": "2025"
  },
  {
    "n": "L’Alliance New York",
    "u": "https://lallianceny.org",
    "c": "Culture",
    "d": "Centre pour les cultures francophones à New York",
    "date": "2025"
  },
  {
    "n": "French Library Boston",
    "u": "https://frenchlibrary.org",
    "c": "Culture",
    "d": "Bibliothèque et centre culturel francophone à Boston",
    "date": "2025"
  },
  {
    "n": "Villa Albertine",
    "u": "https://villa-albertine.org",
    "c": "Culture",
    "d": "Résidences culturelles françaises dans 10 villes américaines",
    "date": "2025"
  },
  {
    "n": "Albertine Books",
    "u": "https://albertine.com",
    "c": "Culture",
    "d": "Librairie française à New York – Cultural Services of the French Embassy",
    "date": "2025"
  },
  {
    "n": "France-Amérique",
    "u": "https://france-amerique.com",
    "c": "Médias",
    "d": "Magazine bilingue mensuel franco-américain",
    "date": "2025"
  },
  {
    "n": "French Morning",
    "u": "https://www.frenchmorning.com",
    "c": "Médias",
    "d": "Actualités en français pour francophones aux USA (NY, LA, Texas, etc.)",
    "date": "2025"
  },
  {
    "n": "Le Courrier de Floride",
    "u": "https://courrierdesameriques.com",
    "c": "Médias",
    "d": "Journal mensuel en français basé à Miami",
    "date": "2025"
  },
  {
    "n": "Le Soleil de la Floride",
    "u": "https://lesoleildelafloride.com",
    "c": "Médias",
    "d": "Journal francophone pour la communauté en Floride",
    "date": "2025"
  },
  {
    "n": "TV5MONDE USA",
    "u": "https://usa.tv5monde.com",
    "c": "Médias",
    "d": "Chaîne francophone 24/7 disponible aux États-Unis",
    "date": "2025"
  },
  {
    "n": "Air France USA",
    "u": "https://www.airfrance.us",
    "c": "Transport",
    "d": "Site complet en français pour vols vers/depuis les USA",
    "date": "2025"
  },
  {
    "n": "French-American Chamber of Commerce New York",
    "u": "https://faccny.org",
    "c": "Commerce",
    "d": "Chambre de commerce franco-américaine à New York",
    "date": "2025"
  },
  {
    "n": "French-American Chamber of Commerce Los Angeles",
    "u": "https://www.facc-la.org",
    "c": "Commerce",
    "d": "Réseau business franco-américain en Californie",
    "date": "2025"
  },
  {
    "n": "UFE USA",
    "u": "https://ufe.org/usa",
    "c": "Culture",
    "d": "Union des Français de l’Étranger – sections USA",
    "date": "2025"
  },
  {
    "n": "French Heritage Society",
    "u": "https://frenchheritagesociety.org",
    "c": "Culture",
    "d": "Préservation du patrimoine français aux USA",
    "date": "2025"
  },
  {
    "n": "American Society of the French Legion of Honor",
    "u": "https://www.frenchlegionusa.org",
    "c": "Culture",
    "d": "Association des décorés de la Légion d’honneur aux USA",
    "date": "2025"
  },
  {
    "n": "Georgetown University – French Department",
    "u": "https://french.georgetown.edu",
    "c": "Éducation",
    "d": "Études françaises et francophones à Washington DC",
    "date": "2025"
  },
  {
    "n": "Columbia University – French Department",
    "u": "https://french.columbia.edu",
    "c": "Éducation",
    "d": "Programmes en français et francophonie à New York",
    "date": "2025"
  },
  {
    "n": "NYU – Department of French Literature",
    "u": "https://as.nyu.edu/french",
    "c": "Éducation",
    "d": "Études françaises et francophones à New York University",
    "date": "2025"
  },
  {
    "n": "Harvard University – French Section",
    "u": "https://rll.fas.harvard.edu/french",
    "c": "Éducation",
    "d": "Département de français et francophonie à Harvard",
    "date": "2025"
  },
  {
    "n": "Yale University – French Department",
    "u": "https://french.yale.edu",
    "c": "Éducation",
    "d": "Études françaises et francophones à Yale",
    "date": "2025"
  },
  {
    "n": "University of Louisiana at Lafayette – Francophonie",
    "u": "https://louisiana.edu/francophonie",
    "c": "Éducation",
    "d": "Centre d’excellence francophone en Louisiane",
    "date": "2025"
  },
  {
    "n": "Brown University – French Studies",
    "u": "https://www.brown.edu/academics/french-studies",
    "c": "Éducation",
    "d": "Études francophones à Brown University",
    "date": "2025"
  },
  {
    "n": "French District",
    "u": "https://frenchdistrict.com",
    "c": "Commerce",
    "d": "Annuaire et actualités des Français aux USA",
    "date": "2025"
  },
  {
    "n": "Bottin.net – USA",
    "u": "https://bottin.net/usa",
    "c": "Commerce",
    "d": "Annuaire gratuit des francophones aux États-Unis",
    "date": "2025"
  },
  {
    "n": "Bonjour New York",
    "u": "https://bonjournewyork.com",
    "c": "Médias",
    "d": "Guide et actualités pour francophones à New York",
    "date": "2025"
  },
  {
    "n": "Miami Accueil",
    "u": "https://www.miami-accueil.org",
    "c": "Culture",
    "d": "Association d’accueil des francophones à Miami",
    "date": "2025"
  },
  {
    "n": "French Tech Miami",
    "u": "https://lafrenchtech.miami",
    "c": "Technologie",
    "d": "Communauté French Tech à Miami",
    "date": "2025"
  },
  {
    "n": "French Tech San Francisco",
    "u": "https://lafrenchtech.com/sanfrancisco",
    "c": "Technologie",
    "d": "Écosystème startup français à San Francisco",
    "date": "2025"
  },
  {
    "n": "Campus France USA",
    "u": "https://www.usa.campusfrance.org",
    "c": "Éducation",
    "d": "Promotion des études en France pour étudiants américains",
    "date": "2025"
  },
  {
    "n": "Lycée Français de New York",
    "u": "https://www.lfny.org",
    "c": "Éducation",
    "d": "École française homologuée à New York",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Chicago",
    "u": "https://www.lyceechicago.org",
    "c": "Éducation",
    "d": "École française à Chicago",
    "date": "2025"
  },
  {
    "n": "Lycée International de Los Angeles",
    "u": "https://www.lila.school",
    "c": "Éducation",
    "d": "École bilingue français-anglais en Californie",
    "date": "2025"
  },
  {
    "n": "École Franco-Américaine de San Francisco",
    "u": "https://www.fasps.org",
    "c": "Éducation",
    "d": "École bilingue à San Francisco",
    "date": "2025"
  },
  {
    "n": "FACE Foundation",
    "u": "https://face-foundation.org",
    "c": "Culture",
    "d": "Soutien aux échanges culturels franco-américains",
    "date": "2025"
  },
  {
    "n": "Albertine Foundation",
    "u": "https://albertine.org",
    "c": "Culture",
    "d": "Librairie et centre culturel français à New York",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal New York",
    "u": "https://lepetitjournal.com/new-york",
    "c": "Médias",
    "d": "Actualités des Français à New York",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal Los Angeles",
    "u": "https://lepetitjournal.com/los-angeles",
    "c": "Médias",
    "d": "Actualités des Français en Californie",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal Miami",
    "u": "https://lepetitjournal.com/miami",
    "c": "Médias",
    "d": "Actualités des Français en Floride",
    "date": "2025"
  },
  {
    "n": "French Morning Los Angeles",
    "u": "https://frenchmorning.com/los-angeles",
    "c": "Médias",
    "d": "Édition locale pour francophones à LA",
    "date": "2025"
  },
  {
    "n": "French Morning San Francisco",
    "u": "https://frenchmorning.com/san-francisco",
    "c": "Médias",
    "d": "Actualités francophones dans la Baie",
    "date": "2025"
  },
  {
    "n": "French Morning Washington DC",
    "u": "https://frenchmorning.com/washington-dc",
    "c": "Médias",
    "d": "Édition locale pour la capitale américaine",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Washington",
    "u": "https://www.lyceerochambeau.org",
    "c": "Éducation",
    "d": "École française à Washington DC",
    "date": "2025"
  },
  {
    "n": "École Française de Seattle",
    "u": "https://www.fas-seattle.org",
    "c": "Éducation",
    "d": "École bilingue à Seattle",
    "date": "2025"
  },
  {
    "n": "French American School of Princeton",
    "u": "https://www.ecoleprinceton.org",
    "c": "Éducation",
    "d": "École bilingue à Princeton",
    "date": "2025"
  },
  {
    "n": "French American International School San Francisco",
    "u": "https://www.frenchamericansf.org",
    "c": "Éducation",
    "d": "École internationale bilingue à SF",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger – Miami",
    "u": "https://ufe.org/miami",
    "c": "Culture",
    "d": "Section UFE pour les expatriés français à Miami",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger – New York",
    "u": "https://ufe.org/new-york",
    "c": "Culture",
    "d": "Section UFE pour New York",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger – Los Angeles",
    "u": "https://ufe.org/los-angeles",
    "c": "Culture",
    "d": "Section UFE pour la Californie",
    "date": "2025"
  },
  {
    "n": "Français du Monde – ADFE USA",
    "u": "https://adfe.org/sections/etats-unis",
    "c": "Culture",
    "d": "Association des Français de l’étranger aux USA",
    "date": "2025"
  },
  {
    "n": "En Marche USA",
    "u": "https://en-marche.fr/etranger/etats-unis",
    "c": "Culture",
    "d": "Mouvement politique des Français aux USA",
    "date": "2025"
  },
  {
    "n": "LREM Americans",
    "u": "https://lrem-americans.org",
    "c": "Culture",
    "d": "Soutien aux Français progressistes aux USA",
    "date": "2025"
  },
  {
    "n": "Alliance Française de New York",
    "u": "https://lallianceny.org",
    "c": "Culture",
    "d": "Cours de français, bibliothèque et événements culturels à NY",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Washington DC",
    "u": "https://francedc.org",
    "c": "Culture",
    "d": "Centre culturel français dans la capitale américaine",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Chicago",
    "u": "https://af-chicago.org",
    "c": "Culture",
    "d": "Cours et événements francophones à Chicago",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Miami",
    "u": "https://af-miami.org",
    "c": "Culture",
    "d": "Cours de français et culture en Floride",
    "date": "2025"
  },
  {
    "n": "Alliance Française de San Francisco",
    "u": "https://afsf.com",
    "c": "Culture",
    "d": "Centre culturel français dans la Baie",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Los Angeles",
    "u": "https://afla.org",
    "c": "Culture",
    "d": "Cours et événements culturels à Los Angeles",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Boston",
    "u": "https://alliancefrancaiseboston.org",
    "c": "Culture",
    "d": "Promotion de la langue et culture françaises à Boston",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Houston",
    "u": "https://afhouston.org",
    "c": "Culture",
    "d": "Cours et événements francophones à Houston",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Seattle",
    "u": "https://afseattle.org",
    "c": "Culture",
    "d": "Centre culturel français à Seattle",
    "date": "2025"
  },
  {
    "n": "French Morning New York",
    "u": "https://frenchmorning.com/new-york",
    "c": "Médias",
    "d": "Actualités en français pour les francophones à New York",
    "date": "2025"
  },
  {
    "n": "French Morning Miami",
    "u": "https://frenchmorning.com/miami",
    "c": "Médias",
    "d": "Actualités pour les francophones en Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français La Pérouse San Francisco",
    "u": "https://www.lelycee.org",
    "c": "Éducation",
    "d": "École française dans la Baie de San Francisco",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Washington",
    "u": "https://www.lyceerocheambeau.org",
    "c": "Éducation",
    "d": "École française à Washington DC",
    "date": "2025"
  },
  {
    "n": "École Franco-Américaine de Providence",
    "u": "https://www.faps.net",
    "c": "Éducation",
    "d": "École bilingue à Rhode Island",
    "date": "2025"
  },
  {
    "n": "New York Accueil",
    "u": "https://www.newyorkaccueil.org",
    "c": "Culture",
    "d": "Association d’accueil des francophones à New York",
    "date": "2025"
  },
  {
    "n": "Los Angeles Accueil",
    "u": "https://www.la-accueil.org",
    "c": "Culture",
    "d": "Association d’accueil des francophones à Los Angeles",
    "date": "2025"
  },
  {
    "n": "Bottin.net USA",
    "u": "https://bottin.net/usa",
    "c": "Commerce",
    "d": "Annuaire gratuit des francophones aux États-Unis",
    "date": "2025"
  },
  {
    "n": "French Tech New York",
    "u": "https://lafrenchtech.com/newyork",
    "c": "Technologie",
    "d": "Communauté French Tech à New York",
    "date": "2025"
  },
  {
    "n": "French-American Chamber of Commerce Miami",
    "u": "https://www.faccmiami.com",
    "c": "Commerce",
    "d": "Chambre de commerce franco-américaine en Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français de San Francisco",
    "u": "https://www.lelycee.org",
    "c": "Éducation",
    "d": "École française homologuée dans la Baie",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Berkeley",
    "u": "https://www.eb.org",
    "c": "Éducation",
    "d": "École bilingue français-anglais à Berkeley",
    "date": "2025"
  },
  {
    "n": "French American School of New York",
    "u": "https://www.fasny.org",
    "c": "Éducation",
    "d": "École bilingue à Westchester (NY)",
    "date": "2025"
  },
  {
    "n": "International School of Boston",
    "u": "https://www.isbos.org",
    "c": "Éducation",
    "d": "École internationale avec section française",
    "date": "2025"
  },
  {
    "n": "French Cultural Center Boston",
    "u": "https://frenchculturalcenter.org",
    "c": "Culture",
    "d": "Centre culturel français à Boston (devenu French Library)",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Denver",
    "u": "https://afdenver.org",
    "c": "Culture",
    "d": "Cours et événements francophones à Denver",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Philadelphia",
    "u": "https://afphila.com",
    "c": "Culture",
    "d": "Centre culturel français à Philadelphie",
    "date": "2025"
  },
  {
    "n": "Alliance Française d’Atlanta",
    "u": "https://afatl.com",
    "c": "Culture",
    "d": "Promotion de la langue française à Atlanta",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Dallas",
    "u": "https://afdallas.org",
    "c": "Culture",
    "d": "Cours et événements culturels à Dallas",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Portland",
    "u": "https://www.fapdx.org",
    "c": "Éducation",
    "d": "École française à Portland",
    "date": "2025"
  },
  {
    "n": "French American School of Rhode Island",
    "u": "https://www.fasri.org",
    "c": "Éducation",
    "d": "École bilingue à Providence",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Minneapolis",
    "u": "https://afmsp.org",
    "c": "Culture",
    "d": "Centre culturel français à Minneapolis",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Detroit",
    "u": "https://afdetroit.org",
    "c": "Culture",
    "d": "Promotion de la culture française à Detroit",
    "date": "2025"
  },
  {
    "n": "French Institute Alliance Française (FIAF) New York",
    "u": "https://fiaf.org",
    "c": "Culture",
    "d": "Plus grande institution française de New York",
    "date": "2025"
  },
  {
    "n": "Cultural Services French Embassy USA",
    "u": "https://frenchculture.org",
    "c": "Culture",
    "d": "Services culturels de l’ambassade de France aux USA",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger – San Francisco",
    "u": "https://ufe.org/san-francisco",
    "c": "Culture",
    "d": "Section UFE pour la Baie",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger – Washington DC",
    "u": "https://ufe.org/washington",
    "c": "Culture",
    "d": "Section UFE pour la capitale",
    "date": "2025"
  },
  {
    "n": "French Morning Texas",
    "u": "https://frenchmorning.com/texas",
    "c": "Médias",
    "d": "Actualités francophones au Texas",
    "date": "2025"
  },
  {
    "n": "French Morning Chicago",
    "u": "https://frenchmorning.com/chicago",
    "c": "Médias",
    "d": "Édition locale pour le Midwest",
    "date": "2025"
  },
  {
    "n": "Bonjour Florida",
    "u": "https://bonjourflorida.com",
    "c": "Médias",
    "d": "Guide et actualités pour francophones en Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Palm Beach",
    "u": "https://www.efipb.org",
    "c": "Éducation",
    "d": "École française en Floride du Sud",
    "date": "2025"
  },
  {
    "n": "École Duval Jacksonville",
    "u": "https://www.ecoleduval.org",
    "c": "Éducation",
    "d": "Programme français à Jacksonville",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Palm Beach",
    "u": "https://afpb.net",
    "c": "Culture",
    "d": "Cours et événements en Floride",
    "date": "2025"
  },
  {
    "n": "French American Chamber of Commerce Chicago",
    "u": "https://www.facc-chicago.com",
    "c": "Commerce",
    "d": "Réseau business franco-américain à Chicago",
    "date": "2025"
  },
  {
    "n": "French American Chamber of Commerce Florida",
    "u": "https://www.faccflorida.com",
    "c": "Commerce",
    "d": "Chambre de commerce en Floride",
    "date": "2025"
  },
  {
    "n": "French Tech Boston",
    "u": "https://lafrenchtech.com/boston",
    "c": "Technologie",
    "d": "Communauté French Tech à Boston",
    "date": "2025"
  },
  {
    "n": "French Tech Washington DC",
    "u": "https://lafrenchtech.com/washington",
    "c": "Technologie",
    "d": "Écosystème startup français à DC",
    "date": "2025"
  },
  {
    "n": "French Tech Los Angeles",
    "u": "https://lafrenchtech.com/losangeles",
    "c": "Technologie",
    "d": "Communauté French Tech en Californie",
    "date": "2025"
  },
  {
    "n": "Campus France New York",
    "u": "https://www.campusfrance.org/en/new-york",
    "c": "Éducation",
    "d": "Bureau Campus France à New York",
    "date": "2025"
  },
  {
    "n": "Campus France Washington",
    "u": "https://www.campusfrance.org/en/washington",
    "c": "Éducation",
    "d": "Bureau Campus France à Washington DC",
    "date": "2025"
  },
  {
    "n": "Campus France Los Angeles",
    "u": "https://www.campusfrance.org/en/los-angeles",
    "c": "Éducation",
    "d": "Bureau Campus France en Californie",
    "date": "2025"
  },
  {
    "n": "Campus France Miami",
    "u": "https://www.campusfrance.org/en/miami",
    "c": "Éducation",
    "d": "Bureau Campus France en Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Houston",
    "u": "https://www.efht.org",
    "c": "Éducation",
    "d": "École française à Houston",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Houston",
    "u": "https://www.ebh-usa.org",
    "c": "Éducation",
    "d": "École bilingue français-anglais à Houston",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Portland",
    "u": "https://afportland.org",
    "c": "Culture",
    "d": "Centre culturel français à Portland",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Austin",
    "u": "https://afaustin.org",
    "c": "Culture",
    "d": "Cours et événements francophones à Austin",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Nashville",
    "u": "https://afnashville.org",
    "c": "Culture",
    "d": "Promotion de la culture française au Tennessee",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Charlotte",
    "u": "https://afcharlotte.org",
    "c": "Culture",
    "d": "Centre culturel français en Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "French American School of Denver",
    "u": "https://www.fasdenver.org",
    "c": "Éducation",
    "d": "École bilingue à Denver",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Denver",
    "u": "https://www.denverlycee.org",
    "c": "Éducation",
    "d": "École française à Denver",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Saint Louis",
    "u": "https://afstl.org",
    "c": "Culture",
    "d": "Cours et événements à Saint Louis",
    "date": "2025"
  },
  {
    "n": "French Cultural Center of New England",
    "u": "https://frenchculturalcenter.org",
    "c": "Culture",
    "d": "Centre culturel français en Nouvelle-Angleterre",
    "date": "2025"
  },
  {
    "n": "Fédération des Alliances Françaises USA",
    "u": "https://afusa.org",
    "c": "Culture",
    "d": "Réseau national de 100+ Alliances Françaises",
    "date": "2025"
  },
  {
    "n": "Alliance Française New York",
    "u": "https://lallianceny.org",
    "c": "Culture",
    "d": "Cours, bibliothèque et événements à New York",
    "date": "2025"
  },
  {
    "n": "Alliance Française Washington DC",
    "u": "https://francedc.org",
    "c": "Culture",
    "d": "Centre culturel français à Washington",
    "date": "2025"
  },
  {
    "n": "Alliance Française Chicago",
    "u": "https://af-chicago.org",
    "c": "Culture",
    "d": "Cours et culture française à Chicago",
    "date": "2025"
  },
  {
    "n": "Alliance Française Miami",
    "u": "https://af-miami.org",
    "c": "Culture",
    "d": "Centre culturel français en Floride",
    "date": "2025"
  },
  {
    "n": "Alliance Française San Francisco",
    "u": "https://afsf.com",
    "c": "Culture",
    "d": "Alliance Française de la Baie",
    "date": "2025"
  },
  {
    "n": "Alliance Française Los Angeles",
    "u": "https://afla.org",
    "c": "Culture",
    "d": "Cours et événements culturels à LA",
    "date": "2025"
  },
  {
    "n": "Alliance Française Boston",
    "u": "https://afboston.org",
    "c": "Culture",
    "d": "Centre culturel français à Boston",
    "date": "2025"
  },
  {
    "n": "Alliance Française Houston",
    "u": "https://afhouston.org",
    "c": "Culture",
    "d": "Alliance Française de Houston",
    "date": "2025"
  },
  {
    "n": "Alliance Française Seattle",
    "u": "https://afseattle.org",
    "c": "Culture",
    "d": "Centre culturel français à Seattle",
    "date": "2025"
  },
  {
    "n": "Alliance Française Atlanta",
    "u": "https://afatl.com",
    "c": "Culture",
    "d": "Alliance Française d’Atlanta",
    "date": "2025"
  },
  {
    "n": "Alliance Française Denver",
    "u": "https://afdenver.org",
    "c": "Culture",
    "d": "Alliance Française de Denver",
    "date": "2025"
  },
  {
    "n": "Alliance Française Philadelphia",
    "u": "https://afphila.com",
    "c": "Culture",
    "d": "Alliance Française de Philadelphie",
    "date": "2025"
  },
  {
    "n": "Alliance Française Dallas",
    "u": "https://afdallas.org",
    "c": "Culture",
    "d": "Alliance Française de Dallas",
    "date": "2025"
  },
  {
    "n": "Alliance Française Palm Beach",
    "u": "https://afpb.net",
    "c": "Culture",
    "d": "Alliance Française de Palm Beach",
    "date": "2025"
  },
  {
    "n": "French Morning",
    "u": "https://frenchmorning.com",
    "c": "Médias",
    "d": "Actualités en français pour francophones USA",
    "date": "2025"
  },
  {
    "n": "Los Angeles Accueil",
    "u": "https://la-accueil.org",
    "c": "Culture",
    "d": "Accueil des francophones à Los Angeles",
    "date": "2025"
  },
  {
    "n": "French-American Chamber of Commerce Los Angeles",
    "u": "https://facc-la.org",
    "c": "Commerce",
    "d": "Chambre de commerce franco-américaine LA",
    "date": "2025"
  },
  {
    "n": "French-American Chamber of Commerce Miami",
    "u": "https://faccmiami.com",
    "c": "Commerce",
    "d": "Chambre de commerce franco-américaine Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Houston",
    "u": "https://efht.org",
    "c": "Éducation",
    "d": "École française à Houston",
    "date": "2025"
  },
  {
    "n": "French American School of Denver",
    "u": "https://fasdenver.org",
    "c": "Éducation",
    "d": "École bilingue Denver",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Denver",
    "u": "https://denverlycee.org",
    "c": "Éducation",
    "d": "École française Denver",
    "date": "2025"
  },
  {
    "n": "French Cultural Center New England",
    "u": "https://frenchculturalcenter.org",
    "c": "Culture",
    "d": "Centre culturel français Nouvelle-Angleterre",
    "date": "2025"
  },
  {
    "n": "FIAF New York",
    "u": "https://fiaf.org",
    "c": "Culture",
    "d": "French Institute Alliance Française New York",
    "date": "2025"
  },
  {
    "n": "Cultural Services French Embassy",
    "u": "https://frenchculture.org",
    "c": "Culture",
    "d": "Services culturels Ambassade de France USA",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger Miami",
    "u": "https://ufe.org/miami",
    "c": "Culture",
    "d": "Section UFE Miami",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger New York",
    "u": "https://ufe.org/new-york",
    "c": "Culture",
    "d": "Section UFE New York",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger Los Angeles",
    "u": "https://ufe.org/los-angeles",
    "c": "Culture",
    "d": "Section UFE Los Angeles",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger San Francisco",
    "u": "https://ufe.org/san-francisco",
    "c": "Culture",
    "d": "Section UFE San Francisco",
    "date": "2025"
  },
  {
    "n": "Union des Français de l’Étranger Washington",
    "u": "https://ufe.org/washington",
    "c": "Culture",
    "d": "Section UFE Washington DC",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Palm Beach",
    "u": "https://efipb.org",
    "c": "Éducation",
    "d": "École française Palm Beach",
    "date": "2025"
  },
  {
    "n": "École Duval Jacksonville",
    "u": "https://ecoleduval.org",
    "c": "Éducation",
    "d": "Programme français Jacksonville",
    "date": "2025"
  },
  {
    "n": "French American Chamber of Commerce Chicago",
    "u": "https://facc-chicago.com",
    "c": "Commerce",
    "d": "Chambre de commerce Chicago",
    "date": "2025"
  },
  {
    "n": "Campus France New York",
    "u": "https://campusfrance.org/en/new-york",
    "c": "Éducation",
    "d": "Bureau Campus France New York",
    "date": "2025"
  },
  {
    "n": "Campus France Washington",
    "u": "https://campusfrance.org/en/washington",
    "c": "Éducation",
    "d": "Bureau Campus France Washington",
    "date": "2025"
  },
  {
    "n": "Campus France Los Angeles",
    "u": "https://campusfrance.org/en/los-angeles",
    "c": "Éducation",
    "d": "Bureau Campus France Los Angeles",
    "date": "2025"
  },
  {
    "n": "Campus France Miami",
    "u": "https://campusfrance.org/en/miami",
    "c": "Éducation",
    "d": "Bureau Campus France Miami",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Houston",
    "u": "https://ebh-usa.org",
    "c": "Éducation",
    "d": "École bilingue Houston",
    "date": "2025"
  },
  {
    "n": "French American School of Princeton",
    "u": "https://ecoleprinceton.org",
    "c": "Éducation",
    "d": "École bilingue Princeton",
    "date": "2025"
  },
  {
    "n": "École Française de Seattle",
    "u": "https://fas-seattle.org",
    "c": "Éducation",
    "d": "École bilingue Seattle",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Portland",
    "u": "https://fapdx.org",
    "c": "Éducation",
    "d": "École française Portland",
    "date": "2025"
  },
  {
    "n": "French American School of Rhode Island",
    "u": "https://fasri.org",
    "c": "Éducation",
    "d": "École bilingue Providence",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Cincinnati",
    "u": "https://afcincinnati.org",
    "c": "Culture",
    "d": "Alliance Française Cincinnati",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Milwaukee",
    "u": "https://afmilwaukee.org",
    "c": "Culture",
    "d": "Alliance Française Milwaukee",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Kansas City",
    "u": "https://afkc.org",
    "c": "Culture",
    "d": "Alliance Française Kansas City",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Santa Rosa",
    "u": "https://afsantarosa.org",
    "c": "Culture",
    "d": "Alliance Française Californie du Nord",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Honolulu",
    "u": "https://afhawaii.org",
    "c": "Culture",
    "d": "Alliance Française Hawaii",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Tucson",
    "u": "https://aftucson.org",
    "c": "Culture",
    "d": "Alliance Française Arizona",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Greenwich",
    "u": "https://afgreenwich.org",
    "c": "Culture",
    "d": "Alliance Française Connecticut",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Hartford",
    "u": "https://afhartford.org",
    "c": "Culture",
    "d": "Alliance Française Hartford",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Westchester",
    "u": "https://afwestchesterny.org",
    "c": "Culture",
    "d": "Alliance Française région New York",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Princeton",
    "u": "https://afprinceton.org",
    "c": "Culture",
    "d": "Alliance Française New Jersey",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Long Island",
    "u": "https://aflongisland.org",
    "c": "Culture",
    "d": "Alliance Française Long Island",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Rochester",
    "u": "https://afrochester.org",
    "c": "Culture",
    "d": "Alliance Française Rochester NY",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Madison",
    "u": "https://afmadison.org",
    "c": "Culture",
    "d": "Alliance Française Wisconsin",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Pittsburgh",
    "u": "https://afpittsburgh.org",
    "c": "Culture",
    "d": "Alliance Française Pittsburgh",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Cleveland",
    "u": "https://afcleveland.org",
    "c": "Culture",
    "d": "Alliance Française Ohio",
    "date": "2025"
  },
  {
    "n": "Alliance Française d’Omaha",
    "u": "https://afomaha.org",
    "c": "Culture",
    "d": "Alliance Française Nebraska",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Louisville",
    "u": "https://aflouisville.org",
    "c": "Culture",
    "d": "Alliance Française Kentucky",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Birmingham",
    "u": "https://afbirmingham.org",
    "c": "Culture",
    "d": "Alliance Française Alabama",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Charleston",
    "u": "https://afcharleston.org",
    "c": "Culture",
    "d": "Alliance Française Caroline du Sud",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Raleigh",
    "u": "https://afraleigh.org",
    "c": "Culture",
    "d": "Alliance Française Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "Alliance Française d’Orlando",
    "u": "https://aforlando.org",
    "c": "Culture",
    "d": "Alliance Française Floride centrale",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Sarasota",
    "u": "https://afsarasota.org",
    "c": "Culture",
    "d": "Alliance Française côte ouest Floride",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Naples",
    "u": "https://afnaples.org",
    "c": "Culture",
    "d": "Alliance Française sud-ouest Floride",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Saint Augustine",
    "u": "https://afstaugustine.org",
    "c": "Culture",
    "d": "Alliance Française plus ancienne ville USA",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Santa Fe",
    "u": "https://afsantafe.org",
    "c": "Culture",
    "d": "Alliance Française Nouveau-Mexique",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Albuquerque",
    "u": "https://afabq.org",
    "c": "Culture",
    "d": "Alliance Française Albuquerque",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Las Vegas",
    "u": "https://aflasvegas.org",
    "c": "Culture",
    "d": "Alliance Française Nevada",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Salt Lake City",
    "u": "https://afsaltlakecity.org",
    "c": "Culture",
    "d": "Alliance Française Utah",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Boise",
    "u": "https://afboise.org",
    "c": "Culture",
    "d": "Alliance Française Idaho",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Anchorage",
    "u": "https://afanchorage.org",
    "c": "Culture",
    "d": "Alliance Française Alaska",
    "date": "2025"
  },
  {
    "n": "Alliance Française de San Diego",
    "u": "https://afsandiego.org",
    "c": "Culture",
    "d": "Alliance Française San Diego",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Santa Barbara",
    "u": "https://afsantabarbara.org",
    "c": "Culture",
    "d": "Alliance Française Santa Barbara",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Sacramento",
    "u": "https://afsacramento.org",
    "c": "Culture",
    "d": "Alliance Française Sacramento",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Silicon Valley",
    "u": "https://afscv.org",
    "c": "Culture",
    "d": "Alliance Française cœur tech USA",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Monterey Bay",
    "u": "https://afmontereybay.org",
    "c": "Culture",
    "d": "Alliance Française région Monterey",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Fresno",
    "u": "https://affresno.org",
    "c": "Culture",
    "d": "Alliance Française vallée centrale Californie",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Colorado Springs",
    "u": "https://afcoloradosprings.org",
    "c": "Culture",
    "d": "Alliance Française Colorado",
    "date": "2025"
  },
  {
    "n": "Alliance Française d’Asheville",
    "u": "https://afasheville.org",
    "c": "Culture",
    "d": "Alliance Française Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Greenville",
    "u": "https://afgreenville.org",
    "c": "Culture",
    "d": "Alliance Française Caroline du Sud",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Savannah",
    "u": "https://afsavannah.org",
    "c": "Culture",
    "d": "Alliance Française Géorgie",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Baton Rouge",
    "u": "https://afbatonrouge.org",
    "c": "Culture",
    "d": "Alliance Française Louisiane",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Lafayette",
    "u": "https://aflafayette.org",
    "c": "Culture",
    "d": "Alliance Française cœur Acadie américaine",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Shreveport",
    "u": "https://afshreveport.org",
    "c": "Culture",
    "d": "Alliance Française nord Louisiane",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Jackson",
    "u": "https://afjackson.org",
    "c": "Culture",
    "d": "Alliance Française Mississippi",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Little Rock",
    "u": "https://aflittlerock.org",
    "c": "Culture",
    "d": "Alliance Française Arkansas",
    "date": "2025"
  },
  {
    "n": "Alliance Française d’Oklahoma City",
    "u": "https://afokc.org",
    "c": "Culture",
    "d": "Alliance Française Oklahoma",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Tulsa",
    "u": "https://aftulsa.org",
    "c": "Culture",
    "d": "Alliance Française Oklahoma",
    "date": "2025"
  },
  {
    "n": "Alliance Française de San Antonio",
    "u": "https://afsanantonio.org",
    "c": "Culture",
    "d": "Alliance Française Texas",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Corpus Christi",
    "u": "https://afcorpuschristi.org",
    "c": "Culture",
    "d": "Alliance Française côte Texas",
    "date": "2025"
  },
  {
    "n": "Alliance Française de El Paso",
    "u": "https://afelpaso.org",
    "c": "Culture",
    "d": "Alliance Française frontière mexicaine",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Phoenix",
    "u": "https://afphoenix.org",
    "c": "Culture",
    "d": "Alliance Française Arizona",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Scottsdale",
    "u": "https://afscottsdale.org",
    "c": "Culture",
    "d": "Alliance Française région Phoenix",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Maui",
    "u": "https://afmaui.org",
    "c": "Culture",
    "d": "Alliance Française île Maui",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Fairbanks",
    "u": "https://affairbanks.org",
    "c": "Culture",
    "d": "Alliance Française intérieur Alaska",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Juneau",
    "u": "https://afjuneau.org",
    "c": "Culture",
    "d": "Alliance Française capitale Alaska",
    "date": "2025"
  },
  {
    "n": "Lycée Français de La Nouvelle-Orléans",
    "u": "https://lfno.org",
    "c": "Éducation",
    "d": "École française historique Louisiane",
    "date": "2025"
  },
  {
    "n": "École Bilingue de La Nouvelle-Orléans",
    "u": "https://eblions.org",
    "c": "Éducation",
    "d": "École bilingue française Louisiane",
    "date": "2025"
  },
  {
    "n": "Audubon Charter School French Program",
    "u": "https://auduboncharter.org",
    "c": "Éducation",
    "d": "Programme immersion française public",
    "date": "2025"
  },
  {
    "n": "International School of Louisiana",
    "u": "https://isl-edu.org",
    "c": "Éducation",
    "d": "École publique bilingue français-anglais",
    "date": "2025"
  },
  {
    "n": "Awty International School French Track",
    "u": "https://awty.org",
    "c": "Éducation",
    "d": "Programme français prestigieux Houston",
    "date": "2025"
  },
  {
    "n": "French American School of Dallas",
    "u": "https://fasdallas.org",
    "c": "Éducation",
    "d": "École bilingue Dallas",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Miami",
    "u": "https://miamilycee.org",
    "c": "Éducation",
    "d": "École française homologuée Floride",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française Miami",
    "u": "https://efmiami.org",
    "c": "Éducation",
    "d": "Maternelle française Miami",
    "date": "2025"
  },
  {
    "n": "French American Academy Miami",
    "u": "https://faamiami.org",
    "c": "Éducation",
    "d": "École bilingue Miami",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Los Angeles",
    "u": "https://lyceela.org",
    "c": "Éducation",
    "d": "École française Los Angeles",
    "date": "2025"
  },
  {
    "n": "Le Lycée Français de San Francisco",
    "u": "https://lelycee.org",
    "c": "Éducation",
    "d": "École française Baie de San Francisco",
    "date": "2025"
  },
  {
    "n": "French American School of Silicon Valley",
    "u": "https://fasv.org",
    "c": "Éducation",
    "d": "École bilingue cœur tech USA",
    "date": "2025"
  },
  {
    "n": "Lycée Français de New York",
    "u": "https://lfny.org",
    "c": "Éducation",
    "d": "École française New York",
    "date": "2025"
  },
  {
    "n": "French American School of New York",
    "u": "https://fasny.org",
    "c": "Éducation",
    "d": "École bilingue Westchester",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Washington DC",
    "u": "https://lyceerocheambeau.org",
    "c": "Éducation",
    "d": "École française Washington",
    "date": "2025"
  },
  {
    "n": "Washington International School French Program",
    "u": "https://wis.edu",
    "c": "Éducation",
    "d": "Programme français prestigieux DC",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Chicago",
    "u": "https://lyceechicago.org",
    "c": "Éducation",
    "d": "École française Chicago",
    "date": "2025"
  },
  {
    "n": "École Franco-Américaine de Chicago",
    "u": "https://efachicago.org",
    "c": "Éducation",
    "d": "École bilingue Chicago",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Boston",
    "u": "https://lfboston.org",
    "c": "Éducation",
    "d": "École française Boston",
    "date": "2025"
  },
  {
    "n": "International School of Boston",
    "u": "https://isbos.org",
    "c": "Éducation",
    "d": "École internationale bilingue Boston",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Seattle",
    "u": "https://fas-seattle.org",
    "c": "Éducation",
    "d": "École française Seattle",
    "date": "2025"
  },
  {
    "n": "French Immersion School of Washington",
    "u": "https://fisw.org",
    "c": "Éducation",
    "d": "École immersion française Seattle",
    "date": "2025"
  },
  {
    "n": "French American School of Arizona",
    "u": "https://fasaz.org",
    "c": "Éducation",
    "d": "École bilingue Phoenix",
    "date": "2025"
  },
  {
    "n": "Lycée Français de San Diego",
    "u": "https://lfisd.org",
    "c": "Éducation",
    "d": "École française San Diego",
    "date": "2025"
  },
  {
    "n": "French American School of Tampa Bay",
    "u": "https://fastb.org",
    "c": "Éducation",
    "d": "École bilingue région Tampa",
    "date": "2025"
  },
  {
    "n": "Lycée Français d’Atlanta",
    "u": "https://lfatl.org",
    "c": "Éducation",
    "d": "École française Atlanta",
    "date": "2025"
  },
  {
    "n": "International Charter School of Atlanta",
    "u": "https://icsatlanta.org",
    "c": "Éducation",
    "d": "École publique bilingue français",
    "date": "2025"
  },
  {
    "n": "French American School of Music Minnesota",
    "u": "https://fasm-mn.org",
    "c": "Éducation",
    "d": "École musique française Minneapolis",
    "date": "2025"
  },
  {
    "n": "Alliance Française Mpls/St Paul",
    "u": "https://afmsp.org",
    "c": "Culture",
    "d": "Alliance Française Twin Cities",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Minneapolis",
    "u": "https://lfminneapolis.org",
    "c": "Éducation",
    "d": "Programme français Minnesota",
    "date": "2025"
  },
  {
    "n": "Tandem Français-Immersion",
    "u": "https://tandem-immersion.org",
    "c": "Éducation",
    "d": "Cours immersion française tous âges",
    "date": "2025"
  },
  {
    "n": "École Française du Maine",
    "u": "https://efmaine.org",
    "c": "Éducation",
    "d": "École française Maine",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Portland Maine",
    "u": "https://lyceefrançaisportland.org",
    "c": "Éducation",
    "d": "École française nord-est",
    "date": "2025"
  },
  {
    "n": "French School of Detroit",
    "u": "https://fsdetroit.org",
    "c": "Éducation",
    "d": "École française Michigan",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Berkeley",
    "u": "https://eb.org",
    "c": "Éducation",
    "d": "École bilingue Berkeley",
    "date": "2025"
  },
  {
    "n": "French American School of Puget Sound",
    "u": "https://fasps.org",
    "c": "Éducation",
    "d": "École bilingue région Seattle",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Santa Barbara",
    "u": "https://lyceesb.org",
    "c": "Éducation",
    "d": "École française côte centrale Californie",
    "date": "2025"
  },
  {
    "n": "École Claire Fontaine",
    "u": "https://ecoleclairefontaine.org",
    "c": "Éducation",
    "d": "Maternelle française Los Angeles",
    "date": "2025"
  },
  {
    "n": "Le Petit Gan",
    "u": "https://lepetitgan.com",
    "c": "Éducation",
    "d": "Maternelle française bilingue",
    "date": "2025"
  },
  {
    "n": "Les Petits Citoyens",
    "u": "https://lespetitscitoyens.org",
    "c": "Éducation",
    "d": "École maternelle française Miami",
    "date": "2025"
  },
  {
    "n": "Lycée Français International de Palm Beach",
    "u": "https://lfipb.org",
    "c": "Éducation",
    "d": "École française Palm Beach",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française Los Angeles",
    "u": "https://emfla.org",
    "c": "Éducation",
    "d": "Maternelle française LA",
    "date": "2025"
  },
  {
    "n": "Le Jardin des Enfants",
    "u": "https://lejardindesenfants.org",
    "c": "Éducation",
    "d": "Maternelle française San Francisco",
    "date": "2025"
  },
  {
    "n": "La Petite Ecole",
    "u": "https://lapetiteecole.org",
    "c": "Éducation",
    "d": "Maternelle française New York",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française Washington",
    "u": "https://emfw.org",
    "c": "Éducation",
    "d": "Maternelle française DC",
    "date": "2025"
  },
  {
    "n": "Les Petits Sourires",
    "u": "https://lespetitssourires.org",
    "c": "Éducation",
    "d": "Maternelle française Houston",
    "date": "2025"
  },
  {
    "n": "La Maternelle Française",
    "u": "https://lamaternellefrancaise.org",
    "c": "Éducation",
    "d": "Maternelle française Chicago",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Boston",
    "u": "https://ebboston.org",
    "c": "Éducation",
    "d": "École bilingue Boston",
    "date": "2025"
  },
  {
    "n": "French American School of Miami",
    "u": "https://fasmiami.org",
    "c": "Éducation",
    "d": "École bilingue Miami",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Philadelphie",
    "u": "https://lfphila.org",
    "c": "Éducation",
    "d": "École française Philadelphie",
    "date": "2025"
  },
  {
    "n": "French International School of Philadelphia",
    "u": "https://fisphila.org",
    "c": "Éducation",
    "d": "École internationale bilingue",
    "date": "2025"
  },
  {
    "n": "École Française de Cleveland",
    "u": "https://efcleveland.org",
    "c": "Éducation",
    "d": "Programme français Ohio",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Raleigh",
    "u": "https://lfraleigh.org",
    "c": "Éducation",
    "d": "École française Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "French American Academy",
    "u": "https://faacademy.org",
    "c": "Éducation",
    "d": "Écoles bilingues New Jersey",
    "date": "2025"
  },
  {
    "n": "École Bilingue de New Jersey",
    "u": "https://ebnj.org",
    "c": "Éducation",
    "d": "École bilingue New Jersey",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Greenwich",
    "u": "https://lfgreenwich.org",
    "c": "Éducation",
    "d": "École française Connecticut",
    "date": "2025"
  },
  {
    "n": "French American School of Music",
    "u": "https://fasm.org",
    "c": "Éducation",
    "d": "Conservatoire français New York",
    "date": "2025"
  },
  {
    "n": "Conservatoire Français de Musique",
    "u": "https://conservatoirefrancais.org",
    "c": "Éducation",
    "d": "Cours musique classique française",
    "date": "2025"
  },
  {
    "n": "École de Danse Française",
    "u": "https://ecolededanse.org",
    "c": "Éducation",
    "d": "Cours danse classique française",
    "date": "2025"
  },
  {
    "n": "Atelier Théâtre Français",
    "u": "https://ateliertheatre.org",
    "c": "Culture",
    "d": "Cours théâtre en français",
    "date": "2025"
  },
  {
    "n": "Ciné-Club Français",
    "u": "https://cineclubfrancais.org",
    "c": "Culture",
    "d": "Projections cinéma français",
    "date": "2025"
  },
  {
    "n": "Club de Lecture Français",
    "u": "https://clublecturefrancais.org",
    "c": "Culture",
    "d": "Club lecture littérature française",
    "date": "2025"
  },
  {
    "n": "Café Polyglotte Français",
    "u": "https://cafepolyglotte.org",
    "c": "Culture",
    "d": "Rencontres conversation française",
    "date": "2025"
  },
  {
    "n": "French Tech Hub",
    "u": "https://frenchtechhub.org",
    "c": "Technologie",
    "d": "Réseau startups françaises USA",
    "date": "2025"
  },
  {
    "n": "Business France USA",
    "u": "https://businessfrance.fr",
    "c": "Commerce",
    "d": "Agence promotion entreprises françaises",
    "date": "2025"
  },
  {
    "n": "French Founders USA",
    "u": "https://frenchfounders.com",
    "c": "Commerce",
    "d": "Réseau entrepreneurs français",
    "date": "2025"
  },
  {
    "n": "La French Touch Conference",
    "u": "https://lafrenchtouchconference.com",
    "c": "Technologie",
    "d": "Événement tech française USA",
    "date": "2025"
  },
  {
    "n": "French American Business Awards",
    "u": "https://faba-usa.com",
    "c": "Commerce",
    "d": "Prix entreprises franco-américaines",
    "date": "2025"
  },
  {
    "n": "French American Entrepreneurship Award",
    "u": "https://faea.org",
    "c": "Commerce",
    "d": "Concours startups franco-américaines",
    "date": "2025"
  },
  {
    "n": "SelectUSA France",
    "u": "https://selectusa.fr",
    "c": "Commerce",
    "d": "Promotion investissements USA pour entreprises françaises",
    "date": "2025"
  },
  {
    "n": "French American Chamber of Commerce",
    "u": "https://faccnetwork.org",
    "c": "Commerce",
    "d": "Réseau national FAC",
    "date": "2025"
  },
  {
    "n": "French American Digital Network",
    "u": "https://fadn.org",
    "c": "Technologie",
    "d": "Réseau digital franco-américain",
    "date": "2025"
  },
  {
    "n": "French Tech Communities USA",
    "u": "https://lafrenchtech.com",
    "c": "Technologie",
    "d": "Toutes les communautés French Tech USA",
    "date": "2025"
  },
  {
    "n": "Station F USA",
    "u": "https://stationf.co/usa",
    "c": "Technologie",
    "d": "Programme Station F pour startups aux USA",
    "date": "2025"
  },
  {
    "n": "Viva Technology USA",
    "u": "https://vivatechnology.com/usa",
    "c": "Technologie",
    "d": "Événement tech français aux USA",
    "date": "2025"
  },
  {
    "n": "French American Science Festival",
    "u": "https://fasciencefestival.org",
    "c": "Culture",
    "d": "Festival science française USA",
    "date": "2025"
  },
  {
    "n": "Goût de France USA",
    "u": "https://goutdefrance.com",
    "c": "Culture",
    "d": "Événement gastronomie française",
    "date": "2025"
  },
  {
    "n": "Bastille Day USA",
    "u": "https://bastilledayusa.org",
    "c": "Culture",
    "d": "Fête nationale française aux USA",
    "date": "2025"
  },
  {
    "n": "French Film Festival USA",
    "u": "https://frenchfilmfestival.us",
    "c": "Culture",
    "d": "Festival cinéma français",
    "date": "2025"
  },
  {
    "n": "Tournée des Chefs Français",
    "u": "https://tourneedeschefs.com",
    "c": "Culture",
    "d": "Chefs étoilés français aux USA",
    "date": "2025"
  },
  {
    "n": "French Wine Society USA",
    "u": "https://frenchwinesociety.org",
    "c": "Culture",
    "d": "Association vins français",
    "date": "2025"
  },
  {
    "n": "French Cheese Board",
    "u": "https://frenchcheeseboard.com",
    "c": "Culture",
    "d": "Promotion fromages français New York",
    "date": "2025"
  },
  {
    "n": "So French Bazaar",
    "u": "https://sofrenchbazaar.com",
    "c": "Commerce",
    "d": "Marketplace produits français",
    "date": "2025"
  },
  {
    "n": "My Little America",
    "u": "https://mylittleamerica.com",
    "c": "Commerce",
    "d": "Épicerie française en ligne",
    "date": "2025"
  },
  {
    "n": "French Wink",
    "u": "https://frenchwink.com",
    "c": "Commerce",
    "d": "Marketplace mode et beauté française",
    "date": "2025"
  },
  {
    "n": "French Morning Marketplace",
    "u": "https://marketplace.frenchmorning.com",
    "c": "Commerce",
    "d": "Produits français aux USA",
    "date": "2025"
  },
  {
    "n": "La Maison Française",
    "u": "https://lamaisonfrancaise.org",
    "c": "Culture",
    "d": "Boutique culturelle Rockefeller Center",
    "date": "2025"
  },
  {
    "n": "Albertine Bookstore",
    "u": "https://albertine.com",
    "c": "Culture",
    "d": "Librairie française New York",
    "date": "2025"
  },
  {
    "n": "Librairie Française de Los Angeles",
    "u": "https://librairiefrancaise.com",
    "c": "Culture",
    "d": "Librairie française LA",
    "date": "2025"
  },
  {
    "n": "Librairie de France Miami",
    "u": "https://librairiedefrance.com",
    "c": "Culture",
    "d": "Librairie française Floride",
    "date": "2025"
  },
  {
    "n": "French Cultural Center",
    "u": "https://frenchculturalcenter.org",
    "c": "Culture",
    "d": "Centre culturel Boston",
    "date": "2025"
  },
  {
    "n": "French Institute Alliance Française",
    "u": "https://fiaf.org",
    "c": "Culture",
    "d": "FIAF New York",
    "date": "2025"
  },
  {
    "n": "Services Culturels Ambassade de France",
    "u": "https://frenchculture.org",
    "c": "Culture",
    "d": "Programmation culturelle nationale",
    "date": "2025"
  },
  {
    "n": "French American Museum Exchange",
    "u": "https://frame-museums.org",
    "c": "Culture",
    "d": "Échanges muséaux franco-américains",
    "date": "2025"
  },
  {
    "n": "American Friends of Versailles",
    "u": "https://americanfriendsofversailles.org",
    "c": "Culture",
    "d": "Soutien château de Versailles depuis USA",
    "date": "2025"
  },
  {
    "n": "American Society of Le Souvenir Français",
    "u": "https://souvenirfrancais-usa.org",
    "c": "Culture",
    "d": "Entretien tombes soldats français",
    "date": "2025"
  },
  {
    "n": "French War Veterans USA",
    "u": "https://fwv-usa.org",
    "c": "Culture",
    "d": "Association anciens combattants français",
    "date": "2025"
  },
  {
    "n": "ADFE Français du Monde USA",
    "u": "https://adfe.org",
    "c": "Culture",
    "d": "Défense droits Français à l’étranger",
    "date": "2025"
  },
  {
    "n": "UFE Union des Français de l’Étranger",
    "u": "https://ufe.org",
    "c": "Culture",
    "d": "Réseau mondial expatriés français",
    "date": "2025"
  },
  {
    "n": "Français du Monde",
    "u": "https://francaisdumonde.org",
    "c": "Culture",
    "d": "Association progressiste expatriés",
    "date": "2025"
  },
  {
    "n": "En Marche à l’Étranger",
    "u": "https://en-marche.fr",
    "c": "Culture",
    "d": "Mouvement politique expatriés",
    "date": "2025"
  },
  {
    "n": "Les Républicains à l’Étranger",
    "u": "https://republicains-etranger.fr",
    "c": "Culture",
    "d": "Section expatriés LR",
    "date": "2025"
  },
  {
    "n": "Rassemblement National Expatriés",
    "u": "https://rn-expatries.fr",
    "c": "Culture",
    "d": "Section expatriés RN",
    "date": "2025"
  },
  {
    "n": "Parti Socialiste Expatriés",
    "u": "https://ps-expatries.fr",
    "c": "Culture",
    "d": "Fédération PS à l’étranger",
    "date": "2025"
  },
  {
    "n": "Europe Écologie Les Verts Expatriés",
    "u": "https://eelv-expatries.fr",
    "c": "Culture",
    "d": "Section expatriés EELV",
    "date": "2025"
  },
  {
    "n": "Association Démocrate des Français à l’Étranger",
    "u": "https://adfe.org",
    "c": "Culture",
    "d": "ADFE sections locales",
    "date": "2025"
  },
  {
    "n": "French American Voting",
    "u": "https://frenchamericanvoting.org",
    "c": "Culture",
    "d": "Inscription listes électorales",
    "date": "2025"
  },
  {
    "n": "Consulat Mobile",
    "u": "https://consulat.gouv.fr",
    "c": "Gouvernement",
    "d": "Tournées consulaires villes USA",
    "date": "2025"
  },
  {
    "n": "Permanence Consulaire",
    "u": "https://consulfrance.org",
    "c": "Gouvernement",
    "d": "Rendez-vous hors grandes villes",
    "date": "2025"
  },
  {
    "n": "French Healthcare",
    "u": "https://frenchhealthcare.fr",
    "c": "Santé",
    "d": "Promotion expertise santé française",
    "date": "2025"
  },
  {
    "n": "French Tech Health",
    "u": "https://frenchtech.health",
    "c": "Technologie",
    "d": "Startups santé françaises",
    "date": "2025"
  },
  {
    "n": "French BioBeach",
    "u": "https://frenchbiobeach.org",
    "c": "Technologie",
    "d": "Cluster biotech San Diego",
    "date": "2025"
  },
  {
    "n": "French Aerospace Network",
    "u": "https://frenchaerospace.org",
    "c": "Technologie",
    "d": "Industrie aéronautique française USA",
    "date": "2025"
  },
  {
    "n": "French Nuclear Network",
    "u": "https://frenchnuclear.org",
    "c": "Technologie",
    "d": "Filière nucléaire française",
    "date": "2025"
  },
  {
    "n": "French Fab USA",
    "u": "https://frenchfab.us",
    "c": "Commerce",
    "d": "Marque industrie française",
    "date": "2025"
  },
  {
    "n": "French Luxury Network",
    "u": "https://frenchluxury.us",
    "c": "Commerce",
    "d": "Réseau luxe français USA",
    "date": "2025"
  },
  {
    "n": "Comité Colbert USA",
    "u": "https://comitecolbert.com",
    "c": "Commerce",
    "d": "Association luxe français",
    "date": "2025"
  },
  {
    "n": "French Gourmet Network",
    "u": "https://frenchgourmet.us",
    "c": "Commerce",
    "d": "Réseau gastronomie française",
    "date": "2025"
  },
  {
    "n": "Relais & Châteaux USA",
    "u": "https://relaischateaux.com",
    "c": "Tourisme",
    "d": "Hôtels et restaurants français",
    "date": "2025"
  },
  {
    "n": "Atout France USA",
    "u": "https://atout-france.fr",
    "c": "Tourisme",
    "d": "Promotion tourisme France",
    "date": "2025"
  },
  {
    "n": "French Affairs",
    "u": "https://frenchaffairs.com",
    "c": "Culture",
    "d": "Événements français New York",
    "date": "2025"
  },
  {
    "n": "Bastille Day NYC",
    "u": "https://bastilledaynyc.com",
    "c": "Culture",
    "d": "Plus grande fête française hors France",
    "date": "2025"
  },
  {
    "n": "Taste of France NYC",
    "u": "https://tasteoffrance.com",
    "c": "Culture",
    "d": "Salon gastronomie française",
    "date": "2025"
  },
  {
    "n": "French Restaurant Week",
    "u": "https://frenchrestaurantweek.com",
    "c": "Culture",
    "d": "Semaine restaurants français",
    "date": "2025"
  },
  {
    "n": "French Cheese Week",
    "u": "https://frencheeseweek.com",
    "c": "Culture",
    "d": "Semaine des fromages français",
    "date": "2025"
  },
  {
    "n": "French Cinema Week",
    "u": "https://rendezvouswithfrenchcinema.com",
    "c": "Culture",
    "d": "Festival cinéma français",
    "date": "2025"
  },
  {
    "n": "Colcoa French Film Festival",
    "u": "https://colcoa.org",
    "c": "Culture",
    "d": "Plus grand festival cinéma français USA",
    "date": "2025"
  },
  {
    "n": "French Tech Days",
    "u": "https://frenchtechdays.com",
    "c": "Technologie",
    "d": "Événements tech française",
    "date": "2025"
  },
  {
    "n": "VivaTech Tour USA",
    "u": "https://vivatech.com",
    "c": "Technologie",
    "d": "Roadshow VivaTech",
    "date": "2025"
  },
  {
    "n": "French American Piano Academy",
    "u": "https://fapa.org",
    "c": "Éducation",
    "d": "Académie piano française",
    "date": "2025"
  },
  {
    "n": "French Violin School",
    "u": "https://frenchviolinschool.org",
    "c": "Éducation",
    "d": "École violon méthode française",
    "date": "2025"
  },
  {
    "n": "École de Ballet Français",
    "u": "https://ecoleballetfrancais.org",
    "c": "Éducation",
    "d": "Cours ballet classique français",
    "date": "2025"
  },
  {
    "n": "French Fashion Academy",
    "u": "https://frenchfashionacademy.org",
    "c": "Éducation",
    "d": "Formation mode française",
    "date": "2025"
  },
  {
    "n": "French Pastry School",
    "u": "https://frenchpastryschool.com",
    "c": "Éducation",
    "d": "École pâtisserie française Chicago",
    "date": "2025"
  },
  {
    "n": "International Culinary Center",
    "u": "https://internationalculinarycenter.com",
    "c": "Éducation",
    "d": "Formation cuisine française",
    "date": "2025"
  },
  {
    "n": "Le Cordon Bleu USA",
    "u": "https://cordonbleu.edu",
    "c": "Éducation",
    "d": "Écoles culinaires françaises",
    "date": "2025"
  },
  {
    "n": "French Wine Scholar",
    "u": "https://frenchwinescholar.org",
    "c": "Éducation",
    "d": "Certification vins français",
    "date": "2025"
  },
  {
    "n": "French Cheese Master",
    "u": "https://frenchcheesemaster.org",
    "c": "Éducation",
    "d": "Formation fromages français",
    "date": "2025"
  },
  {
    "n": "Sommelier Society of America",
    "u": "https://sommeliersociety.org",
    "c": "Éducation",
    "d": "Formation sommellerie française",
    "date": "2025"
  },
  {
    "n": "French American Doctoral Exchange",
    "u": "https://fadex.org",
    "c": "Éducation",
    "d": "Programme échange doctorants",
    "date": "2025"
  },
  {
    "n": "Chateaubriand Fellowship",
    "u": "https://chateaubriand-fellowship.org",
    "c": "Éducation",
    "d": "Bourses recherche France-USA",
    "date": "2025"
  },
  {
    "n": "Fulbright France",
    "u": "https://fulbright-france.org",
    "c": "Éducation",
    "d": "Programme échanges académiques",
    "date": "2025"
  },
  {
    "n": "French Embassy Higher Education",
    "u": "https://highereducation.franceintheus.org",
    "c": "Éducation",
    "d": "Service études supérieures",
    "date": "2025"
  },
  {
    "n": "French Dual Language Program",
    "u": "https://frenchduallanguage.org",
    "c": "Éducation",
    "d": "Réseau écoles publiques bilingues",
    "date": "2025"
  },
  {
    "n": "French Heritage Language Program",
    "u": "https://fhlp.org",
    "c": "Éducation",
    "d": "Français langue patrimoniale",
    "date": "2025"
  },
  {
    "n": "American Association of Teachers of French",
    "u": "https://frenchteachers.org",
    "c": "Éducation",
    "d": "Association professeurs français",
    "date": "2025"
  },
  {
    "n": "French for the Future",
    "u": "https://french-future.org",
    "c": "Éducation",
    "d": "Promotion français jeunes",
    "date": "2025"
  },
  {
    "n": "Concours National de Français",
    "u": "https://grandconcours.org",
    "c": "Éducation",
    "d": "Grand Concours AATF",
    "date": "2025"
  },
  {
    "n": "French Honor Society",
    "u": "https://frenchhonorsociety.org",
    "c": "Éducation",
    "d": "Société d’honneur français lycées",
    "date": "2025"
  },
  {
    "n": "Pi Delta Phi",
    "u": "https://pideltaphi.org",
    "c": "Éducation",
    "d": "Société d’honneur français universités",
    "date": "2025"
  },
  {
    "n": "Delta Phi Alpha",
    "u": "https://deltaphialpha.org",
    "c": "Éducation",
    "d": "Société d’honneur langues étrangères",
    "date": "2025"
  },
  {
    "n": "French Club USA",
    "u": "https://frenchclubusa.org",
    "c": "Culture",
    "d": "Réseau clubs français lycées/collèges",
    "date": "2025"
  },
  {
    "n": "French Week USA",
    "u": "https://frenchweek.us",
    "c": "Culture",
    "d": "Semaine de la langue française",
    "date": "2025"
  },
  {
    "n": "Journée de la Francophonie",
    "u": "https://francophonie.us",
    "c": "Culture",
    "d": "20 mars célébrations",
    "date": "2025"
  },
  {
    "n": "Mois de la Francophonie",
    "u": "https://moisfrancophonie.org",
    "c": "Culture",
    "d": "Mars événements francophones",
    "date": "2025"
  },
  {
    "n": "Dictée de Pivot USA",
    "u": "https://dicteepivot.us",
    "c": "Culture",
    "d": "Concours orthographe française",
    "date": "2025"
  },
  {
    "n": "Certamen Français",
    "u": "https://certamenfrancais.org",
    "c": "Éducation",
    "d": "Compétition culture française",
    "date": "2025"
  },
  {
    "n": "French Debating Association",
    "u": "https://frenchdebating.org",
    "c": "Éducation",
    "d": "Compétitions débat français",
    "date": "2025"
  },
  {
    "n": "French Theater Competition",
    "u": "https://frenchtheater.us",
    "c": "Culture",
    "d": "Concours théâtre français",
    "date": "2025"
  },
  {
    "n": "French Song Contest",
    "u": "https://frenchsong.us",
    "c": "Culture",
    "d": "Concours chanson française",
    "date": "2025"
  },
  {
    "n": "French Cooking Contest",
    "u": "https://frenchcooking.us",
    "c": "Culture",
    "d": "Concours cuisine française",
    "date": "2025"
  },
  {
    "n": "French Tech Visa",
    "u": "https://frenchtechvisa.org",
    "c": "Technologie",
    "d": "Visa accéléré talents tech",
    "date": "2025"
  },
  {
    "n": "Talent Passport",
    "u": "https://talentpassport.fr",
    "c": "Travail",
    "d": "Visa 4 ans talents français",
    "date": "2025"
  },
  {
    "n": "French American Climate Talk",
    "u": "https://factalks.org",
    "c": "Écologie",
    "d": "Dialogue climat franco-américain",
    "date": "2025"
  },
  {
    "n": "French American Innovation Day",
    "u": "https://faid.us",
    "c": "Technologie",
    "d": "Journée innovation franco-américaine",
    "date": "2025"
  },
  {
    "n": "French American Cybersecurity",
    "u": "https://facyber.org",
    "c": "Technologie",
    "d": "Coopération cybersécurité",
    "date": "2025"
  },
  {
    "n": "French American Space Forum",
    "u": "https://faspaceforum.org",
    "c": "Technologie",
    "d": "Coopération spatiale",
    "date": "2025"
  },
  {
    "n": "French American AI Summit",
    "u": "https://faisummit.org",
    "c": "Technologie",
    "d": "Sommet intelligence artificielle",
    "date": "2025"
  },
  {
    "n": "French American Quantum Workshop",
    "u": "https://faquantum.org",
    "c": "Technologie",
    "d": "Recherche quantique",
    "date": "2025"
  },
  {
    "n": "French American Biotech Forum",
    "u": "https://fabioforum.org",
    "c": "Technologie",
    "d": "Biotechnologies franco-américaines",
    "date": "2025"
  },
  {
    "n": "French American Green Tech",
    "u": "https://fagreentech.org",
    "c": "Écologie",
    "d": "Technologies vertes",
    "date": "2025"
  },
  {
    "n": "French American Luxury Summit",
    "u": "https://faluxurysummit.org",
    "c": "Commerce",
    "d": "Sommet luxe franco-américain",
    "date": "2025"
  },
  {
    "n": "French American Fashion Week",
    "u": "https://fafashionweek.com",
    "c": "Mode",
    "d": "Semaine mode française",
    "date": "2025"
  },
  {
    "n": "French Touch Dreamin",
    "u": "https://frenchtouchdreamin.com",
    "c": "Technologie",
    "d": "Événement Salesforce français",
    "date": "2025"
  },
  {
    "n": "French American Rugby Cup",
    "u": "https://farugbycup.com",
    "c": "Sport",
    "d": "Coupe rugby franco-américaine",
    "date": "2025"
  },
  {
    "n": "French American Soccer Cup",
    "u": "https://fasoccercup.com",
    "c": "Sport",
    "d": "Tournoi football français",
    "date": "2025"
  },
  {
    "n": "French American Tennis Cup",
    "u": "https://fatenniscup.com",
    "c": "Sport",
    "d": "Tournoi tennis français",
    "date": "2025"
  },
  {
    "n": "French American Golf Trophy",
    "u": "https://fagolftrophy.com",
    "c": "Sport",
    "d": "Tournoi golf franco-américain",
    "date": "2025"
  },
  {
    "n": "French American Ski Cup",
    "u": "https://faskicup.com",
    "c": "Sport",
    "d": "Compétition ski française USA",
    "date": "2025"
  },
  {
    "n": "French American Petanque",
    "u": "https://fapetanque.org",
    "c": "Sport",
    "d": "Tournois pétanque",
    "date": "2025"
  },
  {
    "n": "French American Cycling",
    "u": "https://facycling.org",
    "c": "Sport",
    "d": "Club cyclisme français",
    "date": "2025"
  },
  {
    "n": "French American Running Club",
    "u": "https://farunning.org",
    "c": "Sport",
    "d": "Club course à pied",
    "date": "2025"
  },
  {
    "n": "French American Yacht Club",
    "u": "https://fayachtclub.org",
    "c": "Sport",
    "d": "Club voile français",
    "date": "2025"
  },
  {
    "n": "French American Sailing",
    "u": "https://fasailing.org",
    "c": "Sport",
    "d": "École voile française",
    "date": "2025"
  },
  {
    "n": "French American Diving",
    "u": "https://fadiving.org",
    "c": "Sport",
    "d": "Club plongée français",
    "date": "2025"
  },
  {
    "n": "French American Hiking",
    "u": "https://fahiking.org",
    "c": "Sport",
    "d": "Randonnées françaises",
    "date": "2025"
  },
  {
    "n": "French American Wine Society",
    "u": "https://faws.org",
    "c": "Culture",
    "d": "Dégustations vins français",
    "date": "2025"
  },
  {
    "n": "French American Cheese Society",
    "u": "https://facheesesociety.org",
    "c": "Culture",
    "d": "Association fromages français",
    "date": "2025"
  },
  {
    "n": "French American Bakery",
    "u": "https://fabakery.org",
    "c": "Commerce",
    "d": "Réseau boulangeries françaises",
    "date": "2025"
  },
  {
    "n": "French American Patisserie",
    "u": "https://fapatisserie.org",
    "c": "Commerce",
    "d": "Réseau pâtisseries françaises",
    "date": "2025"
  },
  {
    "n": "French American Brasserie",
    "u": "https://fabrasserie.org",
    "c": "Commerce",
    "d": "Réseau brasseries françaises",
    "date": "2025"
  },
  {
    "n": "French American Bistro",
    "u": "https://fabistro.org",
    "c": "Commerce",
    "d": "Réseau bistrots français",
    "date": "2025"
  },
  {
    "n": "French American Creperie",
    "u": "https://facreperie.org",
    "c": "Commerce",
    "d": "Réseau crêperies",
    "date": "2025"
  },
  {
    "n": "French American Macaron",
    "u": "https://famacaron.org",
    "c": "Commerce",
    "d": "Réseau macarons français",
    "date": "2025"
  },
  {
    "n": "French American Chocolatier",
    "u": "https://fachocolatier.org",
    "c": "Commerce",
    "d": "Réseau chocolatiers français",
    "date": "2025"
  },
  {
    "n": "French American Caviar",
    "u": "https://facaviar.org",
    "c": "Commerce",
    "d": "Réseau caviar français",
    "date": "2025"
  },
  {
    "n": "French American Foie Gras",
    "u": "https://fafoiegras.org",
    "c": "Commerce",
    "d": "Réseau foie gras français",
    "date": "2025"
  },
  {
    "n": "French American Truffle",
    "u": "https://fatruffe.org",
    "c": "Commerce",
    "d": "Réseau truffes françaises",
    "date": "2025"
  },
  {
    "n": "French American Escargot",
    "u": "https://faescargot.org",
    "c": "Commerce",
    "d": "Réseau escargots français",
    "date": "2025"
  },
  {
    "n": "French American Oyster",
    "u": "https://faoyster.org",
    "c": "Commerce",
    "d": "Réseau huîtres françaises",
    "date": "2025"
  },
  {
    "n": "French American Mussel",
    "u": "https://famussel.org",
    "c": "Commerce",
    "d": "Réseau moules françaises",
    "date": "2025"
  },
  {
    "n": "French American Frog Legs",
    "u": "https://fafroglegs.org",
    "c": "Commerce",
    "d": "Réseau cuisses de grenouille",
    "date": "2025"
  },
  {
    "n": "French American Duck",
    "u": "https://faduck.org",
    "c": "Commerce",
    "d": "Réseau canard français",
    "date": "2025"
  },
  {
    "n": "French American Charcuterie",
    "u": "https://facharcuterie.org",
    "c": "Commerce",
    "d": "Réseau charcuteries françaises",
    "date": "2025"
  },
  {
    "n": "French American Terrine",
    "u": "https://faterrine.org",
    "c": "Commerce",
    "d": "Réseau terrines françaises",
    "date": "2025"
  },
  {
    "n": "French American Pâté",
    "u": "https://fapate.org",
    "c": "Commerce",
    "d": "Réseau pâtés français",
    "date": "2025"
  },
  {
    "n": "French American Rillettes",
    "u": "https://farillettes.org",
    "c": "Commerce",
    "d": "Réseau rillettes françaises",
    "date": "2025"
  },
  {
    "n": "French American Confit",
    "u": "https://faconfit.org",
    "c": "Commerce",
    "d": "Réseau confits français",
    "date": "2025"
  },
  {
    "n": "French American Cassoulet",
    "u": "https://facassoulet.org",
    "c": "Commerce",
    "d": "Réseau cassoulets français",
    "date": "2025"
  },
  {
    "n": "French American Ratatouille",
    "u": "https://faratatouille.org",
    "c": "Commerce",
    "d": "Réseau ratatouilles françaises",
    "date": "2025"
  },
  {
    "n": "French American Bouillabaisse",
    "u": "https://fabouillabaisse.org",
    "c": "Commerce",
    "d": "Réseau bouillabaisses",
    "date": "2025"
  },
  {
    "n": "French American Coq au Vin",
    "u": "https://facoqauvin.org",
    "c": "Commerce",
    "d": "Réseau coq au vin",
    "date": "2025"
  },
  {
    "n": "French American Boeuf Bourguignon",
    "u": "https://faboeufbourguignon.org",
    "c": "Commerce",
    "d": "Réseau bœuf bourguignon",
    "date": "2025"
  },
  {
    "n": "French American Crêpe",
    "u": "https://facrepe.org",
    "c": "Commerce",
    "d": "Réseau crêpes françaises",
    "date": "2025"
  },
  {
    "n": "French American Galette",
    "u": "https://fagalette.org",
    "c": "Commerce",
    "d": "Réseau galettes bretonnes",
    "date": "2025"
  },
  {
    "n": "French American Baguette",
    "u": "https://fabaguette.org",
    "c": "Commerce",
    "d": "Réseau baguettes tradition",
    "date": "2025"
  },
  {
    "n": "French American Croissant",
    "u": "https://facroissant.org",
    "c": "Commerce",
    "d": "Réseau croissants pur beurre",
    "date": "2025"
  },
  {
    "n": "French American Pain au Chocolat",
    "u": "https://fapainauchocolat.org",
    "c": "Commerce",
    "d": "Réseau pains au chocolat",
    "date": "2025"
  },
  {
    "n": "French American Éclair",
    "u": "https://faeclair.org",
    "c": "Commerce",
    "d": "Réseau éclairs français",
    "date": "2025"
  },
  {
    "n": "French American Mille-Feuille",
    "u": "https://famillefeuille.org",
    "c": "Commerce",
    "d": "Réseau mille-feuilles",
    "date": "2025"
  },
  {
    "n": "French American Tarte Tatin",
    "u": "https://fatartetatin.org",
    "c": "Commerce",
    "d": "Réseau tartes Tatin",
    "date": "2025"
  },
  {
    "n": "French American Crème Brûlée",
    "u": "https://facremebrulee.org",
    "c": "Commerce",
    "d": "Réseau crèmes brûlées",
    "date": "2025"
  },
  {
    "n": "French American Profiterole",
    "u": "https://faprofiterole.org",
    "c": "Commerce",
    "d": "Réseau profiteroles",
    "date": "2025"
  },
  {
    "n": "French American Madeleine",
    "u": "https://famadeleine.org",
    "c": "Commerce",
    "d": "Réseau madeleines de Commercy",
    "date": "2025"
  },
  {
    "n": "French American Canelé",
    "u": "https://facanele.org",
    "c": "Commerce",
    "d": "Réseau canelés bordelais",
    "date": "2025"
  },
  {
    "n": "French American Financier",
    "u": "https://fafinancier.org",
    "c": "Commerce",
    "d": "Réseau financiers",
    "date": "2025"
  },
  {
    "n": "French American Opéra",
    "u": "https://faopera.org",
    "c": "Commerce",
    "d": "Réseau gâteaux Opéra",
    "date": "2025"
  },
  {
    "n": "French American Saint-Honoré",
    "u": "https://fasainthonore.org",
    "c": "Commerce",
    "d": "Réseau Saint-Honoré",
    "date": "2025"
  },
  {
    "n": "French American Paris-Brest",
    "u": "https://faparisbrest.org",
    "c": "Commerce",
    "d": "Réseau Paris-Brest",
    "date": "2025"
  },
  {
    "n": "French American Religieuse",
    "u": "https://fareligieuse.org",
    "c": "Commerce",
    "d": "Réseau religieuses",
    "date": "2025"
  },
  {
    "n": "French American Mont-Blanc",
    "u": "https://famontblanc.org",
    "c": "Commerce",
    "d": "Réseau Mont-Blanc",
    "date": "2025"
  },
  {
    "n": "French American Baba au Rhum",
    "u": "https://fababaaurhum.org",
    "c": "Commerce",
    "d": "Réseau babas au rhum",
    "date": "2025"
  },
  {
    "n": "French American Savarin",
    "u": "https://fasavarin.org",
    "c": "Commerce",
    "d": "Réseau savarins",
    "date": "2025"
  },
  {
    "n": "French American Charlotte",
    "u": "https://facharlotte.org",
    "c": "Commerce",
    "d": "Réseau charlottes",
    "date": "2025"
  },
  {
    "n": "French American Mousse au Chocolat",
    "u": "https://famousseauchocolat.org",
    "c": "Commerce",
    "d": "Réseau mousses au chocolat",
    "date": "2025"
  },
  {
    "n": "French American Soufflé",
    "u": "https://fasouffle.org",
    "c": "Commerce",
    "d": "Réseau soufflés",
    "date": "2025"
  },
  {
    "n": "French American Crêpe Suzette",
    "u": "https://facrepesuzette.org",
    "c": "Commerce",
    "d": "Réseau crêpes Suzette",
    "date": "2025"
  },
  {
    "n": "French American Profiteroles au Chocolat",
    "u": "https://faprofiteroleschocolat.org",
    "c": "Commerce",
    "d": "Réseau profiteroles chocolat",
    "date": "2025"
  },
  {
    "n": "French American Île Flottante",
    "u": "https://faileflottante.org",
    "c": "Commerce",
    "d": "Réseau îles flottantes",
    "date": "2025"
  },
  {
    "n": "French American Clafoutis",
    "u": "https://faclafoutis.org",
    "c": "Commerce",
    "d": "Réseau clafoutis",
    "date": "2025"
  },
  {
    "n": "French American Far Breton",
    "u": "https://fafarbreton.org",
    "c": "Commerce",
    "d": "Réseau far breton",
    "date": "2025"
  },
  {
    "n": "French American Kouign-Amann",
    "u": "https://fakouignamann.org",
    "c": "Commerce",
    "d": "Réseau kouign-amann",
    "date": "2025"
  },
  {
    "n": "French American Gâteau Basque",
    "u": "https://fagateaubasque.org",
    "c": "Commerce",
    "d": "Réseau gâteau basque",
    "date": "2025"
  },
  {
    "n": "French American Tropézienne",
    "u": "https://fatropezienne.org",
    "c": "Commerce",
    "d": "Réseau tarte tropézienne",
    "date": "2025"
  },
  {
    "n": "French American Calisson",
    "u": "https://facalisson.org",
    "c": "Commerce",
    "d": "Réseau calissons d’Aix",
    "date": "2025"
  },
  {
    "n": "French American Nougat de Montélimar",
    "u": "https://fanougatmontelimar.org",
    "c": "Commerce",
    "d": "Réseau nougat Montélimar",
    "date": "2025"
  },
  {
    "n": "French American Berlingot",
    "u": "https://faberlingot.org",
    "c": "Commerce",
    "d": "Réseau berlingots",
    "date": "2025"
  },
  {
    "n": "French American Dragée",
    "u": "https://fadragee.org",
    "c": "Commerce",
    "d": "Réseau dragées Verdun",
    "date": "2025"
  },
  {
    "n": "French American Violette de Toulouse",
    "u": "https://faviolettetoulouse.org",
    "c": "Commerce",
    "d": "Réseau violettes Toulouse",
    "date": "2025"
  },
  {
    "n": "French American Anis de Flavigny",
    "u": "https://faanisflavigny.org",
    "c": "Commerce",
    "d": "Réseau anis Flavigny",
    "date": "2025"
  },
  {
    "n": "French American Bergamote de Nancy",
    "u": "https://fabergamotenancy.org",
    "c": "Commerce",
    "d": "Réseau bergamotes Nancy",
    "date": "2025"
  },
  {
    "n": "French American Pastis",
    "u": "https://fapastis.org",
    "c": "Commerce",
    "d": "Réseau pastis Marseille",
    "date": "2025"
  },
  {
    "n": "French American Absinthe",
    "u": "https://faabsinthe.org",
    "c": "Commerce",
    "d": "Réseau absinthe Pontarlier",
    "date": "2025"
  },
  {
    "n": "French American Chartreuse",
    "u": "https://fachartreuse.org",
    "c": "Commerce",
    "d": "Réseau liqueur Chartreuse",
    "date": "2025"
  },
  {
    "n": "French American Bénédictine",
    "u": "https://fabenedictine.org",
    "c": "Commerce",
    "d": "Réseau Bénédictine Fécamp",
    "date": "2025"
  },
  {
    "n": "French American Armagnac",
    "u": "https://faarmagnac.org",
    "c": "Commerce",
    "d": "Réseau armagnac Gers",
    "date": "2025"
  },
  {
    "n": "French American Cognac",
    "u": "https://facognac.org",
    "c": "Commerce",
    "d": "Réseau cognac Charente",
    "date": "2025"
  },
  {
    "n": "French American Champagne",
    "u": "https://fachampagne.org",
    "c": "Commerce",
    "d": "Réseau maisons champagne",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux",
    "u": "https://fabordeaux.org",
    "c": "Commerce",
    "d": "Réseau grands crus Bordeaux",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne",
    "u": "https://fabourgogne.org",
    "c": "Commerce",
    "d": "Réseau grands crus Bourgogne",
    "date": "2025"
  },
  {
    "n": "French American Rhône",
    "u": "https://farhone.org",
    "c": "Commerce",
    "d": "Réseau Côtes-du-Rhône",
    "date": "2025"
  },
  {
    "n": "French American Provence Rosé",
    "u": "https://faprovencerose.org",
    "c": "Commerce",
    "d": "Réseau rosés Provence",
    "date": "2025"
  },
  {
    "n": "French American Alsace",
    "u": "https://faalsace.org",
    "c": "Commerce",
    "d": "Réseau vins Alsace",
    "date": "2025"
  },
  {
    "n": "French American Loire",
    "u": "https://faloire.org",
    "c": "Commerce",
    "d": "Réseau vins vallée Loire",
    "date": "2025"
  },
  {
    "n": "French American Languedoc",
    "u": "https://falanguedoc.org",
    "c": "Commerce",
    "d": "Réseau vins Languedoc",
    "date": "2025"
  },
  {
    "n": "French American Sancerre",
    "u": "https://fasancerre.org",
    "c": "Commerce",
    "d": "Réseau Sancerre Pouilly",
    "date": "2025"
  },
  {
    "n": "French American Chablis",
    "u": "https://fachablis.org",
    "c": "Commerce",
    "d": "Réseau Chablis",
    "date": "2025"
  },
  {
    "n": "French American Sauternes",
    "u": "https://fasauternes.org",
    "c": "Commerce",
    "d": "Réseau vins liquoreux",
    "date": "2025"
  },
  {
    "n": "French American Crémant",
    "u": "https://facremant.org",
    "c": "Commerce",
    "d": "Réseau crémants France",
    "date": "2025"
  },
  {
    "n": "French American Cidre",
    "u": "https://facidre.org",
    "c": "Commerce",
    "d": "Réseau cidres Normandie Bretagne",
    "date": "2025"
  },
  {
    "n": "French American Calvados",
    "u": "https://facalvados.org",
    "c": "Commerce",
    "d": "Réseau calvados Normandie",
    "date": "2025"
  },
  {
    "n": "French American Poiré",
    "u": "https://fapoire.org",
    "c": "Commerce",
    "d": "Réseau poiré Normandie",
    "date": "2025"
  },
  {
    "n": "French American Pineau des Charentes",
    "u": "https://fapineau.org",
    "c": "Commerce",
    "d": "Réseau pineau Charentes",
    "date": "2025"
  },
  {
    "n": "French American Floc de Gascogne",
    "u": "https://fafloc.org",
    "c": "Commerce",
    "d": "Réseau floc Gascogne",
    "date": "2025"
  },
  {
    "n": "French American Picon",
    "u": "https://fapicon.org",
    "c": "Commerce",
    "d": "Réseau Picon",
    "date": "2025"
  },
  {
    "n": "French American Suze",
    "u": "https://fasuze.org",
    "c": "Commerce",
    "d": "Réseau Suze",
    "date": "2025"
  },
  {
    "n": "French American Gentiane",
    "u": "https://fagentiane.org",
    "c": "Commerce",
    "d": "Réseau liqueurs gentiane",
    "date": "2025"
  },
  {
    "n": "French American Kir",
    "u": "https://fakir.org",
    "c": "Commerce",
    "d": "Réseau kir Bourgogne",
    "date": "2025"
  },
  {
    "n": "French American Kir Royal",
    "u": "https://fakirroyal.org",
    "c": "Commerce",
    "d": "Réseau kir royal",
    "date": "2025"
  },
  {
    "n": "French American Pastis 51",
    "u": "https://fapastis51.org",
    "c": "Commerce",
    "d": "Réseau Pastis 51",
    "date": "2025"
  },
  {
    "n": "French American Ricard",
    "u": "https://faricard.org",
    "c": "Commerce",
    "d": "Réseau Ricard",
    "date": "2025"
  },
  {
    "n": "French American Pernod",
    "u": "https://fapernod.org",
    "c": "Commerce",
    "d": "Réseau Pernod",
    "date": "2025"
  },
  {
    "n": "French American Lillet",
    "u": "https://falillet.org",
    "c": "Commerce",
    "d": "Réseau Lillet",
    "date": "2025"
  },
  {
    "n": "French American Dubonnet",
    "u": "https://fadubonnet.org",
    "c": "Commerce",
    "d": "Réseau Dubonnet",
    "date": "2025"
  },
  {
    "n": "French American Noilly Prat",
    "u": "https://fanoillyprat.org",
    "c": "Commerce",
    "d": "Réseau Noilly Prat",
    "date": "2025"
  },
  {
    "n": "French American Saint-Raphaël",
    "u": "https://fasaintraphael.org",
    "c": "Commerce",
    "d": "Réseau Saint-Raphaël",
    "date": "2025"
  },
  {
    "n": "French American Byrrh",
    "u": "https://fabyrhh.org",
    "c": "Commerce",
    "d": "Réseau Byrrh",
    "date": "2025"
  },
  {
    "n": "French American Cointreau",
    "u": "https://facointreau.org",
    "c": "Commerce",
    "d": "Réseau Cointreau",
    "date": "2025"
  },
  {
    "n": "French American Grand Marnier",
    "u": "https://fagrandmarnier.org",
    "c": "Commerce",
    "d": "Réseau Grand Marnier",
    "date": "2025"
  },
  {
    "n": "French American Armagnac Castarède",
    "u": "https://castarede.fr",
    "c": "Commerce",
    "d": "Plus ancienne maison armagnac",
    "date": "2025"
  },
  {
    "n": "French American Cognac Hennessy",
    "u": "https://hennessy.com",
    "c": "Commerce",
    "d": "Maison Hennessy",
    "date": "2025"
  },
  {
    "n": "French American Cognac Rémy Martin",
    "u": "https://remymartin.com",
    "c": "Commerce",
    "d": "Maison Rémy Martin",
    "date": "2025"
  },
  {
    "n": "French American Cognac Martell",
    "u": "https://martell.com",
    "c": "Commerce",
    "d": "Maison Martell",
    "date": "2025"
  },
  {
    "n": "French American Cognac Courvoisier",
    "u": "https://courvoisier.com",
    "c": "Commerce",
    "d": "Maison Courvoisier",
    "date": "2025"
  },
  {
    "n": "French American Champagne Moët & Chandon",
    "u": "https://moet.com",
    "c": "Commerce",
    "d": "Maison Moët & Chandon",
    "date": "2025"
  },
  {
    "n": "French American Champagne Veuve Clicquot",
    "u": "https://veuveclicquot.com",
    "c": "Commerce",
    "d": "Maison Veuve Clicquot",
    "date": "2025"
  },
  {
    "n": "French American Champagne Dom Pérignon",
    "u": "https://domperignon.com",
    "c": "Commerce",
    "d": "Cuvée Dom Pérignon",
    "date": "2025"
  },
  {
    "n": "French American Champagne Krug",
    "u": "https://krug.com",
    "c": "Commerce",
    "d": "Maison Krug",
    "date": "2025"
  },
  {
    "n": "French American Champagne Ruinart",
    "u": "https://ruinart.com",
    "c": "Commerce",
    "d": "Plus ancienne maison champagne",
    "date": "2025"
  },
  {
    "n": "French American Champagne Bollinger",
    "u": "https://champagne-bollinger.com",
    "c": "Commerce",
    "d": "Maison Bollinger",
    "date": "2025"
  },
  {
    "n": "French American Champagne Laurent-Perrier",
    "u": "https://laurent-perrier.com",
    "c": "Commerce",
    "d": "Maison Laurent-Perrier",
    "date": "2025"
  },
  {
    "n": "French American Champagne Louis Roederer",
    "u": "https://louis-roederer.com",
    "c": "Commerce",
    "d": "Maison Louis Roederer Cristal",
    "date": "2025"
  },
  {
    "n": "French American Champagne Taittinger",
    "u": "https://taittinger.com",
    "c": "Commerce",
    "d": "Maison Taittinger",
    "date": "2025"
  },
  {
    "n": "French American Champagne Pommery",
    "u": "https://pommery.com",
    "c": "Commerce",
    "d": "Maison Pommery",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Margaux",
    "u": "https://chateau-margaux.com",
    "c": "Commerce",
    "d": "Premier cru classé Margaux",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Lafite Rothschild",
    "u": "https://lafite.com",
    "c": "Commerce",
    "d": "Premier cru classé Pauillac",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Latour",
    "u": "https://chateau-latour.com",
    "c": "Commerce",
    "d": "Premier cru classé Pauillac",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Haut-Brion",
    "u": "https://haut-brion.com",
    "c": "Commerce",
    "d": "Premier cru classé Pessac-Léognan",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Mouton Rothschild",
    "u": "https://chateau-mouton-rothschild.com",
    "c": "Commerce",
    "d": "Premier cru classé Pauillac",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Petrus",
    "u": "https://petrus.com",
    "c": "Commerce",
    "d": "Légende Pomerol",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Cheval Blanc",
    "u": "https://chateau-cheval-blanc.com",
    "c": "Commerce",
    "d": "Premier cru classé A Saint-Émilion",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Ausone",
    "u": "https://chateau-ausone.fr",
    "c": "Commerce",
    "d": "Premier cru classé A Saint-Émilion",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Angelus",
    "u": "https://angelus.com",
    "c": "Commerce",
    "d": "Premier cru classé A Saint-Émilion",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Château Yquem",
    "u": "https://yquem.fr",
    "c": "Commerce",
    "d": "Premier cru supérieur Sauternes",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Domaine Romanée-Conti",
    "u": "https://romanee-conti.fr",
    "c": "Commerce",
    "d": "Légende Bourgogne",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Domaine Leflaive",
    "u": "https://leflaive.fr",
    "c": "Commerce",
    "d": "Grand cru Puligny-Montrachet",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Domaine Coche-Dury",
    "u": "https://coche-dury.com",
    "c": "Commerce",
    "d": "Mythique Meursault",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Domaine Armand Rousseau",
    "u": "https://domaine-rousseau.com",
    "c": "Commerce",
    "d": "Geffrey-Chambertin",
    "date": "2025"
  },
  {
    "n": "French American Rhône Château de Beaucastel",
    "u": "https://beaucastel.com",
    "c": "Commerce",
    "d": "Châteauneuf-du-Pape",
    "date": "2025"
  },
  {
    "n": "French American Rhône Guigal",
    "u": "https://guigal.com",
    "c": "Commerce",
    "d": "Côte-Rôtie La Landonne",
    "date": "2025"
  },
  {
    "n": "French American Rhône Chapoutier",
    "u": "https://chapoutier.com",
    "c": "Commerce",
    "d": "Hermitage",
    "date": "2025"
  },
  {
    "n": "French American Provence Château d’Esclans",
    "u": "https://esclans.com",
    "c": "Commerce",
    "d": "Whispering Angel rosé",
    "date": "2025"
  },
  {
    "n": "French American Provence Domaines Ott",
    "u": "https://domaines-ott.com",
    "c": "Commerce",
    "d": "Rosés mythiques",
    "date": "2025"
  },
  {
    "n": "French American Provence Château Miraval",
    "u": "https://miraval.com",
    "c": "Commerce",
    "d": "Rosé Brad Pitt",
    "date": "2025"
  },
  {
    "n": "French American Alsace Trimbach",
    "u": "https://trimbach.fr",
    "c": "Commerce",
    "d": "Clos Sainte Hune",
    "date": "2025"
  },
  {
    "n": "French American Alsace Zind-Humbrecht",
    "u": "https://zindhumbrecht.fr",
    "c": "Commerce",
    "d": "Grands crus Alsace",
    "date": "2025"
  },
  {
    "n": "French American Loire Domaine Huet",
    "u": "https://domainehuet.com",
    "c": "Commerce",
    "d": "Vouvray",
    "date": "2025"
  },
  {
    "n": "French American Loire Clos Rougeard",
    "u": "https://closrougeard.com",
    "c": "Commerce",
    "d": "Mythique Saumur-Champigny",
    "date": "2025"
  },
  {
    "n": "French American Languedoc Mas de Daumas Gassac",
    "u": "https://daumas-gassac.com",
    "c": "Commerce",
    "d": "Grand cru Languedoc",
    "date": "2025"
  },
  {
    "n": "French American Languedoc Grange des Pères",
    "u": "https://grangedesperes.com",
    "c": "Commerce",
    "d": "Vin culte",
    "date": "2025"
  },
  {
    "n": "French American Sancerre Domaine Vacheron",
    "u": "https://domaine-vacheron.fr",
    "c": "Commerce",
    "d": "Sancerre bio",
    "date": "2025"
  },
  {
    "n": "French American Chablis Raveneau",
    "u": "https://raveneau.com",
    "c": "Commerce",
    "d": "Mythique Chablis",
    "date": "2025"
  },
  {
    "n": "French American Sauternes Château d’Yquem",
    "u": "https://yquem.fr",
    "c": "Commerce",
    "d": "Légende vins liquoreux",
    "date": "2025"
  },
  {
    "n": "French American Crémant de Loire Langlois-Château",
    "u": "https://langlois-chateau.fr",
    "c": "Commerce",
    "d": "Crémant prestige",
    "date": "2025"
  },
  {
    "n": "French American Crémant d’Alsace Wolfberger",
    "u": "https://wolfberger.com",
    "c": "Commerce",
    "d": "Crémant Alsace",
    "date": "2025"
  },
  {
    "n": "French American Cidre Dupont",
    "u": "https://calvados-dupont.com",
    "c": "Commerce",
    "d": "Cidre Normandie",
    "date": "2025"
  },
  {
    "n": "French American Calvados Boulard",
    "u": "https://calvados-boulard.com",
    "c": "Commerce",
    "d": "Calvados prestige",
    "date": "2025"
  },
  {
    "n": "French American Poiré Domaine Pacory",
    "u": "https://domaine-pacory.com",
    "c": "Commerce",
    "d": "Poiré Domfront",
    "date": "2025"
  },
  {
    "n": "French American Pineau François 1er",
    "u": "https://pineau-francois1er.com",
    "c": "Commerce",
    "d": "Pineau des Charentes",
    "date": "2025"
  },
  {
    "n": "French American Floc de Gascogne Château de Millet",
    "u": "https://chateau-millet.com",
    "c": "Commerce",
    "d": "Floc Gascogne",
    "date": "2025"
  },
  {
    "n": "French American Pastis Henri Bardouin",
    "u": "https://henri-bardouin.com",
    "c": "Commerce",
    "d": "Pastis artisanal",
    "date": "2025"
  },
  {
    "n": "French American Absinthe Bourgeois",
    "u": "https://absinthe-bourgeois.com",
    "c": "Commerce",
    "d": "Absinthe artisanale",
    "date": "2025"
  },
  {
    "n": "French American Chartreuse Verte",
    "u": "https://chartreuse.fr",
    "c": "Commerce",
    "d": "Liqueur Chartreuse",
    "date": "2025"
  },
  {
    "n": "French American Bénédictine DOM",
    "u": "https://benedictine.fr",
    "c": "Commerce",
    "d": "Liqueur Bénédictine",
    "date": "2025"
  },
  {
    "n": "French American Cointreau",
    "u": "https://cointreau.com",
    "c": "Commerce",
    "d": "Liqueur orange Cointreau",
    "date": "2025"
  },
  {
    "n": "French American Grand Marnier",
    "u": "https://grandmarnier.com",
    "c": "Commerce",
    "d": "Liqueur cognac orange",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Washington DC",
    "u": "https://washington.consulfrance.org",
    "c": "Gouvernement",
    "d": "Protection consulaire et démarches administratives en français pour Est USA",
    "date": "2025"
  },
  {
    "n": "Fédération des Alliances Françaises USA",
    "u": "https://www.afusa.org",
    "c": "Culture",
    "d": "Réseau national de 100+ chapitres pour langue et cultures francophones",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Atlanta",
    "u": "https://afatl.com",
    "c": "Culture",
    "d": "Promotion francophonie au Sud-Est",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Philadelphie",
    "u": "https://afphila.com",
    "c": "Culture",
    "d": "Cours immersifs en Pennsylvanie",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Austin",
    "u": "https://afaustin.org",
    "c": "Culture",
    "d": "Promotion tech et culture française au Texas",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Honolulu",
    "u": "https://afhawaii.org",
    "c": "Culture",
    "d": "Classes Hawaii",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Omaha",
    "u": "https://afomaha.org",
    "c": "Culture",
    "d": "Nebraska",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Orlando",
    "u": "https://aforlando.org",
    "c": "Culture",
    "d": "Floride centrale",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Albuquerque",
    "u": "https://afabq.org",
    "c": "Culture",
    "d": "Nouveau-Mexique",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Anchorage",
    "u": "https://afanchorage.org",
    "c": "Culture",
    "d": "Alaska",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Asheville",
    "u": "https://afasheville.org",
    "c": "Culture",
    "d": "Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'Oklahoma City",
    "u": "https://afokc.org",
    "c": "Culture",
    "d": "Oklahoma",
    "date": "2025"
  },
  {
    "n": "Alliance Française d'El Paso",
    "u": "https://afelpaso.org",
    "c": "Culture",
    "d": "Frontière Texas",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Washington Rochambeau",
    "u": "https://www.lyceerocheambeau.org",
    "c": "Éducation",
    "d": "Homologué DC avec programmes IB et français",
    "date": "2025"
  },
  {
    "n": "Awty International School Houston",
    "u": "https://www.awty.org",
    "c": "Éducation",
    "d": "IB français track Texas",
    "date": "2025"
  },
  {
    "n": "French American School of Dallas",
    "u": "https://www.fasdallas.org",
    "c": "Éducation",
    "d": "Bilingue Dallas maternelle à 12e",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Miami",
    "u": "https://www.miamilycee.org",
    "c": "Éducation",
    "d": "AEFE Floride avec bac français",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française Miami",
    "u": "https://www.efmiami.org",
    "c": "Éducation",
    "d": "Maternelle homologuée PS à grande section",
    "date": "2025"
  },
  {
    "n": "French American Academy Miami",
    "u": "https://www.faamiami.org",
    "c": "Éducation",
    "d": "Bilingue maternelle à 5e Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Los Angeles",
    "u": "https://www.lyceela.org",
    "c": "Éducation",
    "d": "AEFE CA Sud avec immersion",
    "date": "2025"
  },
  {
    "n": "French American School of Silicon Valley",
    "u": "https://www.fasv.org",
    "c": "Éducation",
    "d": "Bilingue PS à 8e tech-focused",
    "date": "2025"
  },
  {
    "n": "Lycée Français de La Nouvelle-Orléans",
    "u": "https://www.lfno.org",
    "c": "Éducation",
    "d": "Homologué Louisiane francophone",
    "date": "2025"
  },
  {
    "n": "École Bilingue de La Nouvelle-Orléans",
    "u": "https://www.eblions.org",
    "c": "Éducation",
    "d": "Immersion PS à 8e LA",
    "date": "2025"
  },
  {
    "n": "International School of Louisiana",
    "u": "https://www.isl-edu.org",
    "c": "Éducation",
    "d": "Publique bilingue K-12 Louisiane",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Philadelphie",
    "u": "https://www.lfphila.org",
    "c": "Éducation",
    "d": "AEFE Pennsylvanie avec bac",
    "date": "2025"
  },
  {
    "n": "French International School of Philadelphia",
    "u": "https://www.fisphila.org",
    "c": "Éducation",
    "d": "Bilingue maternelle à 8e PA",
    "date": "2025"
  },
  {
    "n": "Lycée Français d'Atlanta",
    "u": "https://www.lfatl.org",
    "c": "Éducation",
    "d": "Homologué Géorgie Sud-Est",
    "date": "2025"
  },
  {
    "n": "International Charter School Atlanta",
    "u": "https://www.icsatlanta.org",
    "c": "Éducation",
    "d": "Publique immersion K-6 GA",
    "date": "2025"
  },
  {
    "n": "Lycée Français de San Diego",
    "u": "https://www.lfisd.org",
    "c": "Éducation",
    "d": "AEFE CA Sud avec IB",
    "date": "2025"
  },
  {
    "n": "French American School of Tampa Bay",
    "u": "https://www.fastb.org",
    "c": "Éducation",
    "d": "Bilingue Floride Ouest PS-8",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Raleigh",
    "u": "https://www.lfraleigh.org",
    "c": "Éducation",
    "d": "Homologué Caroline du Nord",
    "date": "2025"
  },
  {
    "n": "French American Academy NJ",
    "u": "https://www.faacademy.org",
    "c": "Éducation",
    "d": "Bilingue New Jersey PS-8",
    "date": "2025"
  },
  {
    "n": "École Bilingue de New Jersey",
    "u": "https://www.ebnj.org",
    "c": "Éducation",
    "d": "Immersion PS à 5e NJ",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Greenwich",
    "u": "https://www.lfgreenwich.org",
    "c": "Éducation",
    "d": "Connecticut francophone AEFE",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Seattle",
    "u": "https://www.fas-seattle.org",
    "c": "Éducation",
    "d": "AEFE Nord-Ouest avec bac",
    "date": "2025"
  },
  {
    "n": "French Immersion School of Washington",
    "u": "https://www.fisw.org",
    "c": "Éducation",
    "d": "Immersion K-5 Seattle",
    "date": "2025"
  },
  {
    "n": "French American School of Arizona",
    "u": "https://www.fasaz.org",
    "c": "Éducation",
    "d": "Bilingue Phoenix PS-8",
    "date": "2025"
  },
  {
    "n": "École Française de Cleveland",
    "u": "https://www.efcleveland.org",
    "c": "Éducation",
    "d": "Programme français Ohio",
    "date": "2025"
  },
  {
    "n": "French American School of Music MN",
    "u": "https://www.fasm-mn.org",
    "c": "Éducation",
    "d": "Musique immersion Minnesota",
    "date": "2025"
  },
  {
    "n": "École Française du Maine",
    "u": "https://www.efmaine.org",
    "c": "Éducation",
    "d": "Maine francophone PS-5",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Portland Maine",
    "u": "https://www.lyceefrançaisportland.org",
    "c": "Éducation",
    "d": "Nord-Est bilingue",
    "date": "2025"
  },
  {
    "n": "French School of Detroit",
    "u": "https://www.fsdetroit.org",
    "c": "Éducation",
    "d": "Michigan immersion PS-8",
    "date": "2025"
  },
  {
    "n": "École Claire Fontaine LA",
    "u": "https://www.ecoleclairefontaine.org",
    "c": "Éducation",
    "d": "Maternelle française CA",
    "date": "2025"
  },
  {
    "n": "Le Petit Gan NY",
    "u": "https://www.lepetitgan.com",
    "c": "Éducation",
    "d": "Maternelle bilingue NY",
    "date": "2025"
  },
  {
    "n": "Les Petits Citoyens Miami",
    "u": "https://www.lespetitscitoyens.org",
    "c": "Éducation",
    "d": "Maternelle française Floride",
    "date": "2025"
  },
  {
    "n": "Lycée Français International Palm Beach",
    "u": "https://www.lfipb.org",
    "c": "Éducation",
    "d": "AEFE Floride Sud",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française LA",
    "u": "https://www.emfla.org",
    "c": "Éducation",
    "d": "PS à GS Los Angeles",
    "date": "2025"
  },
  {
    "n": "Le Jardin des Enfants SF",
    "u": "https://www.lejardindesenfants.org",
    "c": "Éducation",
    "d": "Maternelle Baie",
    "date": "2025"
  },
  {
    "n": "La Petite Ecole NY",
    "u": "https://www.lapetiteecole.org",
    "c": "Éducation",
    "d": "Maternelle bilingue NY",
    "date": "2025"
  },
  {
    "n": "École Maternelle Française Washington",
    "u": "https://www.emfw.org",
    "c": "Éducation",
    "d": "PS à GS DC",
    "date": "2025"
  },
  {
    "n": "Les Petits Sourires Houston",
    "u": "https://www.lespetitssourires.org",
    "c": "Éducation",
    "d": "Maternelle Texas",
    "date": "2025"
  },
  {
    "n": "La Maternelle Française Chicago",
    "u": "https://www.lamaternellefrancaise.org",
    "c": "Éducation",
    "d": "Immersion Midwest",
    "date": "2025"
  },
  {
    "n": "École Bilingue de Boston",
    "u": "https://www.ebboston.org",
    "c": "Éducation",
    "d": "Bilingue MA PS-8",
    "date": "2025"
  },
  {
    "n": "French American School of Miami",
    "u": "https://www.fasmiami.org",
    "c": "Éducation",
    "d": "Immersion Floride PS-8",
    "date": "2025"
  },
  {
    "n": "Georgetown University French Dept",
    "u": "https://french.georgetown.edu",
    "c": "Éducation",
    "d": "Études francophones DC avec immersion",
    "date": "2025"
  },
  {
    "n": "Columbia University French Dept",
    "u": "https://french.columbia.edu",
    "c": "Éducation",
    "d": "Major français NY",
    "date": "2025"
  },
  {
    "n": "NYU Department of French",
    "u": "https://as.nyu.edu/french",
    "c": "Éducation",
    "d": "Littérature francophone NYU",
    "date": "2025"
  },
  {
    "n": "Harvard Romance Languages French",
    "u": "https://rll.fas.harvard.edu/french",
    "c": "Éducation",
    "d": "Section française Harvard",
    "date": "2025"
  },
  {
    "n": "Yale French Department",
    "u": "https://french.yale.edu",
    "c": "Éducation",
    "d": "Programmes francophones Yale",
    "date": "2025"
  },
  {
    "n": "University of Louisiana Lafayette Francophonie",
    "u": "https://louisiana.edu/francophonie",
    "c": "Éducation",
    "d": "Centre excellence Acadie",
    "date": "2025"
  },
  {
    "n": "Brown University French Studies",
    "u": "https://www.brown.edu/academics/french-studies",
    "c": "Éducation",
    "d": "Humanités francophones Brown",
    "date": "2025"
  },
  {
    "n": "University of Wisconsin Milwaukee French",
    "u": "https://uwm.edu/french",
    "c": "Éducation",
    "d": "Francophonie nord-américaine WI",
    "date": "2025"
  },
  {
    "n": "Vassar College French Department",
    "u": "https://www.vassar.edu/french",
    "c": "Éducation",
    "d": "Études avancées Vassar",
    "date": "2025"
  },
  {
    "n": "Tufts Romance Languages French",
    "u": "https://as.tufts.edu/romance/french",
    "c": "Éducation",
    "d": "Culture française Tufts",
    "date": "2025"
  },
  {
    "n": "University of Pittsburgh Johnstown French",
    "u": "https://www.upj.pitt.edu/academics/foreign-languages",
    "c": "Éducation",
    "d": "Carrières internationales PA",
    "date": "2025"
  },
  {
    "n": "Dartmouth French and Italian",
    "u": "https://frenchanditalian.dartmouth.edu",
    "c": "Éducation",
    "d": "Perspective globale Dartmouth",
    "date": "2025"
  },
  {
    "n": "UC Berkeley French Department",
    "u": "https://french.berkeley.edu",
    "c": "Éducation",
    "d": "Ressources bilingues Berkeley",
    "date": "2025"
  },
  {
    "n": "Princeton French and Italian",
    "u": "https://french.princeton.edu",
    "c": "Éducation",
    "d": "Recherche francophone Princeton",
    "date": "2025"
  },
  {
    "n": "University of Chicago Romance French",
    "u": "https://rll.uchicago.edu/french",
    "c": "Éducation",
    "d": "Interdisciplinaire Chicago",
    "date": "2025"
  },
  {
    "n": "Stanford French and Italian",
    "u": "https://frenchitalian.stanford.edu",
    "c": "Éducation",
    "d": "Littérature contemporaine Stanford",
    "date": "2025"
  },
  {
    "n": "UPenn Romance Languages French",
    "u": "https://rlan.sas.upenn.edu/french",
    "c": "Éducation",
    "d": "Cultures francophones Penn",
    "date": "2025"
  },
  {
    "n": "Cornell Romance Studies French",
    "u": "https://romancestudies.cornell.edu/french",
    "c": "Éducation",
    "d": "Ressources internationales Cornell",
    "date": "2025"
  },
  {
    "n": "University of Michigan Romance French",
    "u": "https://lsa.umich.edu/rll/french.html",
    "c": "Éducation",
    "d": "Échanges francophones Michigan",
    "date": "2025"
  },
  {
    "n": "University of Virginia French Dept",
    "u": "https://french.as.virginia.edu",
    "c": "Éducation",
    "d": "Louisiane et Acadie UVA",
    "date": "2025"
  },
  {
    "n": "Haiti Progress",
    "u": "https://haitiprogres.com",
    "c": "Médias",
    "d": "Trilingue incluant FR pour communauté haïtienne US",
    "date": "2025"
  },
  {
    "n": "Bonjour Minnesota",
    "u": "https://bonjourminnesota.com",
    "c": "Médias",
    "d": "Actualités francophiles Midwest",
    "date": "2025"
  },
  {
    "n": "Fréquence Juive USA",
    "u": "https://frequencejuive.com/usa",
    "c": "Médias",
    "d": "Magazine juifs francophones US gratuit",
    "date": "2025"
  },
  {
    "n": "French Bridge",
    "u": "https://frenchbridge.org",
    "c": "Médias",
    "d": "Média participatif adolescents francophones US",
    "date": "2025"
  },
  {
    "n": "Canal+ International USA",
    "u": "https://canalplus.com/usa",
    "c": "Médias",
    "d": "TV française via Direct TV pour expatriés",
    "date": "2025"
  },
  {
    "n": "French Morning LA",
    "u": "https://frenchmorning.com/los-angeles",
    "c": "Médias",
    "d": "Locale Californie",
    "date": "2025"
  },
  {
    "n": "French Morning SF",
    "u": "https://frenchmorning.com/san-francisco",
    "c": "Médias",
    "d": "Baie tech francophone",
    "date": "2025"
  },
  {
    "n": "French Morning DC",
    "u": "https://frenchmorning.com/washington-dc",
    "c": "Médias",
    "d": "Capitale édition",
    "date": "2025"
  },
  {
    "n": "LVMH North America",
    "u": "https://www.lvmh.com/fr/north-america",
    "c": "Commerce",
    "d": "Groupe luxe section FR US",
    "date": "2025"
  },
  {
    "n": "L'Oréal USA",
    "u": "https://www.loreal.com/fr/usa",
    "c": "Commerce",
    "d": "Filiale cosmétiques FR US",
    "date": "2025"
  },
  {
    "n": "Pernod Ricard USA",
    "u": "https://www.pernod-ricard.com/fr/usa",
    "c": "Commerce",
    "d": "Spiritueux bilingue marché US",
    "date": "2025"
  },
  {
    "n": "Capgemini USA",
    "u": "https://www.capgemini.com/fr/usa",
    "c": "Commerce",
    "d": "Services numériques FR US",
    "date": "2025"
  },
  {
    "n": "Nokia Bell Labs US",
    "u": "https://www.nokia.com/fr/bell-labs/usa",
    "c": "Commerce",
    "d": "Tech française ressources FR",
    "date": "2025"
  },
  {
    "n": "Société Générale Americas",
    "u": "https://www.societegenerale.com/fr/americas",
    "c": "Commerce",
    "d": "Banque francophone US",
    "date": "2025"
  },
  {
    "n": "SIFA USA",
    "u": "https://sifa-usa.com",
    "c": "Commerce",
    "d": "Logistique internationale Floride",
    "date": "2025"
  },
  {
    "n": "Michelin North America",
    "u": "https://www.michelinman.com/fr/usa",
    "c": "Commerce",
    "d": "Pneus section FR US",
    "date": "2025"
  },
  {
    "n": "Sanofi USA",
    "u": "https://www.sanofi.com/fr/usa",
    "c": "Commerce",
    "d": "Pharma bilingue US",
    "date": "2025"
  },
  {
    "n": "TotalEnergies USA",
    "u": "https://totalenergies.com/fr/usa",
    "c": "Commerce",
    "d": "Énergie opérations FR US",
    "date": "2025"
  },
  {
    "n": "Veolia North America",
    "u": "https://www.veolianorthamerica.com/fr",
    "c": "Commerce",
    "d": "Environnement version FR",
    "date": "2025"
  },
  {
    "n": "Thales USA",
    "u": "https://www.thalesgroup.com/fr/usa",
    "c": "Commerce",
    "d": "Défense tech ressources FR",
    "date": "2025"
  },
  {
    "n": "Schneider Electric USA",
    "u": "https://www.se.com/fr/fr/usa",
    "c": "Commerce",
    "d": "Énergie management bilingue",
    "date": "2025"
  },
  {
    "n": "BNP Paribas USA",
    "u": "https://group.bnpparibas/fr/usa",
    "c": "Commerce",
    "d": "Banque section FR Amérique",
    "date": "2025"
  },
  {
    "n": "Crédit Agricole CIB Americas",
    "u": "https://www.ca-cib.com/fr/americas",
    "c": "Commerce",
    "d": "Finances FR US",
    "date": "2025"
  },
  {
    "n": "Groupama Asset Management US",
    "u": "https://www.groupama-am.fr/fr/usa",
    "c": "Commerce",
    "d": "Actifs exposition US",
    "date": "2025"
  },
  {
    "n": "OFI Asset Management US",
    "u": "https://www.ofiam.com/fr/usa",
    "c": "Commerce",
    "d": "Fonds US francophones",
    "date": "2025"
  },
  {
    "n": "Mandarine Gestion US",
    "u": "https://www.mandarine-gestion.com/fr/usa",
    "c": "Commerce",
    "d": "Actifs marchés US",
    "date": "2025"
  },
  {
    "n": "Institut DATAIA US Partnerships",
    "u": "https://www.dataia.fr/fr/usa",
    "c": "Technologie",
    "d": "IA partenariats franco-US",
    "date": "2025"
  },
  {
    "n": "PRAIRIE Institute US",
    "u": "https://www.prairie-institute.fr/fr/usa",
    "c": "Technologie",
    "d": "Recherche IA US",
    "date": "2025"
  },
  {
    "n": "ADEME International US",
    "u": "https://www.ademe-international.fr/fr/usa",
    "c": "Écologie",
    "d": "Projets verts FR US",
    "date": "2025"
  },
  {
    "n": "Fondation du Patrimoine US Projects",
    "u": "https://www.fondation-patrimoine.org/fr/usa",
    "c": "Culture",
    "d": "Sauvegarde franco-américain",
    "date": "2025"
  },
  {
    "n": "French District Annuaire",
    "u": "https://frenchdistrict.com/annuaire",
    "c": "Commerce",
    "d": "Entreprises françaises US mises à jour quotidiennes",
    "date": "2025"
  },
  {
    "n": "EuropUsa Annuaire",
    "u": "https://www.annuaire-europusa.com",
    "c": "Commerce",
    "d": "Spécialistes francophones US visas et pros",
    "date": "2025"
  },
  {
    "n": "AnnuaireUS Français",
    "u": "https://annuaireus.com/annuaire/?lang=fr",
    "c": "Commerce",
    "d": "Guide pros francophones pour vivre aux US",
    "date": "2025"
  },
  {
    "n": "La French Tech New York",
    "u": "https://lafrenchtech.com/newyork",
    "c": "Technologie",
    "d": "Communauté startups FR NY",
    "date": "2025"
  },
  {
    "n": "La French Tech San Francisco",
    "u": "https://lafrenchtech.com/sanfrancisco",
    "c": "Technologie",
    "d": "Écosystème tech Baie FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Los Angeles",
    "u": "https://lafrenchtech.com/losangeles",
    "c": "Technologie",
    "d": "Startups CA Sud FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Miami",
    "u": "https://lafrenchtech.miami",
    "c": "Technologie",
    "d": "Communauté Floride FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Boston",
    "u": "https://lafrenchtech.com/boston",
    "c": "Technologie",
    "d": "Tech Nouvelle-Angleterre FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Chicago",
    "u": "https://lafrenchtech.com/chicago",
    "c": "Technologie",
    "d": "Midwest startups FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Houston",
    "u": "https://lafrenchtech.com/houston",
    "c": "Technologie",
    "d": "Énergie tech Texas FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Austin",
    "u": "https://lafrenchtech.com/austin",
    "c": "Technologie",
    "d": "Communauté Austin FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Denver",
    "u": "https://lafrenchtech.com/denver",
    "c": "Technologie",
    "d": "Rockies startups FR",
    "date": "2025"
  },
  {
    "n": "La French Tech San Diego",
    "u": "https://lafrenchtech.com/sandiego",
    "c": "Technologie",
    "d": "Biotech CA Sud FR",
    "date": "2025"
  },
  {
    "n": "La French Tech Raleigh RTP",
    "u": "https://lafrenchtech.com/raleigh",
    "c": "Technologie",
    "d": "Triangle recherche FR",
    "date": "2025"
  },
  {
    "n": "French American Chamber of Commerce New York",
    "u": "https://faccny.org",
    "c": "Commerce",
    "d": "Réseau business FR NY",
    "date": "2025"
  },
  {
    "n": "FACC Los Angeles",
    "u": "https://www.facc-la.org",
    "c": "Commerce",
    "d": "Chambre commerce CA FR",
    "date": "2025"
  },
  {
    "n": "FACC Miami Florida",
    "u": "https://www.faccmiami.com",
    "c": "Commerce",
    "d": "Floride réseau FR",
    "date": "2025"
  },
  {
    "n": "FACC Washington DC",
    "u": "https://faccwdc.org",
    "c": "Commerce",
    "d": "Capitale business FR",
    "date": "2025"
  },
  {
    "n": "FACC Chicago",
    "u": "https://www.facc-chicago.com",
    "c": "Commerce",
    "d": "Midwest chambre FR",
    "date": "2025"
  },
  {
    "n": "FACC Boston New England",
    "u": "https://www.faccne.org",
    "c": "Commerce",
    "d": "Nouvelle-Angleterre FR",
    "date": "2025"
  },
  {
    "n": "FACC San Francisco",
    "u": "https://www.faccsf.com",
    "c": "Commerce",
    "d": "Baie tech commerce FR",
    "date": "2025"
  },
  {
    "n": "FACC Seattle PNW",
    "u": "https://www.faccpnw.org",
    "c": "Commerce",
    "d": "Nord-Ouest US FR",
    "date": "2025"
  },
  {
    "n": "FACC Atlanta Carolinas",
    "u": "https://www.facccarolinas.com",
    "c": "Commerce",
    "d": "Sud-Est chambres FR",
    "date": "2025"
  },
  {
    "n": "FACC Dallas",
    "u": "https://www.faccdallas.com",
    "c": "Commerce",
    "d": "Texas réseau FR",
    "date": "2025"
  },
  {
    "n": "FACC Minnesota",
    "u": "https://www.faccmn.com",
    "c": "Commerce",
    "d": "Midwest central FR",
    "date": "2025"
  },
  {
    "n": "FACC Philadelphia",
    "u": "https://www.faccphila.org",
    "c": "Commerce",
    "d": "Pennsylvanie FR",
    "date": "2025"
  },
  {
    "n": "FACC Denver Rockies",
    "u": "https://www.faccdenver.org",
    "c": "Commerce",
    "d": "Colorado chambre FR",
    "date": "2025"
  },
  {
    "n": "FACC Houston Gulf Coast",
    "u": "https://www.facchgulf.org",
    "c": "Commerce",
    "d": "Golfe Texas FR",
    "date": "2025"
  },
  {
    "n": "FACC Portland",
    "u": "https://www.faccpdx.org",
    "c": "Commerce",
    "d": "Oregon réseau FR",
    "date": "2025"
  },
  {
    "n": "FACC Nashville",
    "u": "https://www.faccnashville.org",
    "c": "Commerce",
    "d": "Tennessee FR",
    "date": "2025"
  },
  {
    "n": "FACC Orlando Florida Central",
    "u": "https://www.faccorlando.com",
    "c": "Commerce",
    "d": "Floride centrale FR",
    "date": "2025"
  },
  {
    "n": "FACC Phoenix Arizona",
    "u": "https://www.faccphoenix.org",
    "c": "Commerce",
    "d": "Arizona chambre FR",
    "date": "2025"
  },
  {
    "n": "FACC San Diego",
    "u": "https://www.faccsandiego.org",
    "c": "Commerce",
    "d": "CA Sud réseau FR",
    "date": "2025"
  },
  {
    "n": "FACC National Network",
    "u": "https://nationalfacc.org",
    "c": "Commerce",
    "d": "18 chapitres US FACC unifiés",
    "date": "2025"
  },
  {
    "n": "American Association Teachers French AATF",
    "u": "https://www.frenchteachers.org",
    "c": "Éducation",
    "d": "Ressources profs français US",
    "date": "2025"
  },
  {
    "n": "Association France Etats-Unis",
    "u": "https://www.france-etatsunis.org",
    "c": "Culture",
    "d": "Amitié FR-US événements",
    "date": "2025"
  },
  {
    "n": "French Arts Associates",
    "u": "https://www.frenchartsassociates.org",
    "c": "Culture",
    "d": "Réseau pros art FR",
    "date": "2025"
  },
  {
    "n": "French Club Daytona Beach",
    "u": "https://www.frenchclubdaytona.org",
    "c": "Culture",
    "d": "Rencontres Floride",
    "date": "2025"
  },
  {
    "n": "ADFE USA Sections",
    "u": "https://adfe.org/sections/usa",
    "c": "Culture",
    "d": "Droits expatriés FR US",
    "date": "2025"
  },
  {
    "n": "UFE USA",
    "u": "https://ufe.org/sections/usa",
    "c": "Culture",
    "d": "Intégration expatriés FR",
    "date": "2025"
  },
  {
    "n": "ACREFEU USA",
    "u": "https://www.acrefeu.fr/sections/usa",
    "c": "Culture",
    "d": "Réservistes FR US",
    "date": "2025"
  },
  {
    "n": "American Society Souvenir Français",
    "u": "https://www.souvenirfrancaisusa.org",
    "c": "Culture",
    "d": "Mémorial combattants FR",
    "date": "2025"
  },
  {
    "n": "Paris Choral Society US",
    "u": "https://www.parischoralsociety.org",
    "c": "Culture",
    "d": "Chœur bilingue échanges",
    "date": "2025"
  },
  {
    "n": "Travellers Club Paris US Links",
    "u": "https://thetravellersparis.com",
    "c": "Culture",
    "d": "Club anglo-français liens US",
    "date": "2025"
  },
  {
    "n": "UC Alumni Paris US",
    "u": "https://alumni.berkeley.edu/paris",
    "c": "Culture",
    "d": "Alumni franco-américains",
    "date": "2025"
  },
  {
    "n": "En Marche New York",
    "u": "https://en-marche-new-york.org",
    "c": "Culture",
    "d": "Politique FR expatriés NY",
    "date": "2025"
  },
  {
    "n": "Français Humanistes Amérique Nord",
    "u": "https://facebook.com/lesfrancaisHumanistesUSA",
    "c": "Culture",
    "d": "Groupe humaniste FR US",
    "date": "2025"
  },
  {
    "n": "Business France USA",
    "u": "https://www.businessfrance.fr",
    "c": "Commerce",
    "d": "Promotion export FR US",
    "date": "2025"
  },
  {
    "n": "Tournée des Chefs Français US",
    "u": "https://tourneedeschefs.com",
    "c": "Culture",
    "d": "Chefs étoilés FR US",
    "date": "2025"
  },
  {
    "n": "French Cheese Board US",
    "u": "https://frenchcheeseboard.com",
    "c": "Culture",
    "d": "Fromages FR NY",
    "date": "2025"
  },
  {
    "n": "La Maison Française NY",
    "u": "https://lamaisonfrancaise.org",
    "c": "Culture",
    "d": "Boutique culturelle Rockefeller",
    "date": "2025"
  },
  {
    "n": "Librairie Française LA",
    "u": "https://librairiefrancaise.com",
    "c": "Culture",
    "d": "Livres FR Los Angeles",
    "date": "2025"
  },
  {
    "n": "French Institute Alliance Française NY",
    "u": "https://fiaf.org",
    "c": "Culture",
    "d": "Plus grande institution FR NY",
    "date": "2025"
  },
  {
    "n": "Cultural Services French Embassy US",
    "u": "https://frenchculture.org",
    "c": "Culture",
    "d": "Programmation nationale FR",
    "date": "2025"
  },
  {
    "n": "American Friends of Versailles US",
    "u": "https://americanfriendsofversailles.org",
    "c": "Culture",
    "d": "Soutien Versailles depuis US",
    "date": "2025"
  },
  {
    "n": "American Society Le Souvenir Français",
    "u": "https://souvenirfrancais-usa.org",
    "c": "Culture",
    "d": "Tombeaux soldats FR US",
    "date": "2025"
  },
  {
    "n": "Consulat Mobile US",
    "u": "https://consulat.gouv.fr",
    "c": "Gouvernement",
    "d": "Tournées consulaires FR US",
    "date": "2025"
  },
  {
    "n": "French Healthcare US",
    "u": "https://frenchhealthcare.fr",
    "c": "Santé",
    "d": "Expertise santé FR US",
    "date": "2025"
  },
  {
    "n": "French Tech Health US",
    "u": "https://frenchtech.health",
    "c": "Technologie",
    "d": "Startups santé FR",
    "date": "2025"
  },
  {
    "n": "French BioBeach San Diego",
    "u": "https://frenchbiobeach.org",
    "c": "Technologie",
    "d": "Cluster biotech FR CA",
    "date": "2025"
  },
  {
    "n": "French Aerospace Network US",
    "u": "https://frenchaerospace.org",
    "c": "Technologie",
    "d": "Aéronautique FR US",
    "date": "2025"
  },
  {
    "n": "French Nuclear Network US",
    "u": "https://frenchnuclear.org",
    "c": "Technologie",
    "d": "Nucléaire filière FR",
    "date": "2025"
  },
  {
    "n": "French Luxury Network US",
    "u": "https://frenchluxury.us",
    "c": "Commerce",
    "d": "Luxe FR réseau",
    "date": "2025"
  },
  {
    "n": "French Gourmet Network US",
    "u": "https://frenchgourmet.us",
    "c": "Commerce",
    "d": "Gastronomie FR réseau",
    "date": "2025"
  },
  {
    "n": "French Affairs NY",
    "u": "https://frenchaffairs.com",
    "c": "Culture",
    "d": "Événements FR NY",
    "date": "2025"
  },
  {
    "n": "French Restaurant Week US",
    "u": "https://frenchrestaurantweek.com",
    "c": "Culture",
    "d": "Semaine restaurants FR",
    "date": "2025"
  },
  {
    "n": "French Cheese Week US",
    "u": "https://frencheeseweek.com",
    "c": "Culture",
    "d": "Fromages FR événements",
    "date": "2025"
  },
  {
    "n": "French Cinema Week US",
    "u": "https://rendezvouswithfrenchcinema.com",
    "c": "Culture",
    "d": "Festival cinéma FR",
    "date": "2025"
  },
  {
    "n": "French Tech Days US",
    "u": "https://frenchtechdays.com",
    "c": "Technologie",
    "d": "Événements tech FR",
    "date": "2025"
  },
  {
    "n": "French Violin School US",
    "u": "https://frenchviolinschool.org",
    "c": "Éducation",
    "d": "Violon FR US",
    "date": "2025"
  },
  {
    "n": "École de Ballet Français US",
    "u": "https://ecoleballetfrancais.org",
    "c": "Éducation",
    "d": "Ballet classique FR",
    "date": "2025"
  },
  {
    "n": "French Fashion Academy US",
    "u": "https://frenchfashionacademy.org",
    "c": "Éducation",
    "d": "Mode FR formation",
    "date": "2025"
  },
  {
    "n": "French Pastry School Chicago",
    "u": "https://frenchpastryschool.com",
    "c": "Éducation",
    "d": "Pâtisserie FR US",
    "date": "2025"
  },
  {
    "n": "International Culinary Center US",
    "u": "https://internationalculinarycenter.com",
    "c": "Éducation",
    "d": "Cuisine FR New York",
    "date": "2025"
  },
  {
    "n": "French Wine Scholar US",
    "u": "https://frenchwinescholar.org",
    "c": "Éducation",
    "d": "Certification vins FR",
    "date": "2025"
  },
  {
    "n": "French Cheese Master US",
    "u": "https://frenchcheesemaster.org",
    "c": "Éducation",
    "d": "Fromages FR formation",
    "date": "2025"
  },
  {
    "n": "Sommelier Society America FR",
    "u": "https://sommeliersociety.org",
    "c": "Éducation",
    "d": "Sommellerie FR US",
    "date": "2025"
  },
  {
    "n": "Fulbright France US",
    "u": "https://fulbright-france.org",
    "c": "Éducation",
    "d": "Échanges académiques",
    "date": "2025"
  },
  {
    "n": "French Embassy Higher Education US",
    "u": "https://highereducation.franceintheus.org",
    "c": "Éducation",
    "d": "Études supérieures FR US",
    "date": "2025"
  },
  {
    "n": "French Dual Language Program US",
    "u": "https://frenchduallanguage.org",
    "c": "Éducation",
    "d": "Écoles publiques bilingues",
    "date": "2025"
  },
  {
    "n": "American Association Teachers French",
    "u": "https://frenchteachers.org",
    "c": "Éducation",
    "d": "Profs FR ressources US",
    "date": "2025"
  },
  {
    "n": "French for the Future US",
    "u": "https://french-future.org",
    "c": "Éducation",
    "d": "Français jeunes US",
    "date": "2025"
  },
  {
    "n": "Concours National Français US",
    "u": "https://grandconcours.org",
    "c": "Éducation",
    "d": "Compétitions FR étudiants",
    "date": "2025"
  },
  {
    "n": "French Honor Society US",
    "u": "https://frenchhonorsociety.org",
    "c": "Éducation",
    "d": "Honneur lycées FR",
    "date": "2025"
  },
  {
    "n": "Pi Delta Phi US",
    "u": "https://pideltaphi.org",
    "c": "Éducation",
    "d": "Honneur universités FR",
    "date": "2025"
  },
  {
    "n": "Delta Phi Alpha FR Track",
    "u": "https://deltaphialpha.org",
    "c": "Éducation",
    "d": "Langues étrangères FR",
    "date": "2025"
  },
  {
    "n": "French Club USA Network",
    "u": "https://frenchclubusa.org",
    "c": "Culture",
    "d": "Clubs lycées FR US",
    "date": "2025"
  },
  {
    "n": "Journée de la Francophonie US",
    "u": "https://francophonie.us",
    "c": "Culture",
    "d": "20 mars célébrations US",
    "date": "2025"
  },
  {
    "n": "Mois de la Francophonie US",
    "u": "https://moisfrancophonie.org",
    "c": "Culture",
    "d": "Mars événements FR",
    "date": "2025"
  },
  {
    "n": "Certamen Français US",
    "u": "https://certamenfrancais.org",
    "c": "Éducation",
    "d": "Culture FR compétition",
    "date": "2025"
  },
  {
    "n": "French Debating Association US",
    "u": "https://frenchdebating.org",
    "c": "Éducation",
    "d": "Débat FR US",
    "date": "2025"
  },
  {
    "n": "French Theater Competition US",
    "u": "https://frenchtheater.us",
    "c": "Culture",
    "d": "Théâtre FR concours",
    "date": "2025"
  },
  {
    "n": "French Song Contest US",
    "u": "https://frenchsong.us",
    "c": "Culture",
    "d": "Chanson FR compétition",
    "date": "2025"
  },
  {
    "n": "French Cooking Contest US",
    "u": "https://frenchcooking.us",
    "c": "Culture",
    "d": "Cuisine FR concours",
    "date": "2025"
  },
  {
    "n": "French Tech Visa US Partners",
    "u": "https://frenchtechvisa.org",
    "c": "Technologie",
    "d": "Visa talents tech FR US",
    "date": "2025"
  },
  {
    "n": "Talent Passport FR US",
    "u": "https://talentpassport.fr",
    "c": "Travail",
    "d": "Visa 4 ans talents FR",
    "date": "2025"
  },
  {
    "n": "French Touch Dreamin US",
    "u": "https://frenchtouchdreamin.com",
    "c": "Technologie",
    "d": "Salesforce FR événements",
    "date": "2025"
  },
  {
    "n": "French American Pétanque",
    "u": "https://fapetanque.org",
    "c": "Sport",
    "d": "Pétanque tournois US",
    "date": "2025"
  },
  {
    "n": "French American Bakery Network",
    "u": "https://fabakery.org",
    "c": "Commerce",
    "d": "Boulangeries FR US",
    "date": "2025"
  },
  {
    "n": "French American Pâtisserie",
    "u": "https://fapatisserie.org",
    "c": "Commerce",
    "d": "Pâtisseries FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Bistro Network",
    "u": "https://fabistro.org",
    "c": "Commerce",
    "d": "Bistrots FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Crêperie",
    "u": "https://facreperie.org",
    "c": "Commerce",
    "d": "Crêperies FR US",
    "date": "2025"
  },
  {
    "n": "French American Macaron Shops",
    "u": "https://famacaron.org",
    "c": "Commerce",
    "d": "Macarons FR authentiques",
    "date": "2025"
  },
  {
    "n": "French American Caviar Houses",
    "u": "https://facaviar.org",
    "c": "Commerce",
    "d": "Caviar FR US",
    "date": "2025"
  },
  {
    "n": "French American Truffle Suppliers",
    "u": "https://fatruffe.org",
    "c": "Commerce",
    "d": "Truffes FR US",
    "date": "2025"
  },
  {
    "n": "French American Oyster Bars",
    "u": "https://faoyster.org",
    "c": "Commerce",
    "d": "Huîtres FR US",
    "date": "2025"
  },
  {
    "n": "French American Mussel Farms",
    "u": "https://famussel.org",
    "c": "Commerce",
    "d": "Moules FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Duck Producers",
    "u": "https://faduck.org",
    "c": "Commerce",
    "d": "Canard FR US",
    "date": "2025"
  },
  {
    "n": "French American Terrine Makers",
    "u": "https://faterrine.org",
    "c": "Commerce",
    "d": "Terrines FR US",
    "date": "2025"
  },
  {
    "n": "French American Pâté Houses",
    "u": "https://fapate.org",
    "c": "Commerce",
    "d": "Pâtés FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Confit Producers",
    "u": "https://faconfit.org",
    "c": "Commerce",
    "d": "Confits FR US",
    "date": "2025"
  },
  {
    "n": "French American Crêpe Houses",
    "u": "https://facrepe.org",
    "c": "Commerce",
    "d": "Crêpes FR US",
    "date": "2025"
  },
  {
    "n": "French American Galette Bretonne",
    "u": "https://fagalette.org",
    "c": "Commerce",
    "d": "Galettes bretonnes FR",
    "date": "2025"
  },
  {
    "n": "French American Baguette Bakeries",
    "u": "https://fabaguette.org",
    "c": "Commerce",
    "d": "Baguettes tradition FR US",
    "date": "2025"
  },
  {
    "n": "French American Croissant Shops",
    "u": "https://facroissant.org",
    "c": "Commerce",
    "d": "Croissants pur beurre FR",
    "date": "2025"
  },
  {
    "n": "French American Éclair Patisseries",
    "u": "https://faeclair.org",
    "c": "Commerce",
    "d": "Éclairs FR US",
    "date": "2025"
  },
  {
    "n": "French American Opéra Cake",
    "u": "https://faopera.org",
    "c": "Commerce",
    "d": "Gâteaux Opéra FR",
    "date": "2025"
  },
  {
    "n": "French American Mousse Chocolat",
    "u": "https://famousseauchocolat.org",
    "c": "Commerce",
    "d": "Mousses chocolat FR",
    "date": "2025"
  },
  {
    "n": "French American Nougat Montélimar",
    "u": "https://fanougatmontelimar.org",
    "c": "Commerce",
    "d": "Nougat FR US",
    "date": "2025"
  },
  {
    "n": "French American Dragée Verdun",
    "u": "https://fadragee.org",
    "c": "Commerce",
    "d": "Dragées FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Violette Toulouse",
    "u": "https://faviolettetoulouse.org",
    "c": "Commerce",
    "d": "Violettes FR US",
    "date": "2025"
  },
  {
    "n": "French American Anis Flavigny",
    "u": "https://faanisflavigny.org",
    "c": "Commerce",
    "d": "Anis FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Bergamote Nancy",
    "u": "https://fabergamotenancy.org",
    "c": "Commerce",
    "d": "Bergamotes FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Absinthe Pontarlier",
    "u": "https://faabsinthe.org",
    "c": "Commerce",
    "d": "Absinthe FR US",
    "date": "2025"
  },
  {
    "n": "French American Bénédictine Fécamp",
    "u": "https://fabenedictine.org",
    "c": "Commerce",
    "d": "Bénédictine FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Armagnac Gers",
    "u": "https://faarmagnac.org",
    "c": "Commerce",
    "d": "Armagnac FR US",
    "date": "2025"
  },
  {
    "n": "French American Cognac Charente",
    "u": "https://facognac.org",
    "c": "Commerce",
    "d": "Cognac maisons FR",
    "date": "2025"
  },
  {
    "n": "French American Bordeaux Crus",
    "u": "https://fabordeaux.org",
    "c": "Commerce",
    "d": "Grands crus Bordeaux US",
    "date": "2025"
  },
  {
    "n": "French American Rhône Côtes-du-Rhône",
    "u": "https://farhone.org",
    "c": "Commerce",
    "d": "Rhône vins FR US",
    "date": "2025"
  },
  {
    "n": "French American Alsace Vins",
    "u": "https://faalsace.org",
    "c": "Commerce",
    "d": "Alsace FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Loire Vallée",
    "u": "https://faloire.org",
    "c": "Commerce",
    "d": "Loire vins FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Sancerre Pouilly",
    "u": "https://fasancerre.org",
    "c": "Commerce",
    "d": "Sancerre FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Sauternes Liquoreux",
    "u": "https://fasauternes.org",
    "c": "Commerce",
    "d": "Sauternes FR US",
    "date": "2025"
  },
  {
    "n": "French American Crémant France",
    "u": "https://facremant.org",
    "c": "Commerce",
    "d": "Crémants FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Cidre Normandie",
    "u": "https://facidre.org",
    "c": "Commerce",
    "d": "Cidres FR Bretagne US",
    "date": "2025"
  },
  {
    "n": "French American Poiré Domfront",
    "u": "https://fapoire.org",
    "c": "Commerce",
    "d": "Poiré FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Pineau Charentes",
    "u": "https://fapineau.org",
    "c": "Commerce",
    "d": "Pineau FR US",
    "date": "2025"
  },
  {
    "n": "French American Floc Gascogne",
    "u": "https://fafloc.org",
    "c": "Commerce",
    "d": "Floc FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Gentiane Liqueurs",
    "u": "https://fagentiane.org",
    "c": "Commerce",
    "d": "Gentiane FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Kir Bourgogne",
    "u": "https://fakir.org",
    "c": "Commerce",
    "d": "Kir FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Romanée-Conti",
    "u": "https://romanee-conti.fr",
    "c": "Commerce",
    "d": "Romanée-Conti légende Bourgogne FR",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Leflaive",
    "u": "https://leflaive.fr",
    "c": "Commerce",
    "d": "Leflaive Puligny FR US",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Coche-Dury",
    "u": "https://coche-dury.com",
    "c": "Commerce",
    "d": "Coche-Dury Meursault FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Bourgogne Rousseau",
    "u": "https://domaine-rousseau.com",
    "c": "Commerce",
    "d": "Rousseau Gevrey FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Rhône Beaucastel",
    "u": "https://beaucastel.com",
    "c": "Commerce",
    "d": "Beaucastel Châteauneuf FR US",
    "date": "2025"
  },
  {
    "n": "French American Provence Esclans",
    "u": "https://esclans.com",
    "c": "Commerce",
    "d": "Esclans Whispering Angel rosé FR",
    "date": "2025"
  },
  {
    "n": "French American Provence Ott",
    "u": "https://domaines-ott.com",
    "c": "Commerce",
    "d": "Ott rosés mythiques US FR",
    "date": "2025"
  },
  {
    "n": "French American Provence Miraval",
    "u": "https://miraval.com",
    "c": "Commerce",
    "d": "Miraval rosé Brad Pitt FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Loire Huet",
    "u": "https://domainehuet.com",
    "c": "Commerce",
    "d": "Huet Vouvray FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Loire Rougeard",
    "u": "https://closrougeard.com",
    "c": "Commerce",
    "d": "Rougeard Saumur culte FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Languedoc Daumas Gassac",
    "u": "https://daumas-gassac.com",
    "c": "Commerce",
    "d": "Daumas grand cru Languedoc FR",
    "date": "2025"
  },
  {
    "n": "French American Sancerre Vacheron",
    "u": "https://domaine-vacheron.fr",
    "c": "Commerce",
    "d": "Vacheron Sancerre bio FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Sauternes Yquem",
    "u": "https://yquem.fr",
    "c": "Commerce",
    "d": "Yquem liquoreux légende FR US",
    "date": "2025"
  },
  {
    "n": "French American Crémant Loire Langlois",
    "u": "https://langlois-chateau.fr",
    "c": "Commerce",
    "d": "Langlois crémant prestige FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Crémant Alsace Wolfberger",
    "u": "https://wolfberger.com",
    "c": "Commerce",
    "d": "Wolfberger crémant Alsace FR fournisseurs",
    "date": "2025"
  },
  {
    "n": "French American Poiré Pacory",
    "u": "https://domaine-pacory.com",
    "c": "Commerce",
    "d": "Pacory poiré Domfront FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Floc Millet",
    "u": "https://chateau-millet.com",
    "c": "Commerce",
    "d": "Millet floc Gascogne FR US",
    "date": "2025"
  },
  {
    "n": "French American Pastis Bardouin",
    "u": "https://henri-bardouin.com",
    "c": "Commerce",
    "d": "Bardouin pastis artisanal FR",
    "date": "2025"
  },
  {
    "n": "French American Cointreau Orange",
    "u": "https://cointreau.com",
    "c": "Commerce",
    "d": "Cointreau liqueur FR réseau",
    "date": "2025"
  },
  {
    "n": "French American Grand Marnier Cognac",
    "u": "https://grandmarnier.com",
    "c": "Commerce",
    "d": "Grand Marnier orange FR US",
    "date": "2025"
  },
  {
    "n": "Université des Langues Étrangères de Pékin (BFSU)",
    "u": "https://www.bfsu.edu.cn",
    "c": "Éducation",
    "d": "La plus ancienne université de langues étrangères en Chine, avec département de français renommé.",
    "date": "2025"
  },
  {
    "n": "Université de Wuhan - Département de Français",
    "u": "https://french.whu.edu.cn",
    "c": "Éducation",
    "d": "Département de français de l'une des meilleures universités chinoises.",
    "date": "2025"
  },
  {
    "n": "Université Sun Yat-sen - Faculté de Français",
    "u": "https://french.sysu.edu.cn",
    "c": "Éducation",
    "d": "Programme de français de l'université prestigieuse du Sud de la Chine.",
    "date": "2025"
  },
  {
    "n": "Université Normale de la Chine de l'Est (ECNU)",
    "u": "https://french.ecnu.edu.cn",
    "c": "Éducation",
    "d": "Département de français à Shanghai, centre d'excellence pour les études francophones.",
    "date": "2025"
  },
  {
    "n": "Université du Peuple de Chine - Institut de Français",
    "u": "https://french.ruc.edu.cn",
    "c": "Éducation",
    "d": "Institut de français de l'université renommée pour les sciences sociales.",
    "date": "2025"
  },
  {
    "n": "Université des Études Internationales de Shanghai (SISU)",
    "u": "https://french.shisu.edu.cn",
    "c": "Éducation",
    "d": "Université spécialisée en langues étrangères avec fort département de français.",
    "date": "2025"
  },
  {
    "n": "Université du Yunnan - Département de Français",
    "u": "https://french.ynu.edu.cn",
    "c": "Éducation",
    "d": "Programme de français dans la région frontalière avec l'Asie du Sud-Est francophone.",
    "date": "2025"
  },
  {
    "n": "Université Normale du Guangxi",
    "u": "https://french.gxnu.edu.cn",
    "c": "Éducation",
    "d": "Département de français dans la région autonome Zhuang, proche du Vietnam.",
    "date": "2025"
  },
  {
    "n": "Siège de l'Institut Confucius (Hanban)",
    "u": "https://www.hanban.org",
    "c": "Culture",
    "d": "Organisation officielle chinoise pour la promotion de la langue chinoise à l'étranger.",
    "date": "2025"
  },
  {
    "n": "Alliance Française en Chine",
    "u": "https://www.afchine.org",
    "c": "Culture",
    "d": "Réseau des Alliances Françaises en Chine pour l'apprentissage du français.",
    "date": "2025"
  },
  {
    "n": "Centre Culturel Français de Pékin",
    "u": "https://www.ccfpekin.org",
    "c": "Culture",
    "d": "Institution culturelle française officielle en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Shanghai",
    "u": "https://www.shanghai.institutfrancais.cn",
    "c": "Culture",
    "d": "Centre culturel français à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Canton",
    "u": "https://www.canton.institutfrancais.cn",
    "c": "Culture",
    "d": "Centre culturel français à Guangzhou.",
    "date": "2025"
  },
  {
    "n": "China Radio International (CRI) Français",
    "u": "https://french.cri.cn",
    "c": "Médias",
    "d": "Service français de la radio internationale chinoise, basé à Pékin.",
    "date": "2025"
  },
  {
    "n": "CCTV Français",
    "u": "https://fr.cctv.com",
    "c": "Médias",
    "d": "Chaîne française de la télévision centrale chinoise.",
    "date": "2025"
  },
  {
    "n": "Xinhua Français",
    "u": "https://french.xinhuanet.com",
    "c": "Médias",
    "d": "Service français de l'agence de presse officielle chinoise Xinhua.",
    "date": "2025"
  },
  {
    "n": "China.org en Français",
    "u": "https://french.china.org.cn",
    "c": "Médias",
    "d": "Portail d'information chinois en langue française.",
    "date": "2025"
  },
  {
    "n": "Le Quotidien du Peuple en Français",
    "u": "https://french.peopledaily.com.cn",
    "c": "Médias",
    "d": "Édition française du journal officiel du Parti Communiste Chinois.",
    "date": "2025"
  },
  {
    "n": "China Today en Français",
    "u": "https://www.chinatoday.com.cn/fr",
    "c": "Médias",
    "d": "Revue mensuelle chinoise en langue française.",
    "date": "2025"
  },
  {
    "n": "Beijing Information en Français",
    "u": "https://www.beijinginformation.com/fr",
    "c": "Médias",
    "d": "Publication officielle de la municipalité de Pékin en français.",
    "date": "2025"
  },
  {
    "n": "Air China - Site Français",
    "u": "https://www.airchina.fr",
    "c": "Transport",
    "d": "Compagnie aérienne nationale chinoise, site en français.",
    "date": "2025"
  },
  {
    "n": "China Southern Airlines - Version Française",
    "u": "https://www.csair.com/fr",
    "c": "Transport",
    "d": "Plus grande compagnie aérienne chinoise, site en français.",
    "date": "2025"
  },
  {
    "n": "China Eastern Airlines - Français",
    "u": "https://fr.ceair.com",
    "c": "Transport",
    "d": "Compagnie aérienne basée à Shanghai, site français.",
    "date": "2025"
  },
  {
    "n": "Hainan Airlines - Site Francophone",
    "u": "https://www.hnair.com/fr-fr",
    "c": "Transport",
    "d": "Compagnie aérienne chinoise, informations en français.",
    "date": "2025"
  },
  {
    "n": "Baidu - Traduction Français",
    "u": "https://fanyi.baidu.com",
    "c": "Technologie",
    "d": "Service de traduction du moteur de recherche chinois Baidu, supporte le français.",
    "date": "2025"
  },
  {
    "n": "Alibaba - Site Français",
    "u": "https://french.alibaba.com",
    "c": "Commerce",
    "d": "Plateforme de commerce électronique chinoise en langue française.",
    "date": "2025"
  },
  {
    "n": "Tencent - Présentation Française",
    "u": "https://www.tencent.com/fr-fr",
    "c": "Technologie",
    "d": "Conglomérat technologique chinois, site en français.",
    "date": "2025"
  },
  {
    "n": "Huawei - Site France",
    "u": "https://www.huawei.com/fr",
    "c": "Technologie",
    "d": "Entreprise technologique chinoise, site pour le marché français.",
    "date": "2025"
  },
  {
    "n": "Xiaomi - France",
    "u": "https://www.mi.com/fr",
    "c": "Technologie",
    "d": "Fabricant chinois d'électronique, site français.",
    "date": "2025"
  },
  {
    "n": "BYD - Version Française",
    "u": "https://www.byd.com/fr",
    "c": "Automobile",
    "d": "Constructeur automobile chinois de véhicules électriques, site en français.",
    "date": "2025"
  },
  {
    "n": "Ambassade de Chine en France",
    "u": "https://www.amb-chine.fr",
    "c": "Gouvernement",
    "d": "Site officiel de l'ambassade de Chine en France, en français.",
    "date": "2025"
  },
  {
    "n": "Consulat Général de Chine à Paris",
    "u": "https://www.consulat-chine-paris.fr",
    "c": "Gouvernement",
    "d": "Site du consulat chinois à Paris, en langue française.",
    "date": "2025"
  },
  {
    "n": "Ministère des Affaires Étrangères Chinois - Français",
    "u": "https://www.fmprc.gov.cn/fra",
    "c": "Gouvernement",
    "d": "Site du ministère chinois des affaires étrangères en français.",
    "date": "2025"
  },
  {
    "n": "Office National du Tourisme de Chine (CNTO) - Français",
    "u": "https://fr.cnto.org",
    "c": "Tourisme",
    "d": "Site officiel du tourisme chinois en langue française.",
    "date": "2025"
  },
  {
    "n": "China Customs - Information en Français",
    "u": "https://www.customs.gov.cn/french",
    "c": "Gouvernement",
    "d": "Informations douanières chinoises en français.",
    "date": "2025"
  },
  {
    "n": "UNESCO Beijing Office",
    "u": "https://www.unesco.org/fieldoffice/beijing/fr",
    "c": "International",
    "d": "Bureau de l'UNESCO à Pékin, site en français.",
    "date": "2025"
  },
  {
    "n": "Banque Mondiale - Chine",
    "u": "https://www.worldbank.org/fr/country/china",
    "c": "Finance",
    "d": "Page de la Banque Mondiale sur la Chine, en français.",
    "date": "2025"
  },
  {
    "n": "FMI - Chine",
    "u": "https://www.imf.org/fr/Countries/CHN",
    "c": "Finance",
    "d": "Page du Fonds Monétaire International sur la Chine, en français.",
    "date": "2025"
  },
  {
    "n": "OMS - Bureau Chine",
    "u": "https://www.who.int/fr/countries/chn",
    "c": "Santé",
    "d": "Page de l'Organisation Mondiale de la Santé sur la Chine, en français.",
    "date": "2025"
  },
  {
    "n": "FAO - Chine",
    "u": "https://www.fao.org/fr/country/chn",
    "c": "Agriculture",
    "d": "Page de la FAO sur la Chine, en français.",
    "date": "2025"
  },
  {
    "n": "Université Francophone du Pacifique (Fiji)",
    "u": "https://www.ufp.ac.fj",
    "c": "Éducation",
    "d": "Université francophone dans le Pacifique Sud.",
    "date": "2025"
  },
  {
    "n": "Université de Nouvelle-Calédonie",
    "u": "https://www.unc.nc",
    "c": "Éducation",
    "d": "Université française dans le Pacifique Sud, territoire français.",
    "date": "2025"
  },
  {
    "n": "Université de la Polynésie Française",
    "u": "https://www.upf.pf",
    "c": "Éducation",
    "d": "Université française en Polynésie.",
    "date": "2025"
  },
  {
    "n": "Université Vanuatu - Département de Français",
    "u": "https://www.univ.edu.vu/fr",
    "c": "Éducation",
    "d": "Université du Vanuatu, pays bilingue français-anglais.",
    "date": "2025"
  },
  {
    "n": "Université Royale de Phnom Penh - Département de Français",
    "u": "https://www.rupp.edu.kh/fr",
    "c": "Éducation",
    "d": "Université cambodgienne avec programme de français.",
    "date": "2025"
  },
  {
    "n": "Université Nationale du Laos - Cours de Français",
    "u": "https://www.nuol.edu.la/fr",
    "c": "Éducation",
    "d": "Université laotienne avec enseignement du français.",
    "date": "2025"
  },
  {
    "n": "Université de Hanoi - Département de Français",
    "u": "https://www.hanu.edu.vn/fr",
    "c": "Éducation",
    "d": "Université vietnamienne avec programme de français.",
    "date": "2025"
  },
  {
    "n": "Université de Ho Chi Minh Ville - Français",
    "u": "https://www.hcmus.edu.vn/fr",
    "c": "Éducation",
    "d": "Université vietnamienne avec cours de français.",
    "date": "2025"
  },
  {
    "n": "Radio France Internationale (RFI) Asie",
    "u": "https://www.rfi.fr/fr/asie-pacifique",
    "c": "Médias",
    "d": "Service de RFI pour l'Asie-Pacifique.",
    "date": "2025"
  },
  {
    "n": "France 24 - Édition Asie",
    "u": "https://www.france24.com/fr/asie-pacifique",
    "c": "Médias",
    "d": "Chaîne d'information française, édition Asie-Pacifique.",
    "date": "2025"
  },
  {
    "n": "TV5 Monde Asie-Pacifique",
    "u": "https://www.tv5monde.com/asie-pacifique",
    "c": "Médias",
    "d": "Chaîne francophone mondiale, édition Asie-Pacifique.",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal Shanghai",
    "u": "https://www.lepetitjournal.com/shanghai",
    "c": "Médias",
    "d": "Journal francophone pour la communauté française de Shanghai.",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal Pékin",
    "u": "https://www.lepetitjournal.com/pekin",
    "c": "Médias",
    "d": "Journal francophone pour la communauté française de Pékin.",
    "date": "2025"
  },
  {
    "n": "Le Courrier de Shanghai",
    "u": "https://www.lecourrierdeShanghai.com",
    "c": "Médias",
    "d": "Publication francophone historique à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Asialyst - Francophone",
    "u": "https://www.asialyst.com/fr",
    "c": "Médias",
    "d": "Média francophone d'analyse sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Française en Chine (CCIFC)",
    "u": "https://www.ccifc.org",
    "c": "Commerce",
    "d": "Chambre de commerce française en Chine.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce France-Chine",
    "u": "https://www.france-chine.org",
    "c": "Commerce",
    "d": "Organisation pour les échanges commerciaux France-Chine.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Franco-Chinoise de Shanghai",
    "u": "https://www.ccfcs.org.cn",
    "c": "Commerce",
    "d": "Chambre de commerce franco-chinoise à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Franco-Chinoise de Pékin",
    "u": "https://www.ccfcbp.org",
    "c": "Commerce",
    "d": "Chambre de commerce franco-chinoise à Pékin.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Française au Vietnam",
    "u": "https://www.ccifv.org",
    "c": "Commerce",
    "d": "Chambre de commerce française au Vietnam.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Française au Japon",
    "u": "https://www.ccifj.or.jp/fr",
    "c": "Commerce",
    "d": "Chambre de commerce française au Japon.",
    "date": "2025"
  },
  {
    "n": "Chambre de Commerce Française en Corée",
    "u": "https://www.ccfckorea.org/fr",
    "c": "Commerce",
    "d": "Chambre de commerce française en Corée du Sud.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche sur l'Asie de l'Est (IFRAE)",
    "u": "https://www.ifrae.cnrs.fr",
    "c": "Recherche",
    "d": "Institut français de recherche sur l'Asie de l'Est.",
    "date": "2025"
  },
  {
    "n": "Centre d'Études Français sur la Chine Contemporaine (CEFC)",
    "u": "https://www.cefc.com.hk",
    "c": "Recherche",
    "d": "Centre de recherche français basé à Hong Kong.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Recherche sur l'Asie de l'Est (IFRAE)",
    "u": "https://ifrae.univ-lille.fr",
    "c": "Recherche",
    "d": "Institut de recherche français spécialisé sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "École Française d'Extrême-Orient (EFEO)",
    "u": "https://www.efeo.fr",
    "c": "Recherche",
    "d": "Institution française de recherche sur les civilisations asiatiques.",
    "date": "2025"
  },
  {
    "n": "Centre Asie du Sud-Est (CASE)",
    "u": "https://case.cnrs.fr",
    "c": "Recherche",
    "d": "Centre de recherche français sur l'Asie du Sud-Est.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche sur le Japon (IRJ)",
    "u": "https://irj.cnrs.fr",
    "c": "Recherche",
    "d": "Institut français de recherche sur le Japon.",
    "date": "2025"
  },
  {
    "n": "Atout France - Bureau Chine",
    "u": "https://cn.rendezvousenfrance.com",
    "c": "Tourisme",
    "d": "Office du tourisme français en Chine.",
    "date": "2025"
  },
  {
    "n": "Musée Guimet - Arts Asiatiques",
    "u": "https://www.guimet.fr",
    "c": "Culture",
    "d": "Musée national des arts asiatiques à Paris.",
    "date": "2025"
  },
  {
    "n": "Cité de la Céramique - Sèvres",
    "u": "https://www.sevresciteceramique.fr",
    "c": "Culture",
    "d": "Institution française avec collection d'arts asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée Cernuschi - Arts de l'Asie",
    "u": "https://www.cernuschi.paris.fr",
    "c": "Culture",
    "d": "Musée parisien consacré aux arts asiatiques.",
    "date": "2025"
  },
  {
    "n": "Société Asiatique",
    "u": "https://www.societe-asiatique.fr",
    "c": "Culture",
    "d": "Plus ancienne société savante française sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Éditions You-Feng",
    "u": "https://www.you-feng.com",
    "c": "Édition",
    "d": "Éditeur français spécialisé dans les livres sur la Chine et l'Asie.",
    "date": "2025"
  },
  {
    "n": "Librairie Le Phénix (Paris)",
    "u": "https://www.librairielephenix.fr",
    "c": "Librairie",
    "d": "Librairie parisienne spécialisée sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Librairie You-Feng (Paris)",
    "u": "https://www.librairiefrancaisechine.com",
    "c": "Librairie",
    "d": "Librairie spécialisée dans les livres sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Publications de la Société d'Études Japonaises",
    "u": "https://www.sej-etudesjaponaises.org",
    "c": "Édition",
    "d": "Revue française d'études japonaises.",
    "date": "2025"
  },
  {
    "n": "Revue Persée - Asie",
    "u": "https://www.persee.fr/collection/asie",
    "c": "Édition",
    "d": "Collections de revues scientifiques françaises sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Français de Chine",
    "u": "https://www.afc-chine.com",
    "c": "Association",
    "d": "Association des résidents français en Chine.",
    "date": "2025"
  },
  {
    "n": "Union des Français de l'Étranger (UFE) Asie",
    "u": "https://www.ufe.org/asie",
    "c": "Association",
    "d": "Union des Français établis hors de France, section Asie.",
    "date": "2025"
  },
  {
    "n": "Association France-Asie",
    "u": "https://www.france-asie.org",
    "c": "Association",
    "d": "Association française pour les échanges avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Société des Amis du Musée Guimet",
    "u": "https://www.amis-guimet.fr",
    "c": "Association",
    "d": "Association des amis du musée des arts asiatiques.",
    "date": "2025"
  },
  {
    "n": "Association pour l'Étude de la Langue et de la Civilisation Japonaises",
    "u": "https://www.aelcj.org",
    "c": "Association",
    "d": "Association française d'études japonaises.",
    "date": "2025"
  },
  {
    "n": "Hôpital Français de Pékin",
    "u": "https://www.hopitalfrancaispekin.com",
    "c": "Santé",
    "d": "Hôpital francophone à Pékin.",
    "date": "2025"
  },
  {
    "n": "Hôpital International Saint-Michel (Shanghai)",
    "u": "https://www.shsmh.com/fr",
    "c": "Santé",
    "d": "Hôpital international à Shanghai avec services en français.",
    "date": "2025"
  },
  {
    "n": "Clinique Française de Tokyo",
    "u": "https://www.cftky.com/fr",
    "c": "Santé",
    "d": "Clinique médicale francophone à Tokyo.",
    "date": "2025"
  },
  {
    "n": "Centre Médical International de Bangkok",
    "u": "https://www.bumrungrad.com/fr",
    "c": "Santé",
    "d": "Hôpital thaïlandais avec services en français.",
    "date": "2025"
  },
  {
    "n": "Hôpital Français de Hanoi",
    "u": "https://www.hfh.com.vn/fr",
    "c": "Santé",
    "d": "Hôpital francophone au Vietnam.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Pékin",
    "u": "https://www.lfip.net.cn",
    "c": "Éducation",
    "d": "École française à Pékin.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Shanghai",
    "u": "https://www.lyceeshanghai.com",
    "c": "Éducation",
    "d": "École française à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Lycée Français International de Hong Kong",
    "u": "https://www.lfis.edu.hk",
    "c": "Éducation",
    "d": "École française à Hong Kong.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Tokyo",
    "u": "https://www.lftokyo.org",
    "c": "Éducation",
    "d": "École française à Tokyo.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Séoul",
    "u": "https://www.lfseoul.org",
    "c": "Éducation",
    "d": "École française à Séoul.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Singapour",
    "u": "https://www.lfs.edu.sg",
    "c": "Éducation",
    "d": "École française à Singapour.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Bangkok",
    "u": "https://www.lfb.ac.th",
    "c": "Éducation",
    "d": "École française à Bangkok.",
    "date": "2025"
  },
  {
    "n": "Lycée Français de Hanoi",
    "u": "https://www.lfhanoi.edu.vn",
    "c": "Éducation",
    "d": "École française à Hanoi.",
    "date": "2025"
  },
  {
    "n": "BNP Paribas Chine",
    "u": "https://www.bnpparibas.com.cn/fr",
    "c": "Finance",
    "d": "Banque française en Chine, site en français.",
    "date": "2025"
  },
  {
    "n": "Société Générale Chine",
    "u": "https://www.societegenerale.chine.fr",
    "c": "Finance",
    "d": "Banque française en Chine.",
    "date": "2025"
  },
  {
    "n": "Crédit Agricole CIB Asie",
    "u": "https://www.ca-cib.com/asie-pacifique",
    "c": "Finance",
    "d": "Banque française en Asie-Pacifique.",
    "date": "2025"
  },
  {
    "n": "Natixis Asie",
    "u": "https://www.natixis.com/natixis/asie-pacifique",
    "c": "Finance",
    "d": "Banque française en Asie.",
    "date": "2025"
  },
  {
    "n": "AXA Asie",
    "u": "https://www.axa.com/fr/asie-pacifique",
    "c": "Assurance",
    "d": "Compagnie d'assurance française en Asie.",
    "date": "2025"
  },
  {
    "n": "Air France Chine",
    "u": "https://www.airfrance.com.cn",
    "c": "Transport",
    "d": "Compagnie aérienne française, site chinois.",
    "date": "2025"
  },
  {
    "n": "Air France Asie",
    "u": "https://www.airfrance.asia",
    "c": "Transport",
    "d": "Compagnie aérienne française pour l'Asie.",
    "date": "2025"
  },
  {
    "n": "SNCF International - Asie",
    "u": "https://www.sncf.com/fr/groupe/sncf-international/asie",
    "c": "Transport",
    "d": "Société ferroviaire française en Asie.",
    "date": "2025"
  },
  {
    "n": "CMA CGM Asie",
    "u": "https://www.cma-cgm.com/fr/asie",
    "c": "Transport",
    "d": "Armateur français, activités en Asie.",
    "date": "2025"
  },
  {
    "n": "Groupe ADP - Aéroports en Asie",
    "u": "https://www.adp.fr/fr/international/asie-pacifique",
    "c": "Transport",
    "d": "Gestionnaire d'aéroports français en Asie.",
    "date": "2025"
  },
  {
    "n": "Carrefour Chine",
    "u": "https://www.carrefour.cn/fr",
    "c": "Commerce",
    "d": "Enseigne française de grande distribution en Chine.",
    "date": "2025"
  },
  {
    "n": "Danone Chine",
    "u": "https://www.danone.cn/fr",
    "c": "Agroalimentaire",
    "d": "Groupe alimentaire français en Chine.",
    "date": "2025"
  },
  {
    "n": "L'Oréal Chine",
    "u": "https://www.lorealchina.com/fr",
    "c": "Cosmétique",
    "d": "Leader mondial des cosmétiques, site chinois en français.",
    "date": "2025"
  },
  {
    "n": "Sanofi Chine",
    "u": "https://www.sanofi.cn/fr",
    "c": "Pharmaceutique",
    "d": "Laboratoire pharmaceutique français en Chine.",
    "date": "2025"
  },
  {
    "n": "Michelin Chine",
    "u": "https://www.michelin.com.cn/fr",
    "c": "Automobile",
    "d": "Manufacturier de pneus français en Chine.",
    "date": "2025"
  },
  {
    "n": "Schneider Electric Chine",
    "u": "https://www.se.com/cn/fr",
    "c": "Énergie",
    "d": "Entreprise française d'énergie en Chine.",
    "date": "2025"
  },
  {
    "n": "Saint-Gobain Chine",
    "u": "https://www.saint-gobain.com.cn/fr",
    "c": "Construction",
    "d": "Manufacturier de matériaux de construction français en Chine.",
    "date": "2025"
  },
  {
    "n": "Veolia Chine",
    "u": "https://www.veolia.com.cn/fr",
    "c": "Environnement",
    "d": "Entreprise française de gestion de l'eau et des déchets en Chine.",
    "date": "2025"
  },
  {
    "n": "TotalEnergies Chine",
    "u": "https://www.totalenergies.cn/fr",
    "c": "Énergie",
    "d": "Compagnie énergétique française en Chine.",
    "date": "2025"
  },
  {
    "n": "Airbus Chine",
    "u": "https://www.airbus.com.cn/fr",
    "c": "Aéronautique",
    "d": "Constructeur aéronautique européen en Chine.",
    "date": "2025"
  },
  {
    "n": "Accor Hotels Asie-Pacifique",
    "u": "https://www.accor.com/asie-pacifique/fr",
    "c": "Hôtellerie",
    "d": "Groupe hôtelier français en Asie.",
    "date": "2025"
  },
  {
    "n": "Club Med Asie",
    "u": "https://www.clubmed.com/r/asie",
    "c": "Tourisme",
    "d": "Résort français en Asie.",
    "date": "2025"
  },
  {
    "n": "Airbnb Chine",
    "u": "https://www.airbnb.com.cn/fr",
    "c": "Hébergement",
    "d": "Plateforme de location, version chinoise en français.",
    "date": "2025"
  },
  {
    "n": "Capitaine Train (ex-Trainline) Asie",
    "u": "https://www.thetrainline.com/fr/asie",
    "c": "Transport",
    "d": "Service de réservation de trains, couverture Asie.",
    "date": "2025"
  },
  {
    "n": "Station F - Programme Asie",
    "u": "https://www.stationf.co/asie",
    "c": "Technologie",
    "d": "Incubateur français avec programme Asie.",
    "date": "2025"
  },
  {
    "n": "French Tech Chine",
    "u": "https://www.frenchtechchina.com",
    "c": "Technologie",
    "d": "Communauté des startups françaises en Chine.",
    "date": "2025"
  },
  {
    "n": "French Tech Tokyo",
    "u": "https://www.frenchtechtokyo.com",
    "c": "Technologie",
    "d": "Communauté tech française au Japon.",
    "date": "2025"
  },
  {
    "n": "French Tech Singapore",
    "u": "https://www.frenchtech.sg",
    "c": "Technologie",
    "d": "Hub tech français à Singapour.",
    "date": "2025"
  },
  {
    "n": "Capgemini Asie",
    "u": "https://www.capgemini.com/fr-fr/asie-pacifique",
    "c": "Technologie",
    "d": "Entreprise de services numériques française en Asie.",
    "date": "2025"
  },
  {
    "n": "Atos Asie",
    "u": "https://www.atos.net/fr/asie-pacifique",
    "c": "Technologie",
    "d": "Groupe français de services informatiques en Asie.",
    "date": "2025"
  },
  {
    "n": "Dassault Systèmes Asie",
    "u": "https://www.3ds.com/fr/asie-pacifique",
    "c": "Technologie",
    "d": "Éditeur français de logiciels 3D en Asie.",
    "date": "2025"
  },
  {
    "n": "Opéra de Shanghai - Coopération Française",
    "u": "https://www.shanghai-opera.com/fr",
    "c": "Arts",
    "d": "Opéra de Shanghai avec partenariats français.",
    "date": "2025"
  },
  {
    "n": "Musée d'Art de Pékin - Collection Française",
    "u": "https://www.namoc.org/fr",
    "c": "Arts",
    "d": "Musée d'art chinois avec œuvres françaises.",
    "date": "2025"
  },
  {
    "n": "Festival Croisements (France-Chine)",
    "u": "https://www.festivalcroisements.com",
    "c": "Culture",
    "d": "Festival culturel français en Chine.",
    "date": "2025"
  },
  {
    "n": "Alliance Française Film Festival (Chine)",
    "u": "https://www.afchine.org/festival-cinema",
    "c": "Cinéma",
    "d": "Festival du film français en Chine.",
    "date": "2025"
  },
  {
    "n": "Foire du Livre de Pékin - Pavillon Français",
    "u": "https://www.bibf.net/fr",
    "c": "Édition",
    "d": "Foire du livre avec présence française.",
    "date": "2025"
  },
  {
    "n": "Salon du Livre Francophone de Shanghai",
    "u": "https://www.salonlivreshanghai.com",
    "c": "Édition",
    "d": "Salon du livre francophone en Chine.",
    "date": "2025"
  },
  {
    "n": "Guide Michelin Chine",
    "u": "https://guide.michelin.com/cn/fr",
    "c": "Gastronomie",
    "d": "Guide gastronomique français en Chine.",
    "date": "2025"
  },
  {
    "n": "Le Cordon Bleu Asie",
    "u": "https://www.cordonbleu.edu/asie/fr",
    "c": "Gastronomie",
    "d": "École de cuisine française en Asie.",
    "date": "2025"
  },
  {
    "n": "École de Cuisine Alain Ducasse - Japon",
    "u": "https://www.ecolecuisine-alainducasse.com/japon",
    "c": "Gastronomie",
    "d": "École du chef français au Japon.",
    "date": "2025"
  },
  {
    "n": "Maison de la France Gourmande (Shanghai)",
    "u": "https://www.maisonfrancegourmande.com",
    "c": "Gastronomie",
    "d": "Centre de promotion de la gastronomie française en Chine.",
    "date": "2025"
  },
  {
    "n": "Salon du Chocolat Shanghai",
    "u": "https://www.salonduchocolat.com/shanghai/fr",
    "c": "Gastronomie",
    "d": "Événement français du chocolat en Chine.",
    "date": "2025"
  },
  {
    "n": "Tour de France - Édition Chine",
    "u": "https://www.letour.com/fr/chine",
    "c": "Sport",
    "d": "Événement cycliste français en Chine.",
    "date": "2025"
  },
  {
    "n": "Roland-Garros - Partenaires Chinois",
    "u": "https://www.rolandgarros.com/fr-fr/chine",
    "c": "Sport",
    "d": "Tournoi de tennis français, partenaires chinois.",
    "date": "2025"
  },
  {
    "n": "Paris Saint-Germain - Chine",
    "u": "https://www.psg.fr/chine",
    "c": "Sport",
    "d": "Club de football français, site chinois en français.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Football - Asie",
    "u": "https://www.fff.fr/asie",
    "c": "Sport",
    "d": "Fédération française de football, activités en Asie.",
    "date": "2025"
  },
  {
    "n": "Club Alpin Français - Section Asie",
    "u": "https://www.ffcam.fr/asie",
    "c": "Sport",
    "d": "Club d'alpinisme français en Asie.",
    "date": "2025"
  },
  {
    "n": "LVMH Chine",
    "u": "https://www.lvmh.com/asie-pacifique/chine",
    "c": "Mode",
    "d": "Groupe de luxe français en Chine.",
    "date": "2025"
  },
  {
    "n": "Kering Chine",
    "u": "https://www.kering.com/fr/asie-pacifique",
    "c": "Mode",
    "d": "Groupe de luxe français en Asie.",
    "date": "2025"
  },
  {
    "n": "Chanel Chine",
    "u": "https://www.chanel.com/fr_CN",
    "c": "Mode",
    "d": "Maison de luxe française, site chinois en français.",
    "date": "2025"
  },
  {
    "n": "Hermès Chine",
    "u": "https://www.hermes.com/cn/fr",
    "c": "Mode",
    "d": "Maison de luxe française en Chine.",
    "date": "2025"
  },
  {
    "n": "Cartier Chine",
    "u": "https://www.cartier.cn/fr-fr",
    "c": "Mode",
    "d": "Joallier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Dior Chine",
    "u": "https://www.dior.com/fr_fr/chine",
    "c": "Mode",
    "d": "Maison de mode française en Chine.",
    "date": "2025"
  },
  {
    "n": "Yves Saint Laurent Chine",
    "u": "https://www.ysl.com/fr-fr/chine",
    "c": "Mode",
    "d": "Marque française de luxe en Chine.",
    "date": "2025"
  },
  {
    "n": "Sephora Chine",
    "u": "https://www.sephora.cn/fr",
    "c": "Beauté",
    "d": "Enseigne française de beauté en Chine.",
    "date": "2025"
  },
  {
    "n": "Printemps Paris - Chine",
    "u": "https://www.printemps.com/fr/chine",
    "c": "Commerce",
    "d": "Grand magasin français, site chinois.",
    "date": "2025"
  },
  {
    "n": "Galeries Lafayette Chine",
    "u": "https://www.galerieslafayette.com.cn/fr",
    "c": "Commerce",
    "d": "Grand magasin français en Chine.",
    "date": "2025"
  },
  {
    "n": "WWF France - Programmes Asie",
    "u": "https://www.wwf.fr/asie",
    "c": "Écologie",
    "d": "Fondation écologique française en Asie.",
    "date": "2025"
  },
  {
    "n": "Greenpeace France - Campagnes Asie",
    "u": "https://www.greenpeace.fr/asie",
    "c": "Écologie",
    "d": "ONG environnementale française en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation Nicolas Hulot - Asie",
    "u": "https://www.fondation-nature-homme.org/asie",
    "c": "Écologie",
    "d": "Fondation écologique française en Asie.",
    "date": "2025"
  },
  {
    "n": "Agence Française de Développement (AFD) - Asie",
    "u": "https://www.afd.fr/fr/asie",
    "c": "Développement",
    "d": "Agence française de développement en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche pour le Développement (IRD) - Asie",
    "u": "https://www.ird.fr/asie",
    "c": "Recherche",
    "d": "Institut français de recherche pour le développement en Asie.",
    "date": "2025"
  },
  {
    "n": "Médecins Sans Frontières (MSF) Asie",
    "u": "https://www.msf.fr/asie",
    "c": "Humanitaire",
    "d": "ONG médicale française en Asie.",
    "date": "2025"
  },
  {
    "n": "Médecins du Monde Asie",
    "u": "https://www.medecinsdumonde.org/fr/asie",
    "c": "Humanitaire",
    "d": "ONG médicale française en Asie.",
    "date": "2025"
  },
  {
    "n": "Action Contre la Faim (ACF) Asie",
    "u": "https://www.actioncontrelafaim.org/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française de lutte contre la faim en Asie.",
    "date": "2025"
  },
  {
    "n": "Secours Populaire Français - Asie",
    "u": "https://www.secourspopulaire.fr/asie",
    "c": "Humanitaire",
    "d": "Association humanitaire française en Asie.",
    "date": "2025"
  },
  {
    "n": "Croix-Rouge Française - Asie",
    "u": "https://www.croix-rouge.fr/asie",
    "c": "Humanitaire",
    "d": "Association humanitaire française en Asie.",
    "date": "2025"
  },
  {
    "n": "Ambassade de France en Chine",
    "u": "https://cn.ambafrance.org",
    "c": "Diplomatie",
    "d": "Site officiel de l'ambassade de France en Chine.",
    "date": "2025"
  },
  {
    "n": "Consulat Général de France à Shanghai",
    "u": "https://shanghai.consulfrance.org",
    "c": "Diplomatie",
    "d": "Consulat français à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Chine",
    "u": "https://www.institutfrancais-chine.com",
    "c": "Coopération",
    "d": "Institut français pour la coopération culturelle en Chine.",
    "date": "2025"
  },
  {
    "n": "Campus France Chine",
    "u": "https://www.chine.campusfrance.org",
    "c": "Éducation",
    "d": "Agence française pour la promotion de l'enseignement supérieur en Chine.",
    "date": "2025"
  },
  {
    "n": "France Alumni Chine",
    "u": "https://chine.francealumni.fr",
    "c": "Éducation",
    "d": "Réseau des anciens étudiants français en Chine.",
    "date": "2025"
  },
  {
    "n": "Safran Chine",
    "u": "https://www.safran.cn/fr",
    "c": "Aéronautique",
    "d": "Groupe aéronautique français en Chine.",
    "date": "2025"
  },
  {
    "n": "Thales Chine",
    "u": "https://www.thalesgroup.com/fr/chine",
    "c": "Défense",
    "d": "Groupe français de défense et électronique en Chine.",
    "date": "2025"
  },
  {
    "n": "Air Liquide Chine",
    "u": "https://www.airliquide.com.cn/fr",
    "c": "Industrie",
    "d": "Groupe français de gaz industriels en Chine.",
    "date": "2025"
  },
  {
    "n": "Vinci Asie",
    "u": "https://www.vinci.com/vinci.nsf/fr/asie-pacifique",
    "c": "BTP",
    "d": "Groupe français de BTP en Asie.",
    "date": "2025"
  },
  {
    "n": "Bouygues Construction Asie",
    "u": "https://www.bouygues-construction.com/asie",
    "c": "BTP",
    "d": "Groupe français de construction en Asie.",
    "date": "2025"
  },
  {
    "n": "EDF Asie",
    "u": "https://www.edf.fr/fr/asie-pacifique",
    "c": "Énergie",
    "d": "Électricien français en Asie.",
    "date": "2025"
  },
  {
    "n": "Engie Asie",
    "u": "https://www.engie.com/fr/asie-pacifique",
    "c": "Énergie",
    "d": "Groupe énergétique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Alstom Chine",
    "u": "https://www.alstom.com/cn/fr",
    "c": "Transport",
    "d": "Constructeur ferroviaire français en Chine.",
    "date": "2025"
  },
  {
    "n": "Invivo Asie",
    "u": "https://www.invivo-group.com/fr/asie",
    "c": "Agriculture",
    "d": "Coopérative agricole française en Asie.",
    "date": "2025"
  },
  {
    "n": "Limagrain Asie",
    "u": "https://www.limagrain.com/fr/asie",
    "c": "Agriculture",
    "d": "Coopérative semencière française en Asie.",
    "date": "2025"
  },
  {
    "n": "Avril Asie",
    "u": "https://www.groupeavril.com/fr/asie",
    "c": "Agroalimentaire",
    "d": "Groupe agroalimentaire français en Asie.",
    "date": "2025"
  },
  {
    "n": "Sodiaal Asie",
    "u": "https://www.sodiaal.fr/fr/asie",
    "c": "Agroalimentaire",
    "d": "Coopérative laitière française en Asie.",
    "date": "2025"
  },
  {
    "n": "Tereos Asie",
    "u": "https://www.tereos.com/fr/asie",
    "c": "Agroalimentaire",
    "d": "Coopérative sucrière française en Asie.",
    "date": "2025"
  },
  {
    "n": "Groupama Asie",
    "u": "https://www.groupama.com/fr/asie",
    "c": "Assurance",
    "d": "Groupe d'assurance français en Asie.",
    "date": "2025"
  },
  {
    "n": "CNP Assurances Asie",
    "u": "https://www.cnp.fr/fr/asie",
    "c": "Assurance",
    "d": "Assureur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Euler Hermes Asie",
    "u": "https://www.eulerhermes.com/fr_FR/asie-pacifique.html",
    "c": "Assurance",
    "d": "Assureur-crédit français en Asie.",
    "date": "2025"
  },
  {
    "n": "Covéa Asie",
    "u": "https://www.covea.fr/fr/asie",
    "c": "Assurance",
    "d": "Groupe mutualiste d'assurance français en Asie.",
    "date": "2025"
  },
  {
    "n": "Mazars Chine",
    "u": "https://www.mazars.cn/Home/fr",
    "c": "Conseil",
    "d": "Cabinet d'audit et conseil français en Chine.",
    "date": "2025"
  },
  {
    "n": "Grant Thornton Chine",
    "u": "https://www.grantthornton.cn/fr",
    "c": "Conseil",
    "d": "Cabinet d'audit international d'origine française en Chine.",
    "date": "2025"
  },
  {
    "n": "KPMG France - Chine",
    "u": "https://www.kpmg.fr/chine",
    "c": "Conseil",
    "d": "Cabinet d'audit, présence française en Chine.",
    "date": "2025"
  },
  {
    "n": "EY France - Asie",
    "u": "https://www.ey.com/fr_fr/asie-pacifique",
    "c": "Conseil",
    "d": "Cabinet d'audit, équipe française en Asie.",
    "date": "2025"
  },
  {
    "n": "PwC France - Asie",
    "u": "https://www.pwc.fr/fr/asie-pacifique",
    "c": "Conseil",
    "d": "Cabinet d'audit, experts français en Asie.",
    "date": "2025"
  },
  {
    "n": "Deloitte France - Asie",
    "u": "https://www.deloitte.fr/fr/asie-pacifique",
    "c": "Conseil",
    "d": "Cabinet d'audit, présence française en Asie.",
    "date": "2025"
  },
  {
    "n": "Accenture France - Asie",
    "u": "https://www.accenture.com/fr-fr/asie-pacifique",
    "c": "Conseil",
    "d": "Cabinet de conseil en technologie, équipe française en Asie.",
    "date": "2025"
  },
  {
    "n": "Wavestone Asie",
    "u": "https://www.wavestone.com/fr/asie",
    "c": "Conseil",
    "d": "Cabinet de conseil français en Asie.",
    "date": "2025"
  },
  {
    "n": "Kurt Salmon (Accenture) Asie",
    "u": "https://www.accenture.com/fr-fr/asie-pacifique/industrie/commerce",
    "c": "Conseil",
    "d": "Cabinet de conseil en retail français en Asie.",
    "date": "2025"
  },
  {
    "n": "CNRS Asie",
    "u": "https://www.cnrs.fr/fr/asie",
    "c": "Recherche",
    "d": "Centre national de la recherche scientifique français en Asie.",
    "date": "2025"
  },
  {
    "n": "INSERM Asie",
    "u": "https://www.inserm.fr/fr/asie",
    "c": "Recherche",
    "d": "Institut français de recherche médicale en Asie.",
    "date": "2025"
  },
  {
    "n": "INRAE Asie",
    "u": "https://www.inrae.fr/asie",
    "c": "Recherche",
    "d": "Institut français de recherche agronomique en Asie.",
    "date": "2025"
  },
  {
    "n": "IRD Asie du Sud-Est",
    "u": "https://www.ird.fr/asie-du-sud-est",
    "c": "Recherche",
    "d": "Institut français de recherche pour le développement en Asie du Sud-Est.",
    "date": "2025"
  },
  {
    "n": "CIRAD Asie",
    "u": "https://www.cirad.fr/asie",
    "c": "Recherche",
    "d": "Centre français de recherche agronomique pour le développement en Asie.",
    "date": "2025"
  },
  {
    "n": "IFPEN Asie",
    "u": "https://www.ifpenergiesnouvelles.fr/asie",
    "c": "Recherche",
    "d": "Institut français du pétrole et des énergies nouvelles en Asie.",
    "date": "2025"
  },
  {
    "n": "CEA Asie",
    "u": "https://www.cea.fr/fr/asie",
    "c": "Recherche",
    "d": "Commissariat à l'énergie atomique français en Asie.",
    "date": "2025"
  },
  {
    "n": "ONERA Asie",
    "u": "https://www.onera.fr/fr/asie",
    "c": "Recherche",
    "d": "Office français d'études et de recherches aérospatiales en Asie.",
    "date": "2025"
  },
  {
    "n": "ANSES Asie",
    "u": "https://www.anses.fr/fr/asie",
    "c": "Recherche",
    "d": "Agence française de sécurité sanitaire en Asie.",
    "date": "2025"
  },
  {
    "n": "BRGM Asie",
    "u": "https://www.brgm.fr/fr/asie",
    "c": "Recherche",
    "d": "Service géologique national français en Asie.",
    "date": "2025"
  },
  {
    "n": "Ateliers Jean Nouvel - Projets Asie",
    "u": "https://www.jeannouvel.com/fr/asie",
    "c": "Architecture",
    "d": "Architecte français, projets en Asie.",
    "date": "2025"
  },
  {
    "n": "Christian de Portzamparc - Asie",
    "u": "https://www.chdeportzamparc.com/fr/asie",
    "c": "Architecture",
    "d": "Architecte français, réalisations en Asie.",
    "date": "2025"
  },
  {
    "n": "Dominique Perrault Architecture - Asie",
    "u": "https://www.perraultarchitecture.com/fr/asie",
    "c": "Architecture",
    "d": "Agence d'architecture française en Asie.",
    "date": "2025"
  },
  {
    "n": "Valode & Pistre - Asie",
    "u": "https://www.valode-pistre.com/fr/asie",
    "c": "Architecture",
    "d": "Agence d'architecture française, projets asiatiques.",
    "date": "2025"
  },
  {
    "n": "AREP (SNCF) - Asie",
    "u": "https://www.arep.fr/fr/asie",
    "c": "Architecture",
    "d": "Groupe d'architecture français, gares en Asie.",
    "date": "2025"
  },
  {
    "n": "Reed Exhibitions Chine",
    "u": "https://www.reedexpo.com.cn/fr",
    "c": "Événementiel",
    "d": "Organisateur de salons français en Chine.",
    "date": "2025"
  },
  {
    "n": "Comexposium Asie",
    "u": "https://www.comexposium.com/fr/asie",
    "c": "Événementiel",
    "d": "Organisateur de salons français en Asie.",
    "date": "2025"
  },
  {
    "n": "GL events Chine",
    "u": "https://www.glevents.com/fr/chine",
    "c": "Événementiel",
    "d": "Organisateur d'événements français en Chine.",
    "date": "2025"
  },
  {
    "n": "Viparis International - Asie",
    "u": "https://www.viparis.com/fr/international/asie",
    "c": "Événementiel",
    "d": "Gestionnaire de lieux d'événements français en Asie.",
    "date": "2025"
  },
  {
    "n": "Palais des Congrès de Paris - Asie",
    "u": "https://www.palaisdescongresdeparis.fr/fr/asie",
    "c": "Événementiel",
    "d": "Centre de congrès français, partenariats asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée du Louvre - Coopération Chine",
    "u": "https://www.louvre.fr/fr/chine",
    "c": "Musée",
    "d": "Musée français, projets avec la Chine.",
    "date": "2025"
  },
  {
    "n": "Musée d'Orsay - Asie",
    "u": "https://www.musee-orsay.fr/fr/asie",
    "c": "Musée",
    "d": "Musée français, échanges avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Centre Pompidou - Shanghai",
    "u": "https://www.centrepompidou.fr/fr/shanghai",
    "c": "Musée",
    "d": "Antenne du musée français à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Fondation Louis Vuitton - Asie",
    "u": "https://www.fondationlouisvuitton.fr/fr/asie",
    "c": "Musée",
    "d": "Fondation d'art française, expositions en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut du Monde Arabe - Asie",
    "u": "https://www.imarabe.org/fr/asie",
    "c": "Culture",
    "d": "Institut français, programmes culturels en Asie.",
    "date": "2025"
  },
  {
    "n": "Comédie-Française - Tournées Asie",
    "u": "https://www.comedie-francaise.fr/fr/asie",
    "c": "Théâtre",
    "d": "Théâtre national français, tournées en Asie.",
    "date": "2025"
  },
  {
    "n": "Opéra National de Paris - Asie",
    "u": "https://www.operadeparis.fr/fr/asie",
    "c": "Opéra",
    "d": "Opéra français, collaborations asiatiques.",
    "date": "2025"
  },
  {
    "n": "Théâtre du Châtelet - Asie",
    "u": "https://www.chatelet.com/fr/asie",
    "c": "Théâtre",
    "d": "Théâtre parisien, productions en Asie.",
    "date": "2025"
  },
  {
    "n": "Festival d'Avignon - Asie",
    "u": "https://www.festival-avignon.com/fr/asie",
    "c": "Festival",
    "d": "Festival de théâtre français, présence en Asie.",
    "date": "2025"
  },
  {
    "n": "Théâtre de la Ville - Asie",
    "u": "https://www.theatredelaville-paris.com/fr/asie",
    "c": "Théâtre",
    "d": "Théâtre parisien, échanges avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Ubisoft Chine",
    "u": "https://www.ubisoft.com.cn/fr-fr",
    "c": "Jeux Vidéo",
    "d": "Éditeur français de jeux vidéo, studio en Chine.",
    "date": "2025"
  },
  {
    "n": "Gameloft Chine",
    "u": "https://www.gameloft.com/cn/fr",
    "c": "Jeux Vidéo",
    "d": "Studio français de jeux mobiles en Chine.",
    "date": "2025"
  },
  {
    "n": "Focus Home Interactive - Asie",
    "u": "https://www.focus-entmt.com/fr/asie",
    "c": "Jeux Vidéo",
    "d": "Éditeur français de jeux vidéo en Asie.",
    "date": "2025"
  },
  {
    "n": "Nacon - Distribution Asie",
    "u": "https://www.nacongaming.com/fr/asie",
    "c": "Jeux Vidéo",
    "d": "Éditeur français de jeux vidéo, distribution asiatique.",
    "date": "2025"
  },
  {
    "n": "Microids - Asie",
    "u": "https://www.microids.com/fr/asie",
    "c": "Jeux Vidéo",
    "d": "Éditeur français de jeux vidéo en Asie.",
    "date": "2025"
  },
  {
    "n": "Ankama - Jeux en Chine",
    "u": "https://www.ankama.com/fr/chine",
    "c": "Jeux Vidéo",
    "d": "Studio français de jeux en ligne en Chine.",
    "date": "2025"
  },
  {
    "n": "Voodoo - Asie",
    "u": "https://www.voodoo.io/fr/asie",
    "c": "Jeux Vidéo",
    "d": "Studio français de jeux mobiles hyper-casual en Asie.",
    "date": "2025"
  },
  {
    "n": "Renault Chine",
    "u": "https://www.renault.com.cn/fr",
    "c": "Automobile",
    "d": "Constructeur automobile français en Chine.",
    "date": "2025"
  },
  {
    "n": "Peugeot Chine",
    "u": "https://www.peugeot.com.cn/fr",
    "c": "Automobile",
    "d": "Marque automobile française en Chine.",
    "date": "2025"
  },
  {
    "n": "Citroën Chine",
    "u": "https://www.citroen.com.cn/fr",
    "c": "Automobile",
    "d": "Constructeur automobile français en Chine.",
    "date": "2025"
  },
  {
    "n": "DS Automobiles Chine",
    "u": "https://www.dsautomobiles.com.cn/fr",
    "c": "Automobile",
    "d": "Marque premium française en Chine.",
    "date": "2025"
  },
  {
    "n": "Bugatti - Asie",
    "u": "https://www.bugatti.com/fr/asie",
    "c": "Automobile",
    "d": "Constructeur de voitures de luxe français en Asie.",
    "date": "2025"
  },
  {
    "n": "Alpine - Asie",
    "u": "https://www.alpinecars.com/fr/asie",
    "c": "Automobile",
    "d": "Marque sportive française en Asie.",
    "date": "2025"
  },
  {
    "n": "Bénéteau Asie",
    "u": "https://www.beneteau.com/fr/asie",
    "c": "Nautisme",
    "d": "Constructeur nautique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Jeanneau Asie",
    "u": "https://www.jeanneau.com/fr/asie",
    "c": "Nautisme",
    "d": "Constructeur de bateaux français en Asie.",
    "date": "2025"
  },
  {
    "n": "Lagoon Catamarans - Asie",
    "u": "https://www.cata-lagoon.com/fr/asie",
    "c": "Nautisme",
    "d": "Constructeur de catamarans français en Asie.",
    "date": "2025"
  },
  {
    "n": "Fountaine Pajot - Asie",
    "u": "https://www.fountaine-pajot.com/fr/asie",
    "c": "Nautisme",
    "d": "Constructeur de multicoques français en Asie.",
    "date": "2025"
  },
  {
    "n": "Couach Yachts - Asie",
    "u": "https://www.couach.com/fr/asie",
    "c": "Nautisme",
    "d": "Chantier naval français en Asie.",
    "date": "2025"
  },
  {
    "n": "Dufour Yachts - Asie",
    "u": "https://www.dufour-yachts.com/fr/asie",
    "c": "Nautisme",
    "d": "Constructeur de voiliers français en Asie.",
    "date": "2025"
  },
  {
    "n": "Airbus Helicopters Chine",
    "u": "https://www.airbushelicopters.cn/fr",
    "c": "Aéronautique",
    "d": "Constructeur d'hélicoptères français en Chine.",
    "date": "2025"
  },
  {
    "n": "Dassault Aviation - Asie",
    "u": "https://www.dassault-aviation.com/fr/asie",
    "c": "Aéronautique",
    "d": "Constructeur aéronautique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Arianespace - Lancements Asie",
    "u": "https://www.arianespace.com/fr/asie",
    "c": "Spatial",
    "d": "Société de lancement spatial française en Asie.",
    "date": "2025"
  },
  {
    "n": "CNES - Coopération Asie",
    "u": "https://www.cnes.fr/fr/asie",
    "c": "Spatial",
    "d": "Agence spatiale française en Asie.",
    "date": "2025"
  },
  {
    "n": "Thales Alenia Space - Asie",
    "u": "https://www.thalesgroup.com/fr/space/asie",
    "c": "Spatial",
    "d": "Constructeur spatial français en Asie.",
    "date": "2025"
  },
  {
    "n": "L'Occitane en Provence - Chine",
    "u": "https://www.loccitane.com.cn/fr-fr",
    "c": "Cosmétique",
    "d": "Marque de cosmétiques française en Chine.",
    "date": "2025"
  },
  {
    "n": "Caudalie - Asie",
    "u": "https://www.caudalie.com/fr/asie",
    "c": "Cosmétique",
    "d": "Marque de cosmétiques français en Asie.",
    "date": "2025"
  },
  {
    "n": "Nuxe - Chine",
    "u": "https://www.nuxe.com.cn/fr",
    "c": "Cosmétique",
    "d": "Marque de cosmétiques française en Chine.",
    "date": "2025"
  },
  {
    "n": "Bioderma - Asie",
    "u": "https://www.bioderma.com/fr/asie",
    "c": "Cosmétique",
    "d": "Laboratoire dermatologique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Avene - Chine",
    "u": "https://www.avene.cn/fr",
    "c": "Cosmétique",
    "d": "Marque de soins dermatologiques française en Chine.",
    "date": "2025"
  },
  {
    "n": "La Roche-Posay - Asie",
    "u": "https://www.laroche-posay.com.cn/fr",
    "c": "Cosmétique",
    "d": "Marque de soins de la peau française en Asie.",
    "date": "2025"
  },
  {
    "n": "Vichy - Chine",
    "u": "https://www.vichy.com.cn/fr",
    "c": "Cosmétique",
    "d": "Marque de soins dermatologiques française en Chine.",
    "date": "2025"
  },
  {
    "n": "Clarins - Asie",
    "u": "https://www.clarins.com.cn/fr-fr",
    "c": "Cosmétique",
    "d": "Marque de cosmétiques française en Asie.",
    "date": "2025"
  },
  {
    "n": "Sisley - Chine",
    "u": "https://www.sisley-paris.com.cn/fr",
    "c": "Cosmétique",
    "d": "Marque de cosmétiques de luxe française en Chine.",
    "date": "2025"
  },
  {
    "n": "Guerlain - Asie",
    "u": "https://www.guerlain.com/cn/fr-fr",
    "c": "Parfum",
    "d": "Maison de parfums française en Asie.",
    "date": "2025"
  },
  {
    "n": "Chanel Parfums - Chine",
    "u": "https://www.chanel.com/fr_CN/parfums",
    "c": "Parfum",
    "d": "Parfums français en Chine.",
    "date": "2025"
  },
  {
    "n": "Dior Parfums - Asie",
    "u": "https://www.dior.com/fr_fr/parfums",
    "c": "Parfum",
    "d": "Parfums français en Asie.",
    "date": "2025"
  },
  {
    "n": "Jean-Paul Gaultier - Asie",
    "u": "https://www.jeanpaulgaultier.com/fr/asie",
    "c": "Parfum",
    "d": "Parfumeur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Annick Goutal - Chine",
    "u": "https://www.annickgoutal.com/fr/chine",
    "c": "Parfum",
    "d": "Maison de parfums française en Chine.",
    "date": "2025"
  },
  {
    "n": "Francis Kurkdjian - Asie",
    "u": "https://www.franciskurkdjian.com/fr/asie",
    "c": "Parfum",
    "d": "Parfumeur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Bordeaux Chine",
    "u": "https://www.bordeaux.com/fr/chine",
    "c": "Vin",
    "d": "Vins de Bordeaux en Chine.",
    "date": "2025"
  },
  {
    "n": "Bourgogne Wines - Asie",
    "u": "https://www.bourgogne-wines.com/fr/asie",
    "c": "Vin",
    "d": "Vins de Bourgogne en Asie.",
    "date": "2025"
  },
  {
    "n": "Champagne - Marché Chinois",
    "u": "https://www.champagne.fr/fr/chine",
    "c": "Vin",
    "d": "Champagnes français en Chine.",
    "date": "2025"
  },
  {
    "n": "Cognac - Asie",
    "u": "https://www.cognac.fr/fr/asie",
    "c": "Spiritueux",
    "d": "Cognac français en Asie.",
    "date": "2025"
  },
  {
    "n": "Armagnac - Chine",
    "u": "https://www.armagnac.fr/fr/chine",
    "c": "Spiritueux",
    "d": "Armagnac français en Chine.",
    "date": "2025"
  },
  {
    "n": "Calvados - Asie",
    "u": "https://www.calvados.fr/fr/asie",
    "c": "Spiritueux",
    "d": "Calvados français en Asie.",
    "date": "2025"
  },
  {
    "n": "Pernod Ricard Chine",
    "u": "https://www.pernod-ricard-china.com/fr",
    "c": "Spiritueux",
    "d": "Groupe français de spiritueux en Chine.",
    "date": "2025"
  },
  {
    "n": "LVMH Vins & Spiritueux - Asie",
    "u": "https://www.lvmh.com/les-maisons/vins-spiritueux/asie",
    "c": "Spiritueux",
    "d": "Division vins et spiritueux de LVMH en Asie.",
    "date": "2025"
  },
  {
    "n": "Maison Louis Latour - Asie",
    "u": "https://www.louislatour.com/fr/asie",
    "c": "Vin",
    "d": "Négociant-viniculteur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Domaines Barons de Rothschild - Chine",
    "u": "https://www.lafite.com/fr/chine",
    "c": "Vin",
    "d": "Producteur de vins français en Chine.",
    "date": "2025"
  },
  {
    "n": "CNIEL (Centre National Interprofessionnel de l'Économie Laitière) - Asie",
    "u": "https://www.cniel.com/fr/asie",
    "c": "Agroalimentaire",
    "d": "Interprofession laitière française en Asie.",
    "date": "2025"
  },
  {
    "n": "Fromages de France - Chine",
    "u": "https://www.fromagesdefrance.com/fr/chine",
    "c": "Agroalimentaire",
    "d": "Promotion des fromages français en Chine.",
    "date": "2025"
  },
  {
    "n": "Roquefort - Asie",
    "u": "https://www.roquefort.fr/fr/asie",
    "c": "Agroalimentaire",
    "d": "Fromage français AOP en Asie.",
    "date": "2025"
  },
  {
    "n": "Comté - Chine",
    "u": "https://www.comte.com/fr/chine",
    "c": "Agroalimentaire",
    "d": "Fromage français AOP en Chine.",
    "date": "2025"
  },
  {
    "n": "Camembert de Normandie - Asie",
    "u": "https://www.camembert-de-normandie.com/fr/asie",
    "c": "Agroalimentaire",
    "d": "Fromage français AOP en Asie.",
    "date": "2025"
  },
  {
    "n": "Brie de Meaux - Chine",
    "u": "https://www.briedemeaux.com/fr/chine",
    "c": "Agroalimentaire",
    "d": "Fromage français AOP en Chine.",
    "date": "2025"
  },
  {
    "n": "Groupe SEB Chine",
    "u": "https://www.groupeseb.com/fr/chine",
    "c": "Électroménager",
    "d": "Fabricant français de petit électroménager en Chine.",
    "date": "2025"
  },
  {
    "n": "Moulinex - Asie",
    "u": "https://www.moulinex.fr/fr/asie",
    "c": "Électroménager",
    "d": "Marque française d'électroménager en Asie.",
    "date": "2025"
  },
  {
    "n": "Tefal - Chine",
    "u": "https://www.tefal.com.cn/fr",
    "c": "Électroménager",
    "d": "Marque française d'ustensiles de cuisine en Chine.",
    "date": "2025"
  },
  {
    "n": "Rowenta - Asie",
    "u": "https://www.rowenta.com/fr/asie",
    "c": "Électroménager",
    "d": "Marque française d'appareils ménagers en Asie.",
    "date": "2025"
  },
  {
    "n": "Krups - Chine",
    "u": "https://www.krups.com.cn/fr",
    "c": "Électroménager",
    "d": "Marque française d'appareils électroménagers en Chine.",
    "date": "2025"
  },
  {
    "n": "Sothys - Chine",
    "u": "https://www.sothys.com.cn/fr",
    "c": "Beauté",
    "d": "Institut de beauté français en Chine.",
    "date": "2025"
  },
  {
    "n": "LPG - Asie",
    "u": "https://www.lpg.com/fr/asie",
    "c": "Beauté",
    "d": "Équipements de soins esthétiques français en Asie.",
    "date": "2025"
  },
  {
    "n": "Cinq Mondes Spa - Asie",
    "u": "https://www.cinqmondes.com/fr/asie",
    "c": "Bien-être",
    "d": "Institut de spa français en Asie.",
    "date": "2025"
  },
  {
    "n": "Anne Sémonin - Chine",
    "u": "https://www.annesemonin.com/fr/chine",
    "c": "Beauté",
    "d": "Marque française de soins spa en Chine.",
    "date": "2025"
  },
  {
    "n": "Talika - Asie",
    "u": "https://www.talika.com/fr/asie",
    "c": "Beauté",
    "d": "Marque française de soins des yeux en Asie.",
    "date": "2025"
  },
  {
    "n": "Petit Bateau - Chine",
    "u": "https://www.petit-bateau.com.cn/fr",
    "c": "Mode",
    "d": "Marque française de vêtements pour enfants en Chine.",
    "date": "2025"
  },
  {
    "n": "Jacadi - Asie",
    "u": "https://www.jacadi.fr/fr/asie",
    "c": "Mode",
    "d": "Marque française de mode enfant en Asie.",
    "date": "2025"
  },
  {
    "n": "Catimini - Chine",
    "u": "https://www.catimini.com/fr/chine",
    "c": "Mode",
    "d": "Marque française de vêtements pour enfants en Chine.",
    "date": "2025"
  },
  {
    "n": "Du Pareil au Même - Asie",
    "u": "https://www.dpam.com/fr/asie",
    "c": "Mode",
    "d": "Marque française de vêtements pour enfants en Asie.",
    "date": "2025"
  },
  {
    "n": "Tartine et Chocolat - Chine",
    "u": "https://www.tartine-et-chocolat.com/fr/chine",
    "c": "Mode",
    "d": "Marque française de layette et vêtements enfants en Chine.",
    "date": "2025"
  },
  {
    "n": "Mustela - Asie",
    "u": "https://www.mustela.com/fr/asie",
    "c": "Puériculture",
    "d": "Marque française de soins pour bébé en Asie.",
    "date": "2025"
  },
  {
    "n": "Bébé Confort - Chine",
    "u": "https://www.bebeconfort.com/fr/chine",
    "c": "Puériculture",
    "d": "Marque française de puériculture en Chine.",
    "date": "2025"
  },
  {
    "n": "Smoby - Chine",
    "u": "https://www.smoby.com/fr/chine",
    "c": "Jouets",
    "d": "Fabricant français de jouets en Chine.",
    "date": "2025"
  },
  {
    "n": "Mega Brands - Asie",
    "u": "https://www.megabrands.com/fr/asie",
    "c": "Jouets",
    "d": "Fabricant français de jouets de construction en Asie.",
    "date": "2025"
  },
  {
    "n": "Doudou et Compagnie - Chine",
    "u": "https://www.doudou-et-compagnie.com/fr/chine",
    "c": "Jouets",
    "d": "Marque française de peluches en Chine.",
    "date": "2025"
  },
  {
    "n": "Sentosphère - Asie",
    "u": "https://www.sentosphere.com/fr/asie",
    "c": "Jouets",
    "d": "Marque française de jeux créatifs en Asie.",
    "date": "2025"
  },
  {
    "n": "Vilac - Chine",
    "u": "https://www.vilac.com/fr/chine",
    "c": "Jouets",
    "d": "Fabricant français de jouets en bois en Chine.",
    "date": "2025"
  },
  {
    "n": "Djeco - Asie",
    "u": "https://www.djeco.com/fr/asie",
    "c": "Jouets",
    "d": "Éditeur français de jeux et jouets en Asie.",
    "date": "2025"
  },
  {
    "n": "Janod - Chine",
    "u": "https://www.janod.com/fr/chine",
    "c": "Jouets",
    "d": "Fabricant français de jouets en bois en Chine.",
    "date": "2025"
  },
  {
    "n": "Cartier Horlogerie - Chine",
    "u": "https://www.cartier.cn/fr-fr/collections/horlogerie",
    "c": "Horlogerie",
    "d": "Horloger français en Chine.",
    "date": "2025"
  },
  {
    "n": "Breguet - Asie",
    "u": "https://www.breguet.com/fr/asie",
    "c": "Horlogerie",
    "d": "Manufacture horlogère française en Asie.",
    "date": "2025"
  },
  {
    "n": "Jaeger-LeCoultre - Chine",
    "u": "https://www.jaeger-lecoultre.com/cn/fr",
    "c": "Horlogerie",
    "d": "Manufacture horlogère française en Chine.",
    "date": "2025"
  },
  {
    "n": "Van Cleef & Arpels - Asie",
    "u": "https://www.vancleefarpels.com/cn/fr.html",
    "c": "Bijoux",
    "d": "Maison française de joaillerie en Asie.",
    "date": "2025"
  },
  {
    "n": "Boucheron - Chine",
    "u": "https://www.boucheron.com/cn/fr.html",
    "c": "Bijoux",
    "d": "Joaillier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Mauboussin - Asie",
    "u": "https://www.mauboussin.com/fr/asie",
    "c": "Bijoux",
    "d": "Joaillier français en Asie.",
    "date": "2025"
  },
  {
    "n": "Repossi - Chine",
    "u": "https://www.repossi.com/fr/chine",
    "c": "Bijoux",
    "d": "Joaillier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Messika - Asie",
    "u": "https://www.messika.com/fr/asie",
    "c": "Bijoux",
    "d": "Marque française de bijoux en Asie.",
    "date": "2025"
  },
  {
    "n": "APM Monaco - Chine",
    "u": "https://www.apmmonaco.com/fr/chine",
    "c": "Bijoux",
    "d": "Marque de bijoux française en Chine.",
    "date": "2025"
  },
  {
    "n": "Chantelle - Chine",
    "u": "https://www.chantelle.com.cn/fr",
    "c": "Lingerie",
    "d": "Marque française de lingerie en Chine.",
    "date": "2025"
  },
  {
    "n": "Aubade - Asie",
    "u": "https://www.aubade.com/fr/asie",
    "c": "Lingerie",
    "d": "Marque française de lingerie en Asie.",
    "date": "2025"
  },
  {
    "n": "Princesse tam.tam - Chine",
    "u": "https://www.princessetamtam.com/fr/chine",
    "c": "Lingerie",
    "d": "Marque française de lingerie en Chine.",
    "date": "2025"
  },
  {
    "n": "Simone Pérèle - Asie",
    "u": "https://www.simoneperele.com/fr/asie",
    "c": "Lingerie",
    "d": "Marque française de lingerie en Asie.",
    "date": "2025"
  },
  {
    "n": "Lou - Chine",
    "u": "https://www.loulingerie.com/fr/chine",
    "c": "Lingerie",
    "d": "Marque française de lingerie en Chine.",
    "date": "2025"
  },
  {
    "n": "Lise Charmel - Asie",
    "u": "https://www.lisecharmel.com/fr/asie",
    "c": "Lingerie",
    "d": "Marque française de lingerie de luxe en Asie.",
    "date": "2025"
  },
  {
    "n": "Essilor Chine",
    "u": "https://www.essilor.com.cn/fr",
    "c": "Optique",
    "d": "Fabricant français de verres correcteurs en Chine.",
    "date": "2025"
  },
  {
    "n": "Luxottica France - Asie",
    "u": "https://www.luxottica.com/fr/asie",
    "c": "Optique",
    "d": "Groupe franco-italien de lunetterie en Asie.",
    "date": "2025"
  },
  {
    "n": "Alain Mikli - Chine",
    "u": "https://www.alainmikli.com/fr/chine",
    "c": "Optique",
    "d": "Lunetier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Face à Face - Asie",
    "u": "https://www.faceaface-paris.com/fr/asie",
    "c": "Optique",
    "d": "Marque française de lunettes en Asie.",
    "date": "2025"
  },
  {
    "n": "Bellinger - Chine",
    "u": "https://www.bellinger.com/fr/chine",
    "c": "Optique",
    "d": "Lunetier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Roche Bobois - Chine",
    "u": "https://www.roche-bobois.com.cn/fr",
    "c": "Décoration",
    "d": "Éditeur français de mobilier en Chine.",
    "date": "2025"
  },
  {
    "n": "Ligne Roset - Asie",
    "u": "https://www.ligne-roset.com/fr/asie",
    "c": "Décoration",
    "d": "Fabricant français de mobilier en Asie.",
    "date": "2025"
  },
  {
    "n": "Maison du Monde - Chine",
    "u": "https://www.maisondu monde.com.cn/fr",
    "c": "Décoration",
    "d": "Enseigne française de décoration en Chine.",
    "date": "2025"
  },
  {
    "n": "Mobilier International - Asie",
    "u": "https://www.mobilier-international.com/fr/asie",
    "c": "Décoration",
    "d": "Groupe français d'ameublement en Asie.",
    "date": "2025"
  },
  {
    "n": "Gautier - Chine",
    "u": "https://www.gautier.cn/fr",
    "c": "Décoration",
    "d": "Fabricant français de meubles en Chine.",
    "date": "2025"
  },
  {
    "n": "Cinna - Asie",
    "u": "https://www.cinna.fr/fr/asie",
    "c": "Décoration",
    "d": "Éditeur français de mobilier en Asie.",
    "date": "2025"
  },
  {
    "n": "Christian Liaigre - Chine",
    "u": "https://www.christianliaigre.com/fr/chine",
    "c": "Décoration",
    "d": "Designer français en Chine.",
    "date": "2025"
  },
  {
    "n": "Pierre Frey - Asie",
    "u": "https://www.pierrefrey.com/fr/asie",
    "c": "Décoration",
    "d": "Éditeur français de tissus d'ameublement en Asie.",
    "date": "2025"
  },
  {
    "n": "Nobilis - Chine",
    "u": "https://www.nobilis.fr/fr/chine",
    "c": "Décoration",
    "d": "Éditeur français de tissus et papiers peints en Chine.",
    "date": "2025"
  },
  {
    "n": "JAB Anstoetz - Asie",
    "u": "https://www.jab.de/fr/asie",
    "c": "Décoration",
    "d": "Éditeur français de tissus d'ameublement en Asie.",
    "date": "2025"
  },
  {
    "n": "Cole & Son - Chine",
    "u": "https://www.cole-and-son.com/fr/chine",
    "c": "Décoration",
    "d": "Éditeur français de papiers peints en Chine.",
    "date": "2025"
  },
  {
    "n": "Pierre Augustin Rose - Asie",
    "u": "https://www.pierre-augustin-rose.com/fr/asie",
    "c": "Décoration",
    "d": "Éditeur français de mobilier en Asie.",
    "date": "2025"
  },
  {
    "n": "Bernardaud - Chine",
    "u": "https://www.bernardaud.com/fr/chine",
    "c": "Art de la table",
    "d": "Manufacture française de porcelaine en Chine.",
    "date": "2025"
  },
  {
    "n": "Christofle - Asie",
    "u": "https://www.christofle.com/cn/fr",
    "c": "Art de la table",
    "d": "Orfèvre français en Asie.",
    "date": "2025"
  },
  {
    "n": "Lalique - Chine",
    "u": "https://www.lalique.com/cn/fr",
    "c": "Art de la table",
    "d": "Cristallerie française en Chine.",
    "date": "2025"
  },
  {
    "n": "Baccarat - Asie",
    "u": "https://www.baccarat.fr/fr/asie",
    "c": "Art de la table",
    "d": "Cristallerie française en Asie.",
    "date": "2025"
  },
  {
    "n": "Saint-Louis - Chine",
    "u": "https://www.saint-louis.com/fr/chine",
    "c": "Art de la table",
    "d": "Cristallerie française en Chine.",
    "date": "2025"
  },
  {
    "n": "Daum - Asie",
    "u": "https://www.daum.fr/fr/asie",
    "c": "Art de la table",
    "d": "Cristallerie française en Asie.",
    "date": "2025"
  },
  {
    "n": "Limoges Porcelaine - Chine",
    "u": "https://www.limoges.com/fr/chine",
    "c": "Art de la table",
    "d": "Porcelaine de Limoges en Chine.",
    "date": "2025"
  },
  {
    "n": "Gien - Asie",
    "u": "https://www.gien.com/fr/asie",
    "c": "Art de la table",
    "d": "Faïencerie française en Asie.",
    "date": "2025"
  },
  {
    "n": "Raynaud - Chine",
    "u": "https://www.raynaud.fr/fr/chine",
    "c": "Art de la table",
    "d": "Porcelaine française en Chine.",
    "date": "2025"
  },
  {
    "n": "Haviland - Asie",
    "u": "https://www.haviland.fr/fr/asie",
    "c": "Art de la table",
    "d": "Porcelaine française en Asie.",
    "date": "2025"
  },
  {
    "n": "Buffet Crampon - Chine",
    "u": "https://www.buffet-crampon.com/fr/chine",
    "c": "Musique",
    "d": "Facteur français d'instruments à vent en Chine.",
    "date": "2025"
  },
  {
    "n": "Selmer - Asie",
    "u": "https://www.selmer.fr/fr/asie",
    "c": "Musique",
    "d": "Manufacture française de saxophones en Asie.",
    "date": "2025"
  },
  {
    "n": "Maurice Dupont - Chine",
    "u": "https://www.mauricedupont.com/fr/chine",
    "c": "Musique",
    "d": "Luthier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Fazioli - Asie",
    "u": "https://www.fazioli.com/fr/asie",
    "c": "Musique",
    "d": "Facteur de pianos français en Asie.",
    "date": "2025"
  },
  {
    "n": "Pleyel - Chine",
    "u": "https://www.pleyel.fr/fr/chine",
    "c": "Musique",
    "d": "Manufacture française de pianos en Chine.",
    "date": "2025"
  },
  {
    "n": "Bechstein France - Asie",
    "u": "https://www.bechstein.com/fr/asie",
    "c": "Musique",
    "d": "Facteur de pianos français en Asie.",
    "date": "2025"
  },
  {
    "n": "Decathlon Chine",
    "u": "https://www.decathlon.com.cn/fr",
    "c": "Sport",
    "d": "Enseigne française d'articles de sport en Chine.",
    "date": "2025"
  },
  {
    "n": "Salomon - Asie",
    "u": "https://www.salomon.com/fr/asie",
    "c": "Sport",
    "d": "Marque française d'équipement de sport en Asie.",
    "date": "2025"
  },
  {
    "n": "Rossignol - Chine",
    "u": "https://www.rossignol.com/cn/fr",
    "c": "Sport",
    "d": "Marque française de ski en Chine.",
    "date": "2025"
  },
  {
    "n": "Lacoste - Asie",
    "u": "https://www.lacoste.com/cn/fr",
    "c": "Sport",
    "d": "Marque française de vêtements sport-chic en Asie.",
    "date": "2025"
  },
  {
    "n": "Le Coq Sportif - Chine",
    "u": "https://www.lecoqsportif.com.cn/fr",
    "c": "Sport",
    "d": "Marque française de sportswear en Chine.",
    "date": "2025"
  },
  {
    "n": "Aigle - Asie",
    "u": "https://www.aigle.com/fr/asie",
    "c": "Sport",
    "d": "Marque française d'équipement de plein air en Asie.",
    "date": "2025"
  },
  {
    "n": "Mammut France - Chine",
    "u": "https://www.mammut.com/fr/chine",
    "c": "Sport",
    "d": "Marque française d'équipement d'alpinisme en Chine.",
    "date": "2025"
  },
  {
    "n": "Arc'teryx - Asie",
    "u": "https://www.arcteryx.com/fr/asie",
    "c": "Sport",
    "d": "Marque française d'équipement outdoor en Asie.",
    "date": "2025"
  },
  {
    "n": "Petzl - Chine",
    "u": "https://www.petzl.com/fr/chine",
    "c": "Sport",
    "d": "Fabricant français d'équipement d'escalade en Chine.",
    "date": "2025"
  },
  {
    "n": "Mavic - Asie",
    "u": "https://www.mavic.com/fr/asie",
    "c": "Sport",
    "d": "Marque française d'équipement cycliste en Asie.",
    "date": "2025"
  },
  {
    "n": "Look Cycle - Chine",
    "u": "https://www.lookcycle.com/fr/chine",
    "c": "Sport",
    "d": "Fabricant français de pédales de vélo en Chine.",
    "date": "2025"
  },
  {
    "n": "Time Sport - Asie",
    "u": "https://www.time-sport.com/fr/asie",
    "c": "Sport",
    "d": "Marque française d'équipement cycliste en Asie.",
    "date": "2025"
  },
  {
    "n": "Bic Chine",
    "u": "https://www.bicworld.com/fr/chine",
    "c": "Fournitures",
    "d": "Fabricant français de stylos en Chine.",
    "date": "2025"
  },
  {
    "n": "Exacompta Clairefontaine - Asie",
    "u": "https://www.exacompta-clairefontaine.com/fr/asie",
    "c": "Fournitures",
    "d": "Papetier français en Asie.",
    "date": "2025"
  },
  {
    "n": "Rhodia - Chine",
    "u": "https://www.rhodia.com/fr/chine",
    "c": "Fournitures",
    "d": "Papetier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Moleskine - Asie",
    "u": "https://www.moleskine.com/fr/asie",
    "c": "Fournitures",
    "d": "Carnetier français en Asie.",
    "date": "2025"
  },
  {
    "n": "Quo Vadis - Chine",
    "u": "https://www.quovadis.com/fr/chine",
    "c": "Fournitures",
    "d": "Agendier français en Chine.",
    "date": "2025"
  },
  {
    "n": "Hachette Livre Chine",
    "u": "https://www.hachette.com.cn/fr",
    "c": "Édition",
    "d": "Éditeur français en Chine.",
    "date": "2025"
  },
  {
    "n": "Gallimard - Asie",
    "u": "https://www.gallimard.fr/fr/asie",
    "c": "Édition",
    "d": "Éditeur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Flammarion - Chine",
    "u": "https://www.editionsflammarion.fr/fr/chine",
    "c": "Édition",
    "d": "Éditeur français en Chine.",
    "date": "2025"
  },
  {
    "n": "Albin Michel - Asie",
    "u": "https://www.albin-michel.fr/fr/asie",
    "c": "Édition",
    "d": "Éditeur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Actes Sud - Chine",
    "u": "https://www.actes-sud.fr/fr/chine",
    "c": "Édition",
    "d": "Éditeur français en Chine.",
    "date": "2025"
  },
  {
    "n": "Seuil - Asie",
    "u": "https://www.seuil.com/fr/asie",
    "c": "Édition",
    "d": "Éditeur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Larousse - Chine",
    "u": "https://www.larousse.fr/fr/chine",
    "c": "Édition",
    "d": "Éditeur français en Chine.",
    "date": "2025"
  },
  {
    "n": "Robert - Asie",
    "u": "https://www.lerobert.com/fr/asie",
    "c": "Édition",
    "d": "Éditeur français de dictionnaires en Asie.",
    "date": "2025"
  },
  {
    "n": "Belin Éducation - Chine",
    "u": "https://www.belin-education.com/fr/chine",
    "c": "Édition",
    "d": "Éditeur scolaire français en Chine.",
    "date": "2025"
  },
  {
    "n": "Magnard - Asie",
    "u": "https://www.magnard.fr/fr/asie",
    "c": "Édition",
    "d": "Éditeur scolaire français en Asie.",
    "date": "2025"
  },
  {
    "n": "Le Monde - Chine",
    "u": "https://www.lemonde.fr/chine",
    "c": "Presse",
    "d": "Journal français, couverture de la Chine.",
    "date": "2025"
  },
  {
    "n": "Le Figaro - Asie",
    "u": "https://www.lefigaro.fr/international/asie",
    "c": "Presse",
    "d": "Journal français, rubrique Asie.",
    "date": "2025"
  },
  {
    "n": "Libération - Chine",
    "u": "https://www.liberation.fr/monde/chine",
    "c": "Presse",
    "d": "Journal français, actualités chinoises.",
    "date": "2025"
  },
  {
    "n": "Les Échos - Asie",
    "u": "https://www.lesechos.fr/monde/asie-pacifique",
    "c": "Presse",
    "d": "Journal économique français, rubrique Asie.",
    "date": "2025"
  },
  {
    "n": "L'Express - Chine",
    "u": "https://www.lexpress.fr/monde/asie/chine",
    "c": "Presse",
    "d": "News magazine français sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Le Point - Asie",
    "u": "https://www.lepoint.fr/monde/asie",
    "c": "Presse",
    "d": "News magazine français, rubrique Asie.",
    "date": "2025"
  },
  {
    "n": "Paris Match - Chine",
    "u": "https://www.parismatch.com/Actualites/International/Chine",
    "c": "Presse",
    "d": "Magazine français, reportages sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Elle - Asie",
    "u": "https://www.elle.fr/fr/asie",
    "c": "Presse",
    "d": "Magazine féminin français en Asie.",
    "date": "2025"
  },
  {
    "n": "Vogue Paris - Chine",
    "u": "https://www.vogue.fr/fashion/article/vogue-paris-chine",
    "c": "Presse",
    "d": "Magazine de mode français sur la Chine.",
    "date": "2025"
  },
  {
    "n": "GEO - Asie",
    "u": "https://www.geo.fr/voyage/asie",
    "c": "Presse",
    "d": "Magazine de voyage français sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "National Geographic France - Chine",
    "u": "https://www.nationalgeographic.fr/chine",
    "c": "Presse",
    "d": "Magazine français, articles sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Science & Vie - Asie",
    "u": "https://www.science-et-vie.com/asie",
    "c": "Presse",
    "d": "Magazine scientifique français sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Festival de Cannes - Chine",
    "u": "https://www.festival-cannes.com/fr/chine",
    "c": "Festival",
    "d": "Festival de cinéma français en Chine.",
    "date": "2025"
  },
  {
    "n": "Festival de Jazz de Marciac - Chine",
    "u": "https://www.jazzinmarciac.com/fr/chine",
    "c": "Festival",
    "d": "Festival de jazz français en Chine.",
    "date": "2025"
  },
  {
    "n": "Festival de la BD d'Angoulême - Asie",
    "u": "https://www.bdangouleme.com/fr/asie",
    "c": "Festival",
    "d": "Festival de bande dessinée français en Asie.",
    "date": "2025"
  },
  {
    "n": "Festival des Vieilles Charrues - Chine",
    "u": "https://www.vieillescharrues.asso.fr/fr/chine",
    "c": "Festival",
    "d": "Festival de musique français en Chine.",
    "date": "2025"
  },
  {
    "n": "Festival de Saint-Denis - Asie",
    "u": "https://www.festival-saint-denis.com/fr/asie",
    "c": "Festival",
    "d": "Festival de musique classique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Printemps de Bourges - Chine",
    "u": "https://www.printemps-bourges.com/fr/chine",
    "c": "Festival",
    "d": "Festival de musique français en Chine.",
    "date": "2025"
  },
  {
    "n": "Francofolies - Asie",
    "u": "https://www.francofolies.fr/fr/asie",
    "c": "Festival",
    "d": "Festival de musique francophone en Asie.",
    "date": "2025"
  },
  {
    "n": "Solidays - Chine",
    "u": "https://www.solidays.org/fr/chine",
    "c": "Festival",
    "d": "Festival de musique solidaire français en Chine.",
    "date": "2025"
  },
  {
    "n": "Rock en Seine - Asie",
    "u": "https://www.rockenseine.com/fr/asie",
    "c": "Festival",
    "d": "Festival de rock français en Asie.",
    "date": "2025"
  },
  {
    "n": "Bocuse d'Or - Chine",
    "u": "https://www.bocusedor.com/fr/chine",
    "c": "Gastronomie",
    "d": "Concours de cuisine français en Chine.",
    "date": "2025"
  },
  {
    "n": "Meilleur Ouvrier de France - Asie",
    "u": "https://www.meilleurouvrierdefrance.fr/fr/asie",
    "c": "Gastronomie",
    "d": "Concours d'excellence français en Asie.",
    "date": "2025"
  },
  {
    "n": "Relais & Châteaux - Chine",
    "u": "https://www.relaischateaux.com/fr/chine",
    "c": "Gastronomie",
    "d": "Association française de restaurants et hôtels de luxe en Chine.",
    "date": "2025"
  },
  {
    "n": "Gault & Millau - Asie",
    "u": "https://www.gaultmillau.com/fr/asie",
    "c": "Gastronomie",
    "d": "Guide gastronomique français en Asie.",
    "date": "2025"
  },
  {
    "n": "Pudlowski - Chine",
    "u": "https://www.gillespudlowski.com/fr/chine",
    "c": "Gastronomie",
    "d": "Critique gastronomique français sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Fooding - Asie",
    "u": "https://www.lefooding.com/fr/asie",
    "c": "Gastronomie",
    "d": "Guide gastronomique français en Asie.",
    "date": "2025"
  },
  {
    "n": "OAD (Opinionated About Dining) - Chine",
    "u": "https://www.opinionatedaboutdining.com/fr/chine",
    "c": "Gastronomie",
    "d": "Classement de restaurants français sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Union des Œnologues de France - Chine",
    "u": "https://www.uof.fr/fr/chine",
    "c": "Vin",
    "d": "Association d'œnologues français en Chine.",
    "date": "2025"
  },
  {
    "n": "Conseil Interprofessionnel du Vin de Bordeaux (CIVB) - Asie",
    "u": "https://www.bordeaux.com/fr/asie",
    "c": "Vin",
    "d": "Interprofession bordelaise en Asie.",
    "date": "2025"
  },
  {
    "n": "Comité Champagne - Chine",
    "u": "https://www.champagne.fr/fr/chine",
    "c": "Vin",
    "d": "Comité interprofessionnel du champagne en Chine.",
    "date": "2025"
  },
  {
    "n": "Bureau National Interprofessionnel du Cognac (BNIC) - Asie",
    "u": "https://www.cognac.fr/fr/asie",
    "c": "Spiritueux",
    "d": "Interprofession du cognac en Asie.",
    "date": "2025"
  },
  {
    "n": "Comité National des Vins de Loire - Chine",
    "u": "https://www.vinsdeloire.fr/fr/chine",
    "c": "Vin",
    "d": "Interprofession des vins de Loire en Chine.",
    "date": "2025"
  },
  {
    "n": "Conseil Interprofessionnel des Vins du Languedoc - Asie",
    "u": "https://www.languedoc-wines.com/fr/asie",
    "c": "Vin",
    "d": "Interprofession des vins du Languedoc en Asie.",
    "date": "2025"
  },
  {
    "n": "Inter Rhône - Chine",
    "u": "https://www.vinsderhone.com/fr/chine",
    "c": "Vin",
    "d": "Interprofession des vins de la vallée du Rhône en Chine.",
    "date": "2025"
  },
  {
    "n": "Bureau Interprofessionnel des Vins de Bourgogne (BIVB) - Asie",
    "u": "https://www.bourgogne-wines.com/fr/asie",
    "c": "Vin",
    "d": "Interprofession des vins de Bourgogne en Asie.",
    "date": "2025"
  },
  {
    "n": "Comité Interprofessionnel des Vins d'Alsace (CIVA) - Chine",
    "u": "https://www.vinsalsace.com/fr/chine",
    "c": "Vin",
    "d": "Interprofession des vins d'Alsace en Chine.",
    "date": "2025"
  },
  {
    "n": "Conseil Interprofessionnel des Vins de Provence - Asie",
    "u": "https://www.vinsdeprovence.com/fr/asie",
    "c": "Vin",
    "d": "Interprofession des vins de Provence en Asie.",
    "date": "2025"
  },
  {
    "n": "VIA (Valorisation de l'Innovation dans l'Ameublement) - Chine",
    "u": "https://www.via.fr/fr/chine",
    "c": "Design",
    "d": "Organisation française de promotion du design en Chine.",
    "date": "2025"
  },
  {
    "n": "APCI (Agence pour la Promotion de la Création Industrielle) - Asie",
    "u": "https://www.apci.asso.fr/fr/asie",
    "c": "Design",
    "d": "Agence française de design industriel en Asie.",
    "date": "2025"
  },
  {
    "n": "Cité du Design de Saint-Étienne - Chine",
    "u": "https://www.citedudesign.com/fr/chine",
    "c": "Design",
    "d": "Institution française de design en Chine.",
    "date": "2025"
  },
  {
    "n": "Fondation d'entreprise Hermès - Asie",
    "u": "https://www.fondationdentreprisehermes.org/fr/asie",
    "c": "Design",
    "d": "Fondation française soutenant le design en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation Cartier pour l'art contemporain - Chine",
    "u": "https://www.fondationcartier.com/fr/chine",
    "c": "Design",
    "d": "Fondation française d'art contemporain en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français du Design - Asie",
    "u": "https://www.institut-francais-du-design.fr/fr/asie",
    "c": "Design",
    "d": "Institut français de design en Asie.",
    "date": "2025"
  },
  {
    "n": "Janus Industriel - Chine",
    "u": "https://www.janus-industriel.fr/fr/chine",
    "c": "Design",
    "d": "Label français de design industriel en Chine.",
    "date": "2025"
  },
  {
    "n": "École Française d'Extrême-Orient (EFEO) - Chine",
    "u": "https://www.efeo.fr/fr/chine",
    "c": "Archéologie",
    "d": "Institution française de recherche archéologique en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Recherche en Iran (IFRI) - Asie",
    "u": "https://www.ifri.fr/fr/asie",
    "c": "Archéologie",
    "d": "Institut français de recherche archéologique en Asie.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française en Asie Centrale (MAFAC)",
    "u": "https://www.mafac.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française en Asie centrale.",
    "date": "2025"
  },
  {
    "n": "Délégation Archéologique Française en Afghanistan (DAFA)",
    "u": "https://www.dafa.org.fr",
    "c": "Archéologie",
    "d": "Délégation archéologique française en Afghanistan.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française au Pakistan (MAFP)",
    "u": "https://www.mafp.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française au Pakistan.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française au Népal (MAFN)",
    "u": "https://www.mafn.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française au Népal.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française au Sri Lanka (MAFSL)",
    "u": "https://www.mafsl.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française au Sri Lanka.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française au Bangladesh (MAFB)",
    "u": "https://www.mafb.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française au Bangladesh.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française en Mongolie (MAFM)",
    "u": "https://www.mafm.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française en Mongolie.",
    "date": "2025"
  },
  {
    "n": "Mission Archéologique Française en Corée (MAFC)",
    "u": "https://www.mafc.fr",
    "c": "Archéologie",
    "d": "Mission archéologique française en Corée.",
    "date": "2025"
  },
  {
    "n": "Muséum National d'Histoire Naturelle - Chine",
    "u": "https://www.mnhn.fr/fr/chine",
    "c": "Botanique",
    "d": "Muséum français, collections botaniques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Jardin des Plantes de Paris - Asie",
    "u": "https://www.jardindesplantesdeparis.fr/fr/asie",
    "c": "Botanique",
    "d": "Jardin botanique français, plantes asiatiques.",
    "date": "2025"
  },
  {
    "n": "Conservatoire et Jardins Botaniques de Nancy - Chine",
    "u": "https://www.cjbn.fr/fr/chine",
    "c": "Botanique",
    "d": "Jardin botanique français, collections chinoises.",
    "date": "2025"
  },
  {
    "n": "Arboretum de Chèvreloup - Asie",
    "u": "https://www.arboretumdechevreloup.fr/fr/asie",
    "c": "Botanique",
    "d": "Arboretum français, arbres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Jardin Botanique de Lyon - Chine",
    "u": "https://www.jardin-botanique-lyon.com/fr/chine",
    "c": "Botanique",
    "d": "Jardin botanique français, plantes chinoises.",
    "date": "2025"
  },
  {
    "n": "Parc de la Tête d'Or - Asie",
    "u": "https://www.parcdelatetedor.com/fr/asie",
    "c": "Botanique",
    "d": "Parc français, jardin botanique asiatique.",
    "date": "2025"
  },
  {
    "n": "Jardin Botanique de Bordeaux - Chine",
    "u": "https://www.jardin-botanique-bordeaux.fr/fr/chine",
    "c": "Botanique",
    "d": "Jardin botanique français, collections chinoises.",
    "date": "2025"
  },
  {
    "n": "Musée du Quai Branly - Jacques Chirac - Asie",
    "u": "https://www.quaibranly.fr/fr/asie",
    "c": "Anthropologie",
    "d": "Musée français des arts et civilisations d'Asie.",
    "date": "2025"
  },
  {
    "n": "Musée des Confluences - Chine",
    "u": "https://www.museedesconfluences.fr/fr/chine",
    "c": "Anthropologie",
    "d": "Musée français, collections asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée des Arts Asiatiques de Nice - Asie",
    "u": "https://www.musee-asiatique-nice.org/fr/asie",
    "c": "Anthropologie",
    "d": "Musée français dédié aux arts asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée Guimet - Chine",
    "u": "https://www.guimet.fr/fr/chine",
    "c": "Anthropologie",
    "d": "Musée national des arts asiatiques français.",
    "date": "2025"
  },
  {
    "n": "Musée Cernuschi - Asie",
    "u": "https://www.cernuschi.paris.fr/fr/asie",
    "c": "Anthropologie",
    "d": "Musée parisien des arts de l'Asie.",
    "date": "2025"
  },
  {
    "n": "Musée National des Arts Asiatiques - Chine",
    "u": "https://www.mnaag.fr/fr/chine",
    "c": "Anthropologie",
    "d": "Musée français des arts asiatiques.",
    "date": "2025"
  },
  {
    "n": "La Poste - Timbres Chine",
    "u": "https://www.laposte.fr/timbres/chine",
    "c": "Philatélie",
    "d": "Timbres français sur thèmes chinois.",
    "date": "2025"
  },
  {
    "n": "Monnaie de Paris - Asie",
    "u": "https://www.monnaiedeparis.fr/fr/asie",
    "c": "Numismatique",
    "d": "Monnaie française, collections asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée de La Poste - Chine",
    "u": "https://www.museedelaposte.fr/fr/chine",
    "c": "Philatélie",
    "d": "Musée postal français, collections chinoises.",
    "date": "2025"
  },
  {
    "n": "Société Française de Philatélie - Asie",
    "u": "https://www.sfphilatelie.fr/fr/asie",
    "c": "Philatélie",
    "d": "Société philatélique française en Asie.",
    "date": "2025"
  },
  {
    "n": "Société Française de Numismatique - Chine",
    "u": "https://www.sfnumismatique.fr/fr/chine",
    "c": "Numismatique",
    "d": "Société numismatique française en Chine.",
    "date": "2025"
  },
  {
    "n": "Société des Études Japonaises",
    "u": "https://www.sej-etudesjaponaises.org",
    "c": "Savante",
    "d": "Société savante française sur le Japon.",
    "date": "2025"
  },
  {
    "n": "Société des Études Indochinoises",
    "u": "https://www.etudes-indochinoises.org",
    "c": "Savante",
    "d": "Société savante française sur l'Indochine.",
    "date": "2025"
  },
  {
    "n": "Société des Amis de l'Orient",
    "u": "https://www.amisdelorient.fr",
    "c": "Savante",
    "d": "Société française sur les cultures orientales.",
    "date": "2025"
  },
  {
    "n": "Association Française d'Études Chinoises",
    "u": "https://www.afec-etudeschinoises.com",
    "c": "Savante",
    "d": "Association française d'études chinoises.",
    "date": "2025"
  },
  {
    "n": "Association Française pour l'Étude de la Corée",
    "u": "https://www.afec-corée.org",
    "c": "Savante",
    "d": "Association française d'études coréennes.",
    "date": "2025"
  },
  {
    "n": "Société Française d'Études du Monde Tibétain",
    "u": "https://www.etudes-tibetaines.fr",
    "c": "Savante",
    "d": "Société française d'études tibétaines.",
    "date": "2025"
  },
  {
    "n": "Association Française des Études sur l'Asie du Sud",
    "u": "https://www.afeas.org",
    "c": "Savante",
    "d": "Association française d'études sud-asiatiques.",
    "date": "2025"
  },
  {
    "n": "Société des Africanistes et des Orientalistes",
    "u": "https://www.africanistes-orientalistes.fr",
    "c": "Savante",
    "d": "Société savante française sur l'Afrique et l'Orient.",
    "date": "2025"
  },
  {
    "n": "Société Française d'Acupuncture",
    "u": "https://www.acupuncture-france.fr",
    "c": "Médecine",
    "d": "Société française d'acupuncture, originaire d'Asie.",
    "date": "2025"
  },
  {
    "n": "Association Française d'Études des Médecines Traditionnelles Asiatiques",
    "u": "https://www.afemta.fr",
    "c": "Médecine",
    "d": "Association française sur les médecines asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut Yang Ming - Médecine Chinoise",
    "u": "https://www.institut-yangming.fr",
    "c": "Médecine",
    "d": "Institut français de médecine chinoise.",
    "date": "2025"
  },
  {
    "n": "École de Médecine Traditionnelle Chinoise de Paris",
    "u": "https://www.emtcp.fr",
    "c": "Médecine",
    "d": "École française de médecine chinoise.",
    "date": "2025"
  },
  {
    "n": "Faculté de Médecine de Montpellier - Histoire de la Médecine Asiatique",
    "u": "https://www.medecine-asiatique-montpellier.fr",
    "c": "Médecine",
    "d": "Faculté française étudiant la médecine asiatique.",
    "date": "2025"
  },
  {
    "n": "Musée d'Histoire de la Médecine de Paris - Asie",
    "u": "https://www.musee-medecine-paris.fr/asie",
    "c": "Médecine",
    "d": "Musée français, collections de médecine asiatique.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Judo - Asie",
    "u": "https://www.ffjudo.com/fr/asie",
    "c": "Sport",
    "d": "Fédération française de judo, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Karaté - Chine",
    "u": "https://www.ffkarate.fr/fr/chine",
    "c": "Sport",
    "d": "Fédération française de karaté, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française d'Aïkido - Asie",
    "u": "https://www.ffaba.fr/fr/asie",
    "c": "Sport",
    "d": "Fédération française d'aïkido, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Taekwondo - Corée",
    "u": "https://www.fftda.fr/fr/coree",
    "c": "Sport",
    "d": "Fédération française de taekwondo, art martial coréen.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Wushu - Chine",
    "u": "https://www.ffwushu.fr",
    "c": "Sport",
    "d": "Fédération française de wushu, arts martiaux chinois.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Viet Vo Dao - Vietnam",
    "u": "https://www.ffvvd.fr",
    "c": "Sport",
    "d": "Fédération française de viet vo dao, art martial vietnamien.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Kendo - Japon",
    "u": "https://www.ffjudo.com/fr/kendo",
    "c": "Sport",
    "d": "Fédération française de kendo, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Iaido - Asie",
    "u": "https://www.ffjudo.com/fr/iaido",
    "c": "Sport",
    "d": "Fédération française de iaido, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Jodo - Japon",
    "u": "https://www.ffjudo.com/fr/jodo",
    "c": "Sport",
    "d": "Fédération française de jodo, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Fédération Française de Kyudo - Asie",
    "u": "https://www.ffjudo.com/fr/kyudo",
    "c": "Sport",
    "d": "Fédération française de kyudo, art martial japonais.",
    "date": "2025"
  },
  {
    "n": "Maison des Cultures du Monde - Asie",
    "u": "https://www.maisondesculturesdumonde.org/fr/asie",
    "c": "Musique",
    "d": "Institution française de musiques traditionnelles asiatiques.",
    "date": "2025"
  },
  {
    "n": "Centre de Musiques Traditionnelles de la Réunion - Chine",
    "u": "https://www.cmtr.fr/fr/chine",
    "c": "Musique",
    "d": "Centre français de musiques traditionnelles, influences asiatiques.",
    "date": "2025"
  },
  {
    "n": "Conservatoire à Rayonnement Régional de Paris - Musiques Asiatiques",
    "u": "https://www.crr-paris.fr/fr/musiques-asiatiques",
    "c": "Musique",
    "d": "Conservatoire français enseignant les musiques asiatiques.",
    "date": "2025"
  },
  {
    "n": "École Normale de Musique de Paris - Asie",
    "u": "https://www.ecolenormalemusiqueparis.fr/fr/asie",
    "c": "Musique",
    "d": "École française de musique, département asiatique.",
    "date": "2025"
  },
  {
    "n": "Conservatoire National Supérieur de Musique et de Danse de Paris - Chine",
    "u": "https://www.conservatoiredeparis.fr/fr/chine",
    "c": "Musique",
    "d": "Conservatoire français, musiques chinoises.",
    "date": "2025"
  },
  {
    "n": "Philharmonie de Paris - Asie",
    "u": "https://www.philharmoniedeparis.fr/fr/asie",
    "c": "Musique",
    "d": "Salle de concert française, programmation asiatique.",
    "date": "2025"
  },
  {
    "n": "Opéra National de Lyon - Musiques Asiatiques",
    "u": "https://www.opera-lyon.com/fr/musiques-asiatiques",
    "c": "Musique",
    "d": "Opéra français, œuvres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Théâtre de la Ville - Danse Asiatique",
    "u": "https://www.theatredelaville-paris.com/fr/danse-asiatique",
    "c": "Danse",
    "d": "Théâtre français, danse asiatique.",
    "date": "2025"
  },
  {
    "n": "Centre National de la Danse - Asie",
    "u": "https://www.cnd.fr/fr/asie",
    "c": "Danse",
    "d": "Centre français de danse, formes asiatiques.",
    "date": "2025"
  },
  {
    "n": "Musée de la Musique - Instruments Asiatiques",
    "u": "https://www.musee-musique.com/fr/instruments-asiatiques",
    "c": "Musique",
    "d": "Musée français, collection d'instruments asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut Lumière - Chine",
    "u": "https://www.institut-lumiere.org/fr/chine",
    "c": "Cinéma",
    "d": "Institut français du cinéma, relations avec la Chine.",
    "date": "2025"
  },
  {
    "n": "Fondation Jérôme Seydoux-Pathé - Asie",
    "u": "https://www.fondation-jeromeseydoux-pathe.org/fr/asie",
    "c": "Cinéma",
    "d": "Fondation française du cinéma, patrimoine asiatique.",
    "date": "2025"
  },
  {
    "n": "Cinémathèque Française - Chine",
    "u": "https://www.cinematheque.fr/fr/chine",
    "c": "Cinéma",
    "d": "Cinémathèque française, films chinois.",
    "date": "2025"
  },
  {
    "n": "Forum des Images - Asie",
    "u": "https://www.forumdesimages.fr/fr/asie",
    "c": "Cinéma",
    "d": "Forum français du cinéma, cinéma asiatique.",
    "date": "2025"
  },
  {
    "n": "Fondation Gan pour le Cinéma - Chine",
    "u": "https://www.fondation-gan.org/fr/chine",
    "c": "Non catégorisé",
    "d": "Fondation française soutenant le cinéma chinois.",
    "date": "2025"
  },
  {
    "n": "Unifrance - Asie",
    "u": "https://www.unifrance.org/fr/asie",
    "c": "Cinéma",
    "d": "Organisme français de promotion du cinéma en Asie.",
    "date": "2025"
  },
  {
    "n": "Festival du Film Français d'Hellywood (Chine)",
    "u": "https://www.festivalfilmfrancais-chine.com",
    "c": "Festival",
    "d": "Festival de cinéma français en Chine.",
    "date": "2025"
  },
  {
    "n": "Festival du Film Asiatique de Deauville",
    "u": "https://www.festival-deauville.com/fr/asie",
    "c": "Festival",
    "d": "Festival français du cinéma asiatique.",
    "date": "2025"
  },
  {
    "n": "Festival International du Film Fantastique de Gérardmer - Asie",
    "u": "https://www.festival-gerardmer.com/fr/asie",
    "c": "Festival",
    "d": "Festival français, cinéma fantastique asiatique.",
    "date": "2025"
  },
  {
    "n": "Festival des 3 Continents - Asie",
    "u": "https://www.3continents.com/fr/asie",
    "c": "Festival",
    "d": "Festival français de cinéma d'Asie, Afrique et Amérique.",
    "date": "2025"
  },
  {
    "n": "Festival du Film Court de Villeurbanne - Chine",
    "u": "https://www.festival-film-court-villeurbanne.fr/fr/chine",
    "c": "Festival",
    "d": "Festival français, courts-métrages chinois.",
    "date": "2025"
  },
  {
    "n": "Festival du Film de Sarlat - Asie",
    "u": "https://www.festival-film-sarlat.com/fr/asie",
    "c": "Festival",
    "d": "Festival français du film, section asiatique.",
    "date": "2025"
  },
  {
    "n": "Maison des Écrivains et de la Littérature - Asie",
    "u": "https://www.m-e-l.fr/fr/asie",
    "c": "Littérature",
    "d": "Maison française des écrivains, auteurs asiatiques.",
    "date": "2025"
  },
  {
    "n": "Centre National du Livre - Chine",
    "u": "https://www.centrenationaldulivre.fr/fr/chine",
    "c": "Littérature",
    "d": "Organisme français du livre, traductions chinoises.",
    "date": "2025"
  },
  {
    "n": "Société des Gens de Lettres - Asie",
    "u": "https://www.sgdl.org/fr/asie",
    "c": "Littérature",
    "d": "Société française des auteurs, membres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Académie Goncourt - Chine",
    "u": "https://www.academie-goncourt.fr/fr/chine",
    "c": "Littérature",
    "d": "Académie française, auteurs chinois primés.",
    "date": "2025"
  },
  {
    "n": "Prix Femina - Asie",
    "u": "https://www.prix-femina.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix littéraire français, lauréats asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Renaudot - Chine",
    "u": "https://www.prix-renaudot.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix littéraire français, auteurs chinois.",
    "date": "2025"
  },
  {
    "n": "Prix Médicis - Asie",
    "u": "https://www.prix-medicis.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix littéraire français, écrivains asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Interallié - Chine",
    "u": "https://www.prix-interallie.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix littéraire français, romans sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Prix du Livre Inter - Asie",
    "u": "https://www.livreinter.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix radiophonique français, livres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix des Libraires - Chine",
    "u": "https://www.prixdeslibraires.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix français, sélections chinoises.",
    "date": "2025"
  },
  {
    "n": "Prix Décembre - Asie",
    "u": "https://www.prixdecembre.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix littéraire français, ouvrages asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Wepler - Chine",
    "u": "https://www.prixwepler.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix littéraire français, romans chinois.",
    "date": "2025"
  },
  {
    "n": "Pilotis - Asie",
    "u": "https://www.pilotis.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix littéraire français, premiers romans asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix de l'Académie Française - Chine",
    "u": "https://www.academie-francaise.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix de l'Académie française, auteurs chinois.",
    "date": "2025"
  },
  {
    "n": "Grand Prix du Roman de l'Académie Française - Asie",
    "u": "https://www.academie-francaise.fr/fr/asie",
    "c": "Littérature",
    "d": "Grand prix français, romans asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Littéraire de la Vocation - Chine",
    "u": "https://www.prix-vocation.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix français, jeunes auteurs chinois.",
    "date": "2025"
  },
  {
    "n": "Prix du Premier Roman - Asie",
    "u": "https://www.prix-premier-roman.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix français, premiers romans asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix du Roman Fnac - Chine",
    "u": "https://www.prix-roman-fnac.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix de la Fnac, romans chinois.",
    "date": "2025"
  },
  {
    "n": "Prix des Embouquineurs - Asie",
    "u": "https://www.embouquineurs.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix français jeunesse, livres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Sorcières - Chine",
    "u": "https://www.prix-sorcieres.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix jeunesse français, albums chinois.",
    "date": "2025"
  },
  {
    "n": "Prix des Incorruptibles - Asie",
    "u": "https://www.lesincos.com/fr/asie",
    "c": "Littérature",
    "d": "Prix jeunesse français, livres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Tam-Tam - Chine",
    "u": "https://www.prix-tamtam.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix jeunesse français de la Fnac, romans chinois.",
    "date": "2025"
  },
  {
    "n": "Prix Farniente - Asie",
    "u": "https://www.prix-farniente.be/fr/asie",
    "c": "Littérature",
    "d": "Prix jeunesse belge francophone, livres asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Ados - Chine",
    "u": "https://www.prixados.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix ado français, romans chinois.",
    "date": "2025"
  },
  {
    "n": "Prix des Dévoreurs de Livres - Asie",
    "u": "https://www.devoreursdelivres.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix jeunesse français, livres asiatiques.",
    "date": "2025"
  },
  {
    "n": "P Chroniques - Chine",
    "u": "https://www.pchroniques.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix lycéen français, bandes dessinées chinoises.",
    "date": "2025"
  },
  {
    "n": "Prix BD des Collégiens - Asie",
    "u": "https://www.prixbdcollegiens.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix BD français, mangas et bandes dessinées asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Artemisia - Chine",
    "u": "https://www.prixartemisia.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix français de bande dessinée féminine, autrices chinoises.",
    "date": "2025"
  },
  {
    "n": "Prix Wolinski - Asie",
    "u": "https://www.prixwolinski.fr/fr/asie",
    "c": "Littérature",
    "d": "Prix français de bande dessinée, auteurs asiatiques.",
    "date": "2025"
  },
  {
    "n": "Prix Révélation de l'Académie des Beaux-Arts - Chine",
    "u": "https://www.academie-des-beaux-arts.fr/fr/chine",
    "c": "Littérature",
    "d": "Prix français, bandes dessinées chinoises.",
    "date": "2025"
  },
  {
    "n": "Collège de France - Chaire de Philosophie Asiatique",
    "u": "https://www.college-de-france.fr/fr/chaire-philosophie-asiatique",
    "c": "Philosophie",
    "d": "Institution française, enseignement de philosophie asiatique.",
    "date": "2025"
  },
  {
    "n": "École Pratique des Hautes Études - Asie",
    "u": "https://www.ephe.fr/fr/asie",
    "c": "Philosophie",
    "d": "École française, études des spiritualités asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut d'Études Bouddhiques - Chine",
    "u": "https://www.institut-bouddhique.fr/fr/chine",
    "c": "Philosophie",
    "d": "Institut français d'études bouddhiques.",
    "date": "2025"
  },
  {
    "n": "Société Française d'Études du Bouddhisme",
    "u": "https://www.sfeb.fr",
    "c": "Philosophie",
    "d": "Société française de recherche bouddhique.",
    "date": "2025"
  },
  {
    "n": "Association Française des Amis de l'Orient",
    "u": "https://www.amisdelorient.fr",
    "c": "Philosophie",
    "d": "Association française des philosophies orientales.",
    "date": "2025"
  },
  {
    "n": "Centre d'Études et de Documentation sur le Bouddhisme",
    "u": "https://www.cedb.fr",
    "c": "Philosophie",
    "d": "Centre français de documentation bouddhique.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche sur les Civilisations de l'Asie Orientale",
    "u": "https://www.ircao.fr",
    "c": "Philosophie",
    "d": "Institut français de recherches asiatiques.",
    "date": "2025"
  },
  {
    "n": "Société Française de Philosophie - Asie",
    "u": "https://www.sofrphilo.fr/fr/asie",
    "c": "Philosophie",
    "d": "Société philosophique française, pensée asiatique.",
    "date": "2025"
  },
  {
    "n": "Association pour la Recherche Interculturelle - Chine",
    "u": "https://www.aric.fr/fr/chine",
    "c": "Philosophie",
    "d": "Association française de philosophie interculturelle.",
    "date": "2025"
  },
  {
    "n": "Centre International d'Études de la Philosophie Française Contemporaine - Asie",
    "u": "https://www.ciepfc.fr/fr/asie",
    "c": "Philosophie",
    "d": "Centre français, dialogue philosophique avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Français des Relations Internationales (IFRI) - Asie",
    "u": "https://www.ifri.org/fr/asie",
    "c": "Économie",
    "d": "Think tank français sur les relations internationales asiatiques.",
    "date": "2025"
  },
  {
    "n": "Fondation pour la Recherche Stratégique - Chine",
    "u": "https://www.frstrategie.org/fr/chine",
    "c": "Politique",
    "d": "Fondation française de recherche stratégique sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Centre d'Études et de Recherches Internationales (CERI) - Asie",
    "u": "https://www.ceri-sciencespo.fr/fr/asie",
    "c": "Politique",
    "d": "Centre français de recherches internationales asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche Stratégique de l'École Militaire (IRSEM) - Chine",
    "u": "https://www.irsem.fr/fr/chine",
    "c": "Politique",
    "d": "Institut français de recherche stratégique sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Montaigne - Asie",
    "u": "https://www.institutmontaigne.org/fr/asie",
    "c": "Économie",
    "d": "Think tank français, études économiques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Fondation Jean-Jaurès - Chine",
    "u": "https://www.jean-jaures.org/fr/chine",
    "c": "Politique",
    "d": "Fondation française, analyses politiques chinoises.",
    "date": "2025"
  },
  {
    "n": "Fondation Robert Schuman - Asie",
    "u": "https://www.robert-schuman.eu/fr/asie",
    "c": "Politique",
    "d": "Fondation française, relations Europe-Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Prospective et Sécurité en Europe (IPSE) - Chine",
    "u": "https://www.ipseurope.eu/fr/chine",
    "c": "Politique",
    "d": "Institut français, sécurité et Chine.",
    "date": "2025"
  },
  {
    "n": "Centre d'Analyse, de Prévision et de Stratégie (CAPS) - Asie",
    "u": "https://www.diplomatie.gouv.fr/fr/caps/asie",
    "c": "Politique",
    "d": "Centre français du Quai d'Orsay sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Institut National des Langues et Civilisations Orientales (INALCO) - Chine",
    "u": "https://www.inalco.fr/fr/chine",
    "c": "Économie",
    "d": "Institut français, formation économique sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Campus France - Asie",
    "u": "https://www.campusfrance.org/fr/asie",
    "c": "Éducation",
    "d": "Agence française pour l'accueil des étudiants asiatiques.",
    "date": "2025"
  },
  {
    "n": "France Éducation International - Chine",
    "u": "https://www.france-education-international.fr/fr/chine",
    "c": "Éducation",
    "d": "Opérateur français de coopération éducative avec la Chine.",
    "date": "2025"
  },
  {
    "n": "Agence pour l'Enseignement Français à l'Étranger (AEFE) - Asie",
    "u": "https://www.aefe.fr/fr/asie",
    "c": "Éducation",
    "d": "Réseau des lycées français en Asie.",
    "date": "2025"
  },
  {
    "n": "Mission Laïque Française - Chine",
    "u": "https://www.mlfmonde.org/fr/chine",
    "c": "Éducation",
    "d": "Réseau d'écoles françaises en Chine.",
    "date": "2025"
  },
  {
    "n": "Centre International d'Études Pédagogiques (CIEP) - Asie",
    "u": "https://www.ciep.fr/fr/asie",
    "c": "Éducation",
    "d": "Centre français, coopération éducative asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut National de la Jeunesse et de l'Éducation Populaire (INJEP) - Chine",
    "u": "https://www.injep.fr/fr/chine",
    "c": "Éducation",
    "d": "Institut français, échanges jeunesse avec la Chine.",
    "date": "2025"
  },
  {
    "n": "Office Franco-Allemand pour la Jeunesse (OFAJ) - Asie",
    "u": "https://www.ofaj.org/fr/asie",
    "c": "Éducation",
    "d": "Office franco-allemand, projets jeunesse asiatiques.",
    "date": "2025"
  },
  {
    "n": "Office Franco-Québécois pour la Jeunesse (OFQJ) - Chine",
    "u": "https://www.ofqj.org/fr/chine",
    "c": "Éducation",
    "d": "Office franco-québécois, échanges avec la Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français - Asie",
    "u": "https://www.institutfrancais.com/fr/asie",
    "c": "Éducation",
    "d": "Réseau culturel et éducatif français en Asie.",
    "date": "2025"
  },
  {
    "n": "Alliance Française - Chine",
    "u": "https://www.alliancefr.org/fr/chine",
    "c": "Éducation",
    "d": "Réseau de centres de langue française en Chine.",
    "date": "2025"
  },
  {
    "n": "Société de Législation Comparée - Asie",
    "u": "https://www.legislationcomparee.fr/fr/asie",
    "c": "Droit",
    "d": "Société française de droit comparé asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut de Droit Comparé de Paris - Chine",
    "u": "https://www.institut-droit-comparé-paris.fr/fr/chine",
    "c": "Droit",
    "d": "Institut français de droit chinois.",
    "date": "2025"
  },
  {
    "n": "Centre de Droit International de Nanterre (CEDIN) - Asie",
    "u": "https://www.cedin.univ-paris10.fr/fr/asie",
    "c": "Droit",
    "d": "Centre français de droit international asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut des Hautes Études Internationales (IDHEI) - Chine",
    "u": "https://www.idhei.fr/fr/chine",
    "c": "Droit",
    "d": "Institut français, droit international chinois.",
    "date": "2025"
  },
  {
    "n": "Société Française pour le Droit International (SFDI) - Asie",
    "u": "https://www.sfdi.org/fr/asie",
    "c": "Droit",
    "d": "Société française de droit international asiatique.",
    "date": "2025"
  },
  {
    "n": "Association Française des Juristes (AFJ) - Chine",
    "u": "https://www.afj.fr/fr/chine",
    "c": "Droit",
    "d": "Association française de juristes spécialisés sur la Chine.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche Juridique de la Sorbonne (IRJS) - Asie",
    "u": "https://www.irjs.univ-paris1.fr/fr/asie",
    "c": "Droit",
    "d": "Institut français de recherche juridique asiatique.",
    "date": "2025"
  },
  {
    "n": "Centre de Recherche sur les Droits de l'Homme et le Droit Humanitaire (CRDH) - Chine",
    "u": "https://www.crdh.fr/fr/chine",
    "c": "Droit",
    "d": "Centre français, droits de l'homme en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut des Sciences Juridique et Philosophique de la Sorbonne (ISJPS) - Asie",
    "u": "https://www.isjps.univ-paris1.fr/fr/asie",
    "c": "Droit",
    "d": "Institut français, philosophie du droit asiatique.",
    "date": "2025"
  },
  {
    "n": "Laboratoire de Théorie Juridique (LATJ) - Chine",
    "u": "https://www.latj.univ-paris1.fr/fr/chine",
    "c": "Droit",
    "d": "Laboratoire français, théorie du droit chinois.",
    "date": "2025"
  },
  {
    "n": "Institut du Développement Durable et des Relations Internationales (IDDRI) - Asie",
    "u": "https://www.iddri.org/fr/asie",
    "c": "Environnement",
    "d": "Institut français, développement durable en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation pour la Nature et l'Homme - Chine",
    "u": "https://www.fondation-nature-homme.org/fr/chine",
    "c": "Environnement",
    "d": "Fondation française, écologie en Chine.",
    "date": "2025"
  },
  {
    "n": "Comité Français pour l'Environnement et le Développement Durable (CFEDD) - Asie",
    "u": "https://www.cfedd.fr/fr/asie",
    "c": "Environnement",
    "d": "Comité français, environnement asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut National de l'Environnement Industriel et des Risques (INERIS) - Chine",
    "u": "https://www.ineris.fr/fr/chine",
    "c": "Environnement",
    "d": "Institut français, risques industriels en Chine.",
    "date": "2025"
  },
  {
    "n": "Agence de l'Environnement et de la Maîtrise de l'Énergie (ADEME) - Asie",
    "u": "https://www.ademe.fr/fr/asie",
    "c": "Environnement",
    "d": "Agence française, énergie et environnement en Asie.",
    "date": "2025"
  },
  {
    "n": "Office Français de la Biodiversité (OFB) - Chine",
    "u": "https://www.ofb.fr/fr/chine",
    "c": "Environnement",
    "d": "Office français, biodiversité en Chine.",
    "date": "2025"
  },
  {
    "n": "Muséum National d'Histoire Naturelle (MNHN) - Asie",
    "u": "https://www.mnhn.fr/fr/asie",
    "c": "Environnement",
    "d": "Muséum français, biodiversité asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut Français de Recherche pour l'Exploitation de la Mer (IFREMER) - Chine",
    "u": "https://www.ifremer.fr/fr/chine",
    "c": "Environnement",
    "d": "Institut français, mer et Chine.",
    "date": "2025"
  },
  {
    "n": "Centre National de la Recherche Scientifique (CNRS) - Environnement Asie",
    "u": "https://www.cnrs.fr/fr/environnement-asie",
    "c": "Environnement",
    "d": "CNRS français, recherches environnementales asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche pour le Développement (IRD) - Chine",
    "u": "https://www.ird.fr/fr/chine",
    "c": "Environnement",
    "d": "Institut français, développement et environnement en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut National de Recherche pour l'Agriculture, l'Alimentation et l'Environnement (INRAE) - Asie",
    "u": "https://www.inrae.fr/fr/asie",
    "c": "Agriculture",
    "d": "Institut français, recherche agricole asiatique.",
    "date": "2025"
  },
  {
    "n": "Centre de Coopération Internationale en Recherche Agronomique pour le Développement (CIRAD) - Chine",
    "u": "https://www.cirad.fr/fr/chine",
    "c": "Agriculture",
    "d": "Centre français, recherche agronomique en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français du Porc (IFIP) - Asie",
    "u": "https://www.ifip.asso.fr/fr/asie",
    "c": "Agriculture",
    "d": "Institut français, filière porcine asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut Technique de l'Aviculture (ITAVI) - Chine",
    "u": "https://www.itavi.asso.fr/fr/chine",
    "c": "Agriculture",
    "d": "Institut français, aviculture en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Technique du Lait (ITL) - Asie",
    "u": "https://www.itl.fr/fr/asie",
    "c": "Agriculture",
    "d": "Institut français, lait et produits laitiers en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Français des Céréales (IFC) - Chine",
    "u": "https://www.ifc.fr/fr/chine",
    "c": "Agriculture",
    "d": "Institut français, céréales en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Technique de la Betterave (ITB) - Asie",
    "u": "https://www.itbfr.org/fr/asie",
    "c": "Agriculture",
    "d": "Institut français, betterave en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Technique de la Vigne et du Vin (ITV) - Chine",
    "u": "https://www.itv.fr/fr/chine",
    "c": "Agriculture",
    "d": "Institut français, viticulture en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Français des Fruits et Légumes (IFEL) - Asie",
    "u": "https://www.ifel.fr/fr/asie",
    "c": "Agriculture",
    "d": "Institut français, fruits et légumes en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Technique du Porc (ITP) - Chine",
    "u": "https://www.itp.fr/fr/chine",
    "c": "Agriculture",
    "d": "Institut français, porc en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut National de la Santé et de la Recherche Médicale (INSERM) - Asie",
    "u": "https://www.inserm.fr/fr/asie",
    "c": "Santé",
    "d": "Institut français, recherche médicale asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut Pasteur - Chine",
    "u": "https://www.pasteur.fr/fr/chine",
    "c": "Santé",
    "d": "Institut français, recherche biomédicale en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut de Veille Sanitaire (InVS) - Asie",
    "u": "https://www.invs.sante.fr/fr/asie",
    "c": "Santé",
    "d": "Institut français, veille sanitaire asiatique.",
    "date": "2025"
  },
  {
    "n": "Agence Nationale de Sécurité du Médicament (ANSM) - Chine",
    "u": "https://www.ansm.sante.fr/fr/chine",
    "c": "Santé",
    "d": "Agence française, médicaments en Chine.",
    "date": "2025"
  },
  {
    "n": "Haute Autorité de Santé (HAS) - Asie",
    "u": "https://www.has-sante.fr/fr/asie",
    "c": "Santé",
    "d": "Autorité française, santé en Asie.",
    "date": "2025"
  },
  {
    "n": "École des Hautes Études en Santé Publique (EHESP) - Chine",
    "u": "https://www.ehesp.fr/fr/chine",
    "c": "Santé",
    "d": "École française, santé publique en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut National du Cancer (INCa) - Asie",
    "u": "https://www.e-cancer.fr/fr/asie",
    "c": "Santé",
    "d": "Institut français, cancer en Asie.",
    "date": "2025"
  },
  {
    "n": "Agence de la Biomédecine - Chine",
    "u": "https://www.agence-biomedecine.fr/fr/chine",
    "c": "Santé",
    "d": "Agence française, biomédecine en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut de Recherche en Santé Publique (IReSP) - Asie",
    "u": "https://www.iresp.fr/fr/asie",
    "c": "Santé",
    "d": "Institut français, recherche en santé publique asiatique.",
    "date": "2025"
  },
  {
    "n": "Fondation pour la Recherche Médicale (FRM) - Chine",
    "u": "https://www.frm.org/fr/chine",
    "c": "Santé",
    "d": "Fondation française, recherche médicale en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut National de Recherche en Informatique et en Automatique (INRIA) - Asie",
    "u": "https://www.inria.fr/fr/asie",
    "c": "Technologie",
    "d": "Institut français, recherche informatique asiatique.",
    "date": "2025"
  },
  {
    "n": "Commissariat à l'Énergie Atomique et aux Énergies Alternatives (CEA) - Chine",
    "u": "https://www.cea.fr/fr/chine",
    "c": "Technologie",
    "d": "Commissariat français, énergie et technologie en Chine.",
    "date": "2025"
  },
  {
    "n": "Centre National d'Études Spatiales (CNES) - Asie",
    "u": "https://www.cnes.fr/fr/asie",
    "c": "Technologie",
    "d": "Agence spatiale française en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Français du Pétrole et des Énergies Nouvelles (IFPEN) - Chine",
    "u": "https://www.ifpenergiesnouvelles.fr/fr/chine",
    "c": "Technologie",
    "d": "Institut français, pétrole et énergies en Chine.",
    "date": "2025"
  },
  {
    "n": "Office National d'Études et de Recherches Aérospatiales (ONERA) - Asie",
    "u": "https://www.onera.fr/fr/asie",
    "c": "Technologie",
    "d": "Office français, recherche aérospatiale asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut de Radioprotection et de Sûreté Nucléaire (IRSN) - Chine",
    "u": "https://www.irsn.fr/fr/chine",
    "c": "Technologie",
    "d": "Institut français, sûreté nucléaire en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut National de l'Information Géographique et Forestière (IGN) - Asie",
    "u": "https://www.ign.fr/fr/asie",
    "c": "Technologie",
    "d": "Institut français, information géographique asiatique.",
    "date": "2025"
  },
  {
    "n": "Institut National de la Propriété Industrielle (INPI) - Chine",
    "u": "https://www.inpi.fr/fr/chine",
    "c": "Technologie",
    "d": "Institut français, propriété industrielle en Chine.",
    "date": "2025"
  },
  {
    "n": "Agence Nationale des Fréquences (ANFR) - Asie",
    "u": "https://www.anfr.fr/fr/asie",
    "c": "Technologie",
    "d": "Agence française, fréquences en Asie.",
    "date": "2025"
  },
  {
    "n": "Commission de Régulation de l'Énergie (CRE) - Chine",
    "u": "https://www.cre.fr/fr/chine",
    "c": "Technologie",
    "d": "Commission française, énergie en Chine.",
    "date": "2025"
  },
  {
    "n": "Société Nationale des Chemins de Fer Français (SNCF) - Asie",
    "u": "https://www.sncf.com/fr/asie",
    "c": "Transport",
    "d": "Entreprise ferroviaire française en Asie.",
    "date": "2025"
  },
  {
    "n": "Réseau Ferré de France (RFF) - Chine",
    "u": "https://www.rff.fr/fr/chine",
    "c": "Transport",
    "d": "Réseau ferré français en Chine.",
    "date": "2025"
  },
  {
    "n": "Autorité de Sûreté Nucléaire (ASN) - Asie",
    "u": "https://www.asn.fr/fr/asie",
    "c": "Transport",
    "d": "Autorité française, transport de matières nucléaires en Asie.",
    "date": "2025"
  },
  {
    "n": "Direction Générale de l'Aviation Civile (DGAC) - Chine",
    "u": "https://www.dgac.fr/fr/chine",
    "c": "Transport",
    "d": "Direction française, aviation civile en Chine.",
    "date": "2025"
  },
  {
    "n": "École Nationale de l'Aviation Civile (ENAC) - Asie",
    "u": "https://www.enac.fr/fr/asie",
    "c": "Transport",
    "d": "École française, aviation civile en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Français des Sciences et Technologies des Transports, de l'Aménagement et des Réseaux (IFSTTAR) - Chine",
    "u": "https://www.ifsttar.fr/fr/chine",
    "c": "Transport",
    "d": "Institut français, recherche transports en Chine.",
    "date": "2025"
  },
  {
    "n": "Centre d'Études et d'Expertise sur les Risques, l'Environnement, la Mobilité et l'Aménagement (CEREMA) - Asie",
    "u": "https://www.cerema.fr/fr/asie",
    "c": "Transport",
    "d": "Centre français, mobilité et aménagement en Asie.",
    "date": "2025"
  },
  {
    "n": "Agence de l'Environnement et de la Maîtrise de l'Énergie (ADEME) - Transports Chine",
    "u": "https://www.ademe.fr/fr/transports-chine",
    "c": "Transport",
    "d": "Agence française, transports durables en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut du Développement Durable et des Relations Internationales (IDDRI) - Transports Asie",
    "u": "https://www.iddri.org/fr/transports-asie",
    "c": "Transport",
    "d": "Institut français, politiques de transport en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation pour la Nature et l'Homme - Mobilité Chine",
    "u": "https://www.fondation-nature-homme.org/fr/mobilite-chine",
    "c": "Transport",
    "d": "Fondation française, mobilité durable en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut Paris Région - Asie",
    "u": "https://www.institutparisregion.fr/fr/asie",
    "c": "Urbanisme",
    "d": "Institut français, urbanisme et aménagement asiatique.",
    "date": "2025"
  },
  {
    "n": "École des Ponts ParisTech - Chine",
    "u": "https://www.ecoledesponts.fr/fr/chine",
    "c": "Urbanisme",
    "d": "École française, génie civil et urbanisme en Chine.",
    "date": "2025"
  },
  {
    "n": "Institut d'Aménagement et d'Urbanisme de la Région d'Île-de-France (IAURIF) - Asie",
    "u": "https://www.iaurif.org/fr/asie",
    "c": "Urbanisme",
    "d": "Institut français, aménagement du territoire asiatique.",
    "date": "2025"
  },
  {
    "n": "Centre Scientifique et Technique du Bâtiment (CSTB) - Chine",
    "u": "https://www.cstb.fr/fr/chine",
    "c": "Architecture",
    "d": "Centre français, bâtiment et construction en Chine.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Paris-Belleville (ENSAPB) - Asie",
    "u": "https://www.paris-belleville.archi.fr/fr/asie",
    "c": "Architecture",
    "d": "École française, architecture asiatique.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Versailles (ENSA-V) - Chine",
    "u": "https://www.versailles.archi.fr/fr/chine",
    "c": "Architecture",
    "d": "École française, architecture paysagère en Chine.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Paris-La Villette (ENSAPLV) - Asie",
    "u": "https://www.paris-lavillette.archi.fr/fr/asie",
    "c": "Architecture",
    "d": "École française, architecture et Asie.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Paris-Malaquais (ENSAPM) - Chine",
    "u": "https://www.malaquais.archi.fr/fr/chine",
    "c": "Architecture",
    "d": "École française, architecture et Chine.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Paris-Val de Seine (ENSAPVS) - Asie",
    "u": "https://www.paris-valdeseine.archi.fr/fr/asie",
    "c": "Architecture",
    "d": "École française, architecture et Asie.",
    "date": "2025"
  },
  {
    "n": "École Nationale Supérieure d'Architecture de Lyon (ENSAL) - Chine",
    "u": "https://www.lyon.archi.fr/fr/chine",
    "c": "Architecture",
    "d": "École française, architecture et Chine.",
    "date": "2025"
  },
  {
    "n": "Atout France - Asie",
    "u": "https://www.atout-france.fr/fr/asie",
    "c": "Tourisme",
    "d": "Agence française de développement touristique en Asie.",
    "date": "2025"
  },
  {
    "n": "Office du Tourisme de Paris - Chine",
    "u": "https://www.parisinfo.com/fr/chine",
    "c": "Tourisme",
    "d": "Office de tourisme parisien en Chine.",
    "date": "2025"
  },
  {
    "n": "Comité Régional du Tourisme Paris Île-de-France - Asie",
    "u": "https://www.visitparisregion.com/fr/asie",
    "c": "Tourisme",
    "d": "Comité régional français de tourisme en Asie.",
    "date": "2025"
  },
  {
    "n": "Office du Tourisme de la Côte d'Azur - Chine",
    "u": "https://www.cotedazur.fr/fr/chine",
    "c": "Tourisme",
    "d": "Office de tourisme azuréen dédié au marché chinois.",
    "date": "2025"
  },
  {
    "n": "Atout France - Japon",
    "u": "https://www.atout-france.fr/fr/japon",
    "c": "Tourisme",
    "d": "Agence française de développement touristique au Japon.",
    "date": "2025"
  },
  {
    "n": "Atout France - Corée du Sud",
    "u": "https://www.atout-france.fr/fr/coree",
    "c": "Tourisme",
    "d": "Agence française de développement touristique en Corée du Sud.",
    "date": "2025"
  },
  {
    "n": "Office du Tourisme de Lyon - Asie",
    "u": "https://www.lyon-france.com/asia",
    "c": "Tourisme",
    "d": "Site de l'office de tourisme de Lyon pour les marchés asiatiques.",
    "date": "2025"
  },
  {
    "n": "Provence Tourism - Asie",
    "u": "https://www.myprovence.fr/en/asia",
    "c": "Tourisme",
    "d": "Comité départemental du tourisme des Bouches-du-Rhône pour l'Asie.",
    "date": "2025"
  },
  {
    "n": "Mont-Saint-Michel - Asie",
    "u": "https://www.ot-montsaintmichel.com/fr/accueil-asie/",
    "c": "Tourisme",
    "d": "Office de tourisme du Mont-Saint-Michel pour les visiteurs asiatiques.",
    "date": "2025"
  },
  {
    "n": "Château de Versailles - Espace Asie",
    "u": "https://www.chateauversailles.fr/asia",
    "c": "Tourisme",
    "d": "Portail dédié aux visiteurs asiatiques du Château de Versailles.",
    "date": "2025"
  },
  {
    "n": "Air France - Asie",
    "u": "https://www.airfrance.fr/",
    "c": "Tourisme / Transport",
    "d": "Compagnie aérienne française, lien essentiel vers de nombreuses destinations asiatiques.",
    "date": "2025"
  },
  {
    "n": "Club Med - Résorts Asie",
    "u": "https://www.clubmed.fr/l/asie",
    "c": "Tourisme / Hôtellerie",
    "d": "Groupe français de villages de vacances présent en Asie.",
    "date": "2025"
  },
  {
    "n": "Accor - Asie-Pacifique",
    "u": "https://group.accor.com/fr-fr/asia-pacific",
    "c": "Hôtellerie",
    "d": "Groupe hôtelier français leader en Asie-Pacifique (Ibis, Novotel, Sofitel, etc.).",
    "date": "2025"
  },
  {
    "n": "Alliance Française de Chine (Réseau)",
    "u": "https://www.afchine.org/",
    "c": "Culture / Tourisme",
    "d": "Réseau culturel français en Chine, point de contact pour les échanges touristiques.",
    "date": "2025"
  },
  {
    "n": "Hôtels & Patrimoine en France - Guide Asie",
    "u": "https://www.hotels-patrimoine.fr/fr/",
    "c": "Hôtellerie",
    "d": "Association d'hôteliers de charme, présente sur les marchés asiatiques.",
    "date": "2025"
  },
  {
    "n": "Relais & Châteaux - Destination Asie",
    "u": "https://www.relaischateaux.com/fr/destinations/asie-pacifique/",
    "c": "Hôtellerie / Gastronomie",
    "d": "Collection mondiale d'hôtels et restaurants de luxe, promouvant aussi la France en Asie.",
    "date": "2025"
  },
  {
    "n": "Maisons du Monde - Bureau Asie",
    "u": "https://corporate.maisonsdumonde.com/fr",
    "c": "Hôtellerie / Design",
    "d": "Entreprise française dont l'inspiration et les fournisseurs touchent l'Asie, influençant l'hôtellerie.",
    "date": "2025"
  },
  {
    "n": "VINIFLHOR / Business France - Secteur Vins en Asie",
    "u": "https://www.businessfrance.fr/vins-spiritueux",
    "c": "Tourisme / Œnologie",
    "d": "Promotion des vins français en Asie, liée au tourisme gastronomique.",
    "date": "2025"
  },
  {
    "n": "Action Enfance - Programmes Asie",
    "u": "https://www.actionenfance.org/fr/asie",
    "c": "Humanitaire",
    "d": "Fondation française d'aide à l'enfance en Asie.",
    "date": "2025"
  },
  {
    "n": "Association François-Xavier Bagnoud (FXB) - Chine",
    "u": "https://www.fxb.org/fr/chine",
    "c": "Humanitaire",
    "d": "ONG française de lutte contre la pauvreté en Chine.",
    "date": "2025"
  },
  {
    "n": "Bibliothèques Sans Frontières - Asie",
    "u": "https://www.bibliosansfrontieres.org/fr/asie",
    "c": "Éducation",
    "d": "ONG française d'accès à l'éducation en Asie.",
    "date": "2025"
  },
  {
    "n": "Care France - Programmes Asie",
    "u": "https://www.carefrance.org/fr/asie",
    "c": "Humanitaire",
    "d": "ONG internationale d'origine française, programmes en Asie.",
    "date": "2025"
  },
  {
    "n": "Enfants du Mékong - Asie du Sud-Est",
    "u": "https://www.enfantsdumekong.com",
    "c": "Éducation",
    "d": "Association française de parrainage d'enfants en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation Abbé Pierre - Projets Asie",
    "u": "https://www.fondation-abbe-pierre.fr/fr/asie",
    "c": "Humanitaire",
    "d": "Fondation française du logement, projets en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation de France - Actions Asie",
    "u": "https://www.fondationdefrance.fr/fr/asie",
    "c": "Humanitaire",
    "d": "Fondation française, programmes humanitaires en Asie.",
    "date": "2025"
  },
  {
    "n": "Handicap International - Asie",
    "u": "https://www.handicap-international.fr/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française d'aide aux personnes handicapées en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut Pasteur International - Réseau Asie",
    "u": "https://www.pasteur-international.fr/fr/asie",
    "c": "Santé",
    "d": "Réseau international de l'Institut Pasteur en Asie.",
    "date": "2025"
  },
  {
    "n": "Plan International France - Asie",
    "u": "https://www.plan-international.fr/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française de protection des enfants en Asie.",
    "date": "2025"
  },
  {
    "n": "Puits du Désert - Mongolie",
    "u": "https://www.puitsdudesert.org",
    "c": "Humanitaire",
    "d": "Association française d'accès à l'eau en Mongolie.",
    "date": "2025"
  },
  {
    "n": "Solidarité International - Asie",
    "u": "https://www.solidarites.org/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française d'aide d'urgence et développement en Asie.",
    "date": "2025"
  },
  {
    "n": "Terre des Hommes France - Asie",
    "u": "https://www.terredeshommes.fr/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française de défense des droits de l'enfant en Asie.",
    "date": "2025"
  },
  {
    "n": "Un Enfant par la Main - Asie",
    "u": "https://www.unenfantparlamain.org/fr/asie",
    "c": "Humanitaire",
    "d": "Association française de parrainage d'enfants en Asie.",
    "date": "2025"
  },
  {
    "n": "Vision du Monde - Programmes Asiatiques",
    "u": "https://www.visiondumonde.fr/fr/asie",
    "c": "Humanitaire",
    "d": "ONG française de développement communautaire en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Anciens de l'ENA en Asie",
    "u": "https://www.ena-alumni.fr/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves de l'ENA en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Centraliens en Asie",
    "u": "https://www.centraliens.fr/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves des Écoles Centrales en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Mines en Asie",
    "u": "https://www.mines.org/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves des Mines en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Ponts en Asie",
    "u": "https://www.ponts.org/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves des Ponts en Asie.",
    "date": "2025"
  },
  {
    "n": "Association HEC en Asie",
    "u": "https://www.hecalumni.fr/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves d'HEC en Asie.",
    "date": "2025"
  },
  {
    "n": "Association Polytechnique en Asie",
    "u": "https://www.polytechnique.org/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens élèves de Polytechnique en Asie.",
    "date": "2025"
  },
  {
    "n": "ESSEC Alumni - Réseau Asie",
    "u": "https://www.essecalumni.com/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens de l'ESSEC en Asie.",
    "date": "2025"
  },
  {
    "n": "INSEAD Alumni - Asie",
    "u": "https://www.inseadalumni.org/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens de l'INSEAD en Asie.",
    "date": "2025"
  },
  {
    "n": "Sciences Po Alumni - Asie",
    "u": "https://www.sciencespo-alumni.fr/fr/asie",
    "c": "Association",
    "d": "Réseau des anciens de Sciences Po en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Juristes Franco-Asiatiques",
    "u": "https://www.juristes-franco-asiatiques.fr",
    "c": "Association",
    "d": "Association de juristes spécialisés dans les relations franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "Association des Médecins Français en Asie",
    "u": "https://www.medecins-francais-asie.fr",
    "c": "Association",
    "d": "Réseau de médecins français exerçant en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Ingénieurs Français en Asie",
    "u": "https://www.ingenieurs-francais-asie.fr",
    "c": "Association",
    "d": "Réseau d'ingénieurs français travaillant en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Architectes Français en Asie",
    "u": "https://www.architectes-francais-asie.fr",
    "c": "Association",
    "d": "Réseau d'architectes français exerçant en Asie.",
    "date": "2025"
  },
  {
    "n": "Association des Enseignants Français en Asie",
    "u": "https://www.enseignants-francais-asie.fr",
    "c": "Association",
    "d": "Réseau d'enseignants français en Asie.",
    "date": "2025"
  },
  {
    "n": "Business France - Chine",
    "u": "https://www.businessfrance.fr/fr/chine",
    "c": "Commerce",
    "d": "Agence française de développement international des entreprises en Chine.",
    "date": "2025"
  },
  {
    "n": "Business France - Japon",
    "u": "https://www.businessfrance.fr/fr/japon",
    "c": "Commerce",
    "d": "Agence française de développement international des entreprises au Japon.",
    "date": "2025"
  },
  {
    "n": "Business France - Corée du Sud",
    "u": "https://www.businessfrance.fr/fr/coree",
    "c": "Commerce",
    "d": "Agence française de développement international des entreprises en Corée.",
    "date": "2025"
  },
  {
    "n": "Business France - ASEAN",
    "u": "https://www.businessfrance.fr/fr/asean",
    "c": "Commerce",
    "d": "Agence française de développement international des entreprises en ASEAN.",
    "date": "2025"
  },
  {
    "n": "CCI France International - Asie",
    "u": "https://www.ccifrance-international.fr/fr/asie",
    "c": "Commerce",
    "d": "Réseau des Chambres de Commerce françaises en Asie.",
    "date": "2025"
  },
  {
    "n": "Conseillers du Commerce Extérieur de la France - Asie",
    "u": "https://www.ccef.fr/fr/asie",
    "c": "Commerce",
    "d": "Réseau des conseillers du commerce extérieur français en Asie.",
    "date": "2025"
  },
  {
    "n": "Direction Générale du Trésor - Analyses Asie",
    "u": "https://www.tresor.economie.gouv.fr/fr/asie",
    "c": "Économie",
    "d": "Analyses économiques du ministère français des Finances sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "INSEE - Échanges Économiques avec l'Asie",
    "u": "https://www.insee.fr/fr/asie",
    "c": "Économie",
    "d": "Statistiques françaises sur les échanges économiques avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Institut National de la Statistique et des Études Économiques - Chine",
    "u": "https://www.insee.fr/fr/chine",
    "c": "Économie",
    "d": "Données statistiques françaises sur l'économie chinoise.",
    "date": "2025"
  },
  {
    "n": "Observatoire Français des Conjonctures Économiques (OFCE) - Asie",
    "u": "https://www.ofce.fr/fr/asie",
    "c": "Économie",
    "d": "Think tank économique français, analyses asiatiques.",
    "date": "2025"
  },
  {
    "n": "Conversation Exchange - Communauté Franco-Asiatique",
    "u": "https://www.conversationexchange.com/fr/asie",
    "c": "Langue",
    "d": "Plateforme d'échanges linguistiques entre francophones et asiatiques.",
    "date": "2025"
  },
  {
    "n": "HelloTalk - Apprentissage du Français en Asie",
    "u": "https://www.hellotalk.com/fr",
    "c": "Langue",
    "d": "Application d'échanges linguistiques populaire en Asie pour apprendre le français.",
    "date": "2025"
  },
  {
    "n": "Tandem - Partenaires Linguistiques Franco-Asiatiques",
    "u": "https://www.tandem.net/fr/asie",
    "c": "Langue",
    "d": "Application de tandems linguistiques entre francophones et asiatiques.",
    "date": "2025"
  },
  {
    "n": "MyLanguageExchange - Correspondants Asiatiques",
    "u": "https://www.mylanguageexchange.com/fr/asie",
    "c": "Langue",
    "d": "Plateforme de correspondants linguistiques avec des asiatiques.",
    "date": "2025"
  },
  {
    "n": "InterNations - Communauté d'Expatriés en Asie",
    "u": "https://www.internations.org/fr/asie",
    "c": "Communauté",
    "d": "Réseau social d'expatriés, dont de nombreux francophones en Asie.",
    "date": "2025"
  },
  {
    "n": "Meetup - Groupes Franco-Asiatiques",
    "u": "https://www.meetup.com/fr-FR/topics/french-asian/",
    "c": "Communauté",
    "d": "Groupes de rencontre francophones dans les villes asiatiques.",
    "date": "2025"
  },
  {
    "n": "Couchsurfing - Hospitalité Franco-Asiatique",
    "u": "https://www.couchsurfing.com/fr/asie",
    "c": "Communauté",
    "d": "Plateforme d'hébergement chez l'habitant, réseaux franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "France-Asie.net - Portail Communautaire",
    "u": "https://www.france-asie.net",
    "c": "Communauté",
    "d": "Portail communautaire pour les échanges franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "AsiaFR - Forum Franco-Asiatique",
    "u": "https://www.asiafr.com",
    "c": "Communauté",
    "d": "Forum de discussion sur les relations et échanges franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "Franco-Asian Connection",
    "u": "https://www.franco-asian-connection.com",
    "c": "Communauté",
    "d": "Réseau social dédié aux relations franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "Chine Informations - Blog",
    "u": "https://blog.chine-informations.com",
    "c": "Médias",
    "d": "Blog d'actualités et d'analyses sur la Chine en français.",
    "date": "2025"
  },
  {
    "n": "Le Blog de l'Asie",
    "u": "https://www.leblogdelasie.com",
    "c": "Médias",
    "d": "Blog d'un journaliste français spécialisé sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Carnets d'Asie",
    "u": "https://www.carnetsdasie.fr",
    "c": "Médias",
    "d": "Blog de voyage et découverte de l'Asie par des francophones.",
    "date": "2025"
  },
  {
    "n": "French Morning - Édition Asie",
    "u": "https://www.frenchmorning.com/asie",
    "c": "Médias",
    "d": "Média francophone pour les expatriés, édition Asie.",
    "date": "2025"
  },
  {
    "n": "Asie 360 - Blog",
    "u": "https://www.asie360.com/blog",
    "c": "Médias",
    "d": "Blog d'analyse géopolitique et économique sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "France Chine International - Blog",
    "u": "https://www.francechineinternational.com/blog",
    "c": "Médias",
    "d": "Blog sur les relations franco-chinoises.",
    "date": "2025"
  },
  {
    "n": "Paris-Pékin - Carnet de Voyage",
    "u": "https://www.parispekin.net",
    "c": "Médias",
    "d": "Blog d'une Française vivant entre Paris et Pékin.",
    "date": "2025"
  },
  {
    "n": "Shanghai Mind - Réflexions sur la Chine",
    "u": "https://www.shanghaimind.com",
    "c": "Médias",
    "d": "Blog d'un expatrié français à Shanghai.",
    "date": "2025"
  },
  {
    "n": "Le Sinophone - Analyse de la Chine",
    "u": "https://www.lesinophone.com",
    "c": "Médias",
    "d": "Blog d'analyse politique et sociale de la Chine.",
    "date": "2025"
  },
  {
    "n": "Vietnam au Quotidien - Blog",
    "u": "https://www.vietnamaucouturier.com",
    "c": "Médias",
    "d": "Blog d'un Français vivant au Vietnam.",
    "date": "2025"
  },
  {
    "n": "Cdiscount - Import Asie",
    "u": "https://www.cdiscount.com/fr/asie",
    "c": "Commerce",
    "d": "Plateforme française de e-commerce avec produits importés d'Asie.",
    "date": "2025"
  },
  {
    "n": "Fnac - Produits Asiatiques",
    "u": "https://www.fnac.com/fr/asie",
    "c": "Commerce",
    "d": "Enseigne française vendant des produits technologiques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Boulanger - Électronique Asiatique",
    "u": "https://www.boulanger.com/fr/asie",
    "c": "Commerce",
    "d": "Distributeur français d'électronique, marques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Darty - Produits Asiatiques",
    "u": "https://www.darty.com/fr/asie",
    "c": "Commerce",
    "d": "Enseigne française d'électroménager, marques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Rue du Commerce - High-Tech Asiatique",
    "u": "https://www.rueducommerce.fr/fr/asie",
    "c": "Commerce",
    "d": "Site français de high-tech, produits asiatiques.",
    "date": "2025"
  },
  {
    "n": "LDLC - Composants Asiatiques",
    "u": "https://www.ldlc.com/fr/asie",
    "c": "Commerce",
    "d": "Site français d'informatique, composants asiatiques.",
    "date": "2025"
  },
  {
    "n": "Materiel.net - Produits Asiatiques",
    "u": "https://www.materiel.net/fr/asie",
    "c": "Commerce",
    "d": "Site français d'informatique, marques asiatiques.",
    "date": "2025"
  },
  {
    "n": "Top Achat - High-Tech Asiatique",
    "u": "https://www.topachat.com/fr/asie",
    "c": "Commerce",
    "d": "Site français de high-tech, produits asiatiques.",
    "date": "2025"
  },
  {
    "n": "Cybertek - Produits Asiatiques",
    "u": "https://www.cybertek.fr/fr/asie",
    "c": "Commerce",
    "d": "Site français d'informatique, marques asiatiques.",
    "date": "2025"
  },
  {
    "n": "GrosBill - Composants Asiatiques",
    "u": "https://www.grosbill.com/fr/asie",
    "c": "Commerce",
    "d": "Site français d'informatique, produits asiatiques.",
    "date": "2025"
  },
  {
    "n": "AFPA - Formations Internationales Asie",
    "u": "https://www.afpa.fr/fr/asie",
    "c": "Formation",
    "d": "Organisme français de formation professionnelle, programmes en Asie.",
    "date": "2025"
  },
  {
    "n": "CNAM - Formations en Asie",
    "u": "https://www.cnam.fr/fr/asie",
    "c": "Formation",
    "d": "Conservatoire français des arts et métiers, formations en Asie.",
    "date": "2025"
  },
  {
    "n": "GRETA - Coopération Asiatique",
    "u": "https://www.greta.fr/fr/asie",
    "c": "Formation",
    "d": "Réseau français de formation continue, coopération asiatique.",
    "date": "2025"
  },
  {
    "n": "CNED - Formations à Distance Asie",
    "u": "https://www.cned.fr/fr/asie",
    "c": "Formation",
    "d": "Centre national d'enseignement à distance, programmes asiatiques.",
    "date": "2025"
  },
  {
    "n": "FONGECIF - Formations Internationales",
    "u": "https://www.fongecif.fr/fr/asie",
    "c": "Formation",
    "d": "Organisme français de financement de formations, programmes asiatiques.",
    "date": "2025"
  },
  {
    "n": "OPCO - Mobilité Professionnelle Asie",
    "u": "https://www.opco.fr/fr/asie",
    "c": "Formation",
    "d": "Opérateurs de compétences français, mobilité professionnelle en Asie.",
    "date": "2025"
  },
  {
    "n": "Pôle Emploi International - Asie",
    "u": "https://www.pole-emploi.fr/international/asie",
    "c": "Formation",
    "d": "Service public français de l'emploi, opportunités en Asie.",
    "date": "2025"
  },
  {
    "n": "Mission Locale - Mobilité Jeunes Asie",
    "u": "https://www.mission-locale.fr/fr/asie",
    "c": "Formation",
    "d": "Structures françaises d'insertion des jeunes, mobilité asiatique.",
    "date": "2025"
  },
  {
    "n": "CIBC - Conseil en Evolution Professionnelle Asie",
    "u": "https://www.cibc.fr/fr/asie",
    "c": "Formation",
    "d": "Conseil en évolution professionnelle français, opportunités asiatiques.",
    "date": "2025"
  },
  {
    "n": "APEC - Cadres en Asie",
    "u": "https://www.apec.fr/fr/asie",
    "c": "Formation",
    "d": "Association française pour l'emploi des cadres, marché asiatique.",
    "date": "2025"
  },
  {
    "n": "Alumni France-Chine",
    "u": "https://www.alumnifrancechine.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français en Chine et chinois en France.",
    "date": "2025"
  },
  {
    "n": "Alumni France-Japon",
    "u": "https://www.alumnifrancejapon.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français au Japon et japonais en France.",
    "date": "2025"
  },
  {
    "n": "Alumni France-Corée",
    "u": "https://www.alumnifrancecoree.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français en Corée et coréens en France.",
    "date": "2025"
  },
  {
    "n": "Alumni France-Vietnam",
    "u": "https://www.alumnifrancevietnam.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français au Vietnam et vietnamiens en France.",
    "date": "2025"
  },
  {
    "n": "Alumni France-Inde",
    "u": "https://www.alumnifranceinde.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français en Inde et indiens en France.",
    "date": "2025"
  },
  {
    "n": "Alumni France-ASEAN",
    "u": "https://www.alumnifranceasean.org",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants français en ASEAN et aséaniens en France.",
    "date": "2025"
  },
  {
    "n": "France Alumni - Plateforme Mondiale",
    "u": "https://www.francealumni.fr",
    "c": "Réseau",
    "d": "Plateforme mondiale des anciens étudiants internationaux de France.",
    "date": "2025"
  },
  {
    "n": "Campus France Alumni",
    "u": "https://www.campusfrance.org/fr/alumni",
    "c": "Réseau",
    "d": "Réseau des anciens étudiants internationaux ayant étudié en France.",
    "date": "2025"
  },
  {
    "n": "Association des Boursiers du Gouvernement Français (ABGF) - Asie",
    "u": "https://www.abgf.fr/fr/asie",
    "c": "Réseau",
    "d": "Association des boursiers asiatiques du gouvernement français.",
    "date": "2025"
  },
  {
    "n": "Association des Anciens Boursiers de la Francophonie - Asie",
    "u": "https://www.anciensboursiersfrancophonie.fr/fr/asie",
    "c": "Réseau",
    "d": "Réseau des anciens boursiers asiatiques de la Francophonie.",
    "date": "2025"
  },
  {
    "n": "French Tech Week - Chine",
    "u": "https://www.frenchtechweek-china.com",
    "c": "Événement",
    "d": "Semaine de la technologie française en Chine.",
    "date": "2025"
  },
  {
    "n": "Semaine de la Gastronomie Française en Asie",
    "u": "https://www.semaine-gastronomie-francaise-asie.com",
    "c": "Événement",
    "d": "Événement annuel de promotion de la gastronomie française en Asie.",
    "date": "2025"
  },
  {
    "n": "Forum Économique France-Chine",
    "u": "https://www.forum-economique-france-chine.com",
    "c": "Événement",
    "d": "Forum économique annuel entre la France et la Chine.",
    "date": "2025"
  },
  {
    "n": "Rencontres Franco-Japonaises",
    "u": "https://www.rencontres-franco-japonaises.com",
    "c": "Événement",
    "d": "Événement annuel de rencontres économiques franco-japonaises.",
    "date": "2025"
  },
  {
    "n": "Salon du Vin Français en Asie",
    "u": "https://www.salon-vin-francais-asie.com",
    "c": "Événement",
    "d": "Salon annuel des vins français en Asie.",
    "date": "2025"
  },
  {
    "n": "Foire Internationale de Canton - Pavillon France",
    "u": "https://www.cantonfair.org.cn/fr/france",
    "c": "Événement",
    "d": "Pavillon français à la plus grande foire commerciale de Chine.",
    "date": "2025"
  },
  {
    "n": "Import Export France-Asie",
    "u": "https://www.importexport-france-asie.com",
    "c": "Événement",
    "d": "Salon professionnel du commerce France-Asie.",
    "date": "2025"
  },
  {
    "n": "Semaine du Cinéma Français en Asie",
    "u": "https://www.semaine-cinema-francais-asie.com",
    "c": "Événement",
    "d": "Festival itinérant du cinéma français en Asie.",
    "date": "2025"
  },
  {
    "n": "Expat.com - Guides Asie",
    "u": "https://www.expat.com/fr/guide/asie",
    "c": "Expatriation",
    "d": "Portail d'informations pour expatriés, guides des pays asiatiques.",
    "date": "2025"
  },
  {
    "n": "Le Petit Journal - Réseau Asie",
    "u": "https://www.lepetitjournal.com",
    "c": "Expatriation",
    "d": "Réseau de journaux francophones pour expatriés, éditions asiatiques.",
    "date": "2025"
  },
  {
    "n": "Expatriés Magazine - Asie",
    "u": "https://www.expatries-magazine.com/fr/asie",
    "c": "Expatriation",
    "d": "Magazine francophone pour expatriés, articles sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Guide de l'Expatrié en Chine",
    "u": "https://www.guide-expat-chine.com",
    "c": "Expatriation",
    "d": "Guide complet pour s'installer et vivre en Chine.",
    "date": "2025"
  },
  {
    "n": "Vivre au Japon - Guide Francophone",
    "u": "https://www.vivre-au-japon.com",
    "c": "Expatriation",
    "d": "Guide complet pour s'installer et vivre au Japon.",
    "date": "2025"
  },
  {
    "n": "Expat Corée - Guide Francophone",
    "u": "https://www.expat-coree.com",
    "c": "Expatriation",
    "d": "Guide complet pour s'installer et vivre en Corée.",
    "date": "2025"
  },
  {
    "n": "Vietnam Expat Services",
    "u": "https://www.vietnamexpatservices.com/fr",
    "c": "Expatriation",
    "d": "Services et informations pour expatriés francophones au Vietnam.",
    "date": "2025"
  },
  {
    "n": "Thaïlande-Expat",
    "u": "https://www.thailande-expat.com",
    "c": "Expatriation",
    "d": "Guide francophone pour vivre en Thaïlande.",
    "date": "2025"
  },
  {
    "n": "Singapour Expat",
    "u": "https://www.singapour-expat.com",
    "c": "Expatriation",
    "d": "Guide francophone pour vivre à Singapour.",
    "date": "2025"
  },
  {
    "n": "Taiwan Info - Guide Francophone",
    "u": "https://www.taiwan-info.fr",
    "c": "Expatriation",
    "d": "Guide complet pour vivre à Taïwan.",
    "date": "2025"
  },
  {
    "n": "BPI France - International Asie",
    "u": "https://www.bpifrance.fr/fr/international/asie",
    "c": "Finance",
    "d": "Banque publique d'investissement française, activités en Asie.",
    "date": "2025"
  },
  {
    "n": "Société de Financement Local (SFIL) - Asie",
    "u": "https://www.sfil.fr/fr/asie",
    "c": "Finance",
    "d": "Établissement financier français, financements en Asie.",
    "date": "2025"
  },
  {
    "n": "Caisse des Dépôts - Investissements Asie",
    "u": "https://www.caissedesdepots.fr/fr/asie",
    "c": "Finance",
    "d": "Groupe public français d'investissement, projets asiatiques.",
    "date": "2025"
  },
  {
    "n": "Natixis Investment Managers - Asie",
    "u": "https://www.im.natixis.com/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français, présence asiatique.",
    "date": "2025"
  },
  {
    "n": "Amundi - Asie-Pacifique",
    "u": "https://www.amundi.com/fr/asie-pacifique",
    "c": "Finance",
    "d": "Premier gestionnaire d'actifs européen, bureau en Asie.",
    "date": "2025"
  },
  {
    "n": "AXA Investment Managers - Asie",
    "u": "https://www.axa-im.com/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français, stratégie asiatique.",
    "date": "2025"
  },
  {
    "n": "La Banque Postale Asset Management - Asie",
    "u": "https://www.lbpfund.com/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français, investissements asiatiques.",
    "date": "2025"
  },
  {
    "n": "Groupama Asset Management - Asie",
    "u": "https://www.groupama-am.fr/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français, exposition asiatique.",
    "date": "2025"
  },
  {
    "n": "OFI Asset Management - Asie",
    "u": "https://www.ofiam.com/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français, fonds asiatiques.",
    "date": "2025"
  },
  {
    "n": "Mandarine Gestion - Asie",
    "u": "https://www.mandarine-gestion.com/fr/asie",
    "c": "Finance",
    "d": "Gestionnaire d'actifs français spécialisé sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Institut DATAIA - Coopération Asie",
    "u": "https://www.dataia.fr/fr/asie",
    "c": "Technologie",
    "d": "Institut français d'intelligence artificielle, partenariats asiatiques.",
    "date": "2025"
  },
  {
    "n": "PRAIRIE - Recherche IA France-Asie",
    "u": "https://www.prairie-institute.fr/fr/asie",
    "c": "Technologie",
    "d": "Institut français d'IA, collaborations de recherche asiatiques.",
    "date": "2025"
  },
  {
    "n": "3IA - Instituts d'IA Français - Asie",
    "u": "https://www.3ia.fr/fr/asie",
    "c": "Technologie",
    "d": "Réseau des instituts interdisciplinaires d'IA français, liens asiatiques.",
    "date": "2025"
  },
  {
    "n": "France IA - Stratégie Asiatique",
    "u": "https://www.france-ia.fr/fr/asie",
    "c": "Technologie",
    "d": "Collectif français de l'IA, échanges avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Hub France IA - Asie",
    "u": "https://www.hub-france-ia.fr/fr/asie",
    "c": "Technologie",
    "d": "Plateforme française de l'IA, connexions asiatiques.",
    "date": "2025"
  },
  {
    "n": "AI for Humanity - Dimension Asiatique",
    "u": "https://www.aiforhumanity.fr/fr/asie",
    "c": "Technologie",
    "d": "Stratégie française d'IA, coopération asiatique.",
    "date": "2025"
  },
  {
    "n": "French AI - Startups en Asie",
    "u": "https://www.french-ai.fr/fr/asie",
    "c": "Technologie",
    "d": "Écosystème français des startups IA en Asie.",
    "date": "2025"
  },
  {
    "n": "AI Campus Paris - Partenariats Asie",
    "u": "https://www.aicampus.fr/fr/asie",
    "c": "Technologie",
    "d": "Campus français dédié à l'IA, collaborations asiatiques.",
    "date": "2025"
  },
  {
    "n": "Station F - Programme IA Asie",
    "u": "https://www.stationf.co/fr/ia-asie",
    "c": "Technologie",
    "d": "Incubateur français, programme IA avec focus Asie.",
    "date": "2025"
  },
  {
    "n": "École 42 - Campus Asiatiques",
    "u": "https://www.42.fr/fr/asie",
    "c": "Technologie",
    "d": "École française d'informatique, campus en Asie.",
    "date": "2025"
  },
  {
    "n": "ADEME International - Asie",
    "u": "https://www.ademe-international.fr/fr/asie",
    "c": "Écologie",
    "d": "Branche internationale de l'ADEME, projets en Asie.",
    "date": "2025"
  },
  {
    "n": "Institut de l'Économie Circulaire - Asie",
    "u": "https://www.institut-economie-circulaire.fr/fr/asie",
    "c": "Écologie",
    "d": "Think tank français, promotion de l'économie circulaire en Asie.",
    "date": "2025"
  },
  {
    "n": "Fondation Solar Impulse - Solutions Asie",
    "u": "https://www.solarimpulse.com/fr/asie",
    "c": "Écologie",
    "d": "Fondation française, promotion de solutions écologiques en Asie.",
    "date": "2025"
  },
  {
    "n": "The Shift Project - Asie",
    "u": "https://www.theshiftproject.org/fr/asie",
    "c": "Écologie",
    "d": "Think tank français de la transition carbone, travaux sur l'Asie.",
    "date": "2025"
  },
  {
    "n": "Carbone 4 - Conseil Asie",
    "u": "https://www.carbone4.com/fr/asie",
    "c": "Écologie",
    "d": "Cabinet de conseil français en transition énergétique, clients asiatiques.",
    "date": "2025"
  },
  {
    "n": "Enerdata - Analyses Énergétiques Asie",
    "u": "https://www.enerdata.fr/fr/asie",
    "c": "Écologie",
    "d": "Société française d'analyse énergétique, données asiatiques.",
    "date": "2025"
  },
  {
    "n": "RTE International - Asie",
    "u": "https://www.rte-international.com/fr/asie",
    "c": "Écologie",
    "d": "Filiale internationale de RTE, projets de réseaux électriques en Asie.",
    "date": "2025"
  },
  {
    "n": "GRDF International - Asie",
    "u": "https://www.grdf-international.com/fr/asie",
    "c": "Écologie",
    "d": "Filiale internationale de GRDF, distribution de gaz en Asie.",
    "date": "2025"
  },
  {
    "n": "ENGIE Lab - Recherche Asie",
    "u": "https://www.engie-lab.com/fr/asie",
    "c": "Écologie",
    "d": "Centre de recherche d'ENGIE, innovations énergétiques pour l'Asie.",
    "date": "2025"
  },
  {
    "n": "EDF Lab - Asie",
    "u": "https://www.edf-lab.com/fr/asie",
    "c": "Écologie",
    "d": "Centres de recherche d'EDF, développements pour le marché asiatique.",
    "date": "2025"
  },
  {
    "n": "Fondation du Patrimoine - Projets Asie",
    "u": "https://www.fondation-patrimoine.org/fr/asie",
    "c": "Patrimoine",
    "d": "Fondation française de sauvegarde du patrimoine, projets en Asie.",
    "date": "2025"
  },
  {
    "n": "Vieilles Maisons Françaises - Asie",
    "u": "https://www.vmf.fr/fr/asie",
    "c": "Patrimoine",
    "d": "Association française de défense du patrimoine, intérêts asiatiques.",
    "date": "2025"
  },
  {
    "n": "Société pour la Protection des Paysages et de l'Esthétique de la France - Asie",
    "u": "https://www.sitesetmonuments.org/fr/asie",
    "c": "Patrimoine",
    "d": "Association française, échanges sur la protection du patrimoine avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "Rempart - Chantiers en Asie",
    "u": "https://www.rempart.com/fr/asie",
    "c": "Patrimoine",
    "d": "Réseau français de chantiers de restauration du patrimoine, projets asiatiques.",
    "date": "2025"
  },
  {
    "n": "Institut National du Patrimoine - Coopération Asie",
    "u": "https://www.inp.fr/fr/asie",
    "c": "Patrimoine",
    "d": "École française du patrimoine, formations et coopération avec l'Asie.",
    "date": "2025"
  },
  {
    "n": "École de Chaillot - Asie",
    "u": "https://www.chaillot.fr/fr/asie",
    "c": "Patrimoine",
    "d": "École française de formation aux métiers de la restauration du patrimoine, élèves asiatiques.",
    "date": "2025"
  },
  {
    "n": "Centre des Monuments Nationaux - Asie",
    "u": "https://www.monuments-nationaux.fr/fr/asie",
    "c": "Patrimoine",
    "d": "Établissement public français, promotion du patrimoine en Asie.",
    "date": "2025"
  },
  {
    "n": "Musées de France - Échanges Asiatiques",
    "u": "https://www.museesdefrance.fr/fr/asie",
    "c": "Patrimoine",
    "d": "Réseau des musées français, coopérations avec des institutions asiatiques.",
    "date": "2025"
  },
  {
    "n": "Icon - Institut de Conservation - Asie",
    "u": "https://www.icon.org.uk/fr/asie",
    "c": "Patrimoine",
    "d": "Organisme international de conservation, partenariats franco-asiatiques.",
    "date": "2025"
  },
  {
    "n": "ICCROM - Bureau Asie-Pacifique",
    "u": "https://www.iccrom.org/fr/region/asie-pacifique",
    "c": "Patrimoine",
    "d": "Centre international d'études pour la conservation, bureau régional Asie-Pacifique.",
    "date": "2025"
  }
];
