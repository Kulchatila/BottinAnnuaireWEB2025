// Exemple minimal — remplace par ton top réel.
window.TOP_THEMES = [
  { theme: "Souveraineté", count: 42, desc: "Autonomie numérique, outils et pratiques." },
  { theme: "Logiciels libres", count: 37, desc: "Projets et plateformes open-source." },
  { theme: "Communauté", count: 29, desc: "Initiatives collectives et entraide." },
  { theme: "Technologie", count: 21, desc: "Innovation et outils techniques." }
];
